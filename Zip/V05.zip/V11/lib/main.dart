import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui';
import 'dart:math';

const Color kLime = Color(0xFFC5E84D);
const Color kLimeDark = Color(0xFFAACC30);
const Color kLimeText = Color(0xFF1A2E05);
const Color kBg = Color(0xFF0A0A0A);
const Color kCard = Color(0xFF131313);
const Color kSurface = Color(0xFF161616);
const Color kBorder = Color(0x0DFFFFFF);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PremiumManager.init();
  runApp(const TrendHookApp());
}

class TrendHookApp extends StatelessWidget {
  const TrendHookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TREND HOOK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        primaryColor: kCard,
      ),
      home: const HomePage(),
    );
  }
}

class PremiumManager {
  static bool _isPremium = false;
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _isPremium = _prefs?.getBool('premium') ?? false;
  }

  static bool get isPremium => _isPremium;

  static Future<void> activate() async {
    _isPremium = true;
    await _prefs?.setBool('premium', true);
  }

  static bool validateCode(String code) {
    return code == '000';
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int selectedSection = 0;
  String selectedCategory = 'All';
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<Map<String, dynamic>> categories = [
    {'name': 'All', 'icon': Icons.grid_view_rounded},
    {'name': 'Entertainment', 'icon': Icons.movie_filter_rounded},
    {'name': 'Comedy', 'icon': Icons.sentiment_very_satisfied_rounded},
    {'name': 'Education', 'icon': Icons.school_rounded},
    {'name': 'Fitness', 'icon': Icons.fitness_center_rounded},
    {'name': 'Food', 'icon': Icons.restaurant_rounded},
    {'name': 'Tech', 'icon': Icons.devices_rounded},
    {'name': 'Fashion', 'icon': Icons.checkroom_rounded},
    {'name': 'Travel', 'icon': Icons.flight_rounded},
  ];

  final Map<String, List<Map<String, dynamic>>> trendingReels = {
    'Entertainment': [
      {
        'creator': '@viralking',
        'initials': 'VK',
        'caption': 'This magic trick broke the internet',
        'views': '12.5M',
        'likes': '1.8M',
        'comments': '45.2K',
        'shares': '320K',
        'growthRate': '+540%',
        'daysAgo': 2,
        'hoursAgo': '3h',
        'category': 'Entertainment',
        'isLoaded': true,
        'color1': Color(0xFF6C5CE7),
        'color2': Color(0xFFA29BFE),
      },
      {
        'creator': '@funfactsdaily',
        'initials': 'FF',
        'caption': 'Facts that will blow your mind',
        'views': '8.3M',
        'likes': '920K',
        'comments': '28.1K',
        'shares': '180K',
        'growthRate': '+320%',
        'daysAgo': 1,
        'hoursAgo': '6h',
        'category': 'Entertainment',
        'isLoaded': false,
        'color1': Color(0xFFE17055),
        'color2': Color(0xFFFF7675),
      },
      {
        'creator': '@dancemoves',
        'initials': 'DM',
        'caption': 'New dance challenge everyone is doing',
        'views': '15.1M',
        'likes': '2.1M',
        'comments': '67K',
        'shares': '450K',
        'growthRate': '+890%',
        'daysAgo': 1,
        'hoursAgo': '1h',
        'category': 'Entertainment',
        'isLoaded': true,
        'color1': Color(0xFFC5E84D),
        'color2': Color(0xFFAACC30),
      },
    ],
    'Comedy': [
      {
        'creator': '@laughoutloud',
        'initials': 'LL',
        'caption': 'POV: When your mom finds your report card',
        'views': '9.7M',
        'likes': '1.5M',
        'comments': '52K',
        'shares': '280K',
        'growthRate': '+410%',
        'daysAgo': 1,
        'hoursAgo': '2h',
        'category': 'Comedy',
        'isLoaded': true,
        'color1': Color(0xFFFD79A8),
        'color2': Color(0xFFE84393),
      },
      {
        'creator': '@comedycentral_clips',
        'initials': 'CC',
        'caption': 'This standup bit went viral overnight',
        'views': '6.2M',
        'likes': '780K',
        'comments': '19K',
        'shares': '140K',
        'growthRate': '+280%',
        'daysAgo': 3,
        'hoursAgo': '12h',
        'category': 'Comedy',
        'isLoaded': false,
        'color1': Color(0xFF00B894),
        'color2': Color(0xFF55EFC4),
      },
      {
        'creator': '@pranksters',
        'initials': 'PR',
        'caption': 'Prank gone wholesome',
        'views': '11.4M',
        'likes': '1.9M',
        'comments': '41K',
        'shares': '390K',
        'growthRate': '+620%',
        'daysAgo': 2,
        'hoursAgo': '5h',
        'category': 'Comedy',
        'isLoaded': true,
        'color1': Color(0xFFFF7675),
        'color2': Color(0xFFD63031),
      },
    ],
    'Education': [
      {
        'creator': '@sciencewithsam',
        'initials': 'SS',
        'caption': 'Why the sky is actually violet not blue',
        'views': '5.8M',
        'likes': '640K',
        'comments': '15K',
        'shares': '210K',
        'growthRate': '+350%',
        'daysAgo': 2,
        'hoursAgo': '8h',
        'category': 'Education',
        'isLoaded': true,
        'color1': Color(0xFF0984E3),
        'color2': Color(0xFF74B9FF),
      },
      {
        'creator': '@historybuff',
        'initials': 'HB',
        'caption': 'The real story they never taught in school',
        'views': '7.1M',
        'likes': '890K',
        'comments': '32K',
        'shares': '260K',
        'growthRate': '+470%',
        'daysAgo': 1,
        'hoursAgo': '4h',
        'category': 'Education',
        'isLoaded': false,
        'color1': Color(0xFFFDAB40),
        'color2': Color(0xFFFCCB69),
      },
      {
        'creator': '@mathgenius',
        'initials': 'MG',
        'caption': 'Solve this in 5 seconds if you can',
        'views': '4.2M',
        'likes': '520K',
        'comments': '48K',
        'shares': '95K',
        'growthRate': '+190%',
        'daysAgo': 3,
        'hoursAgo': '16h',
        'category': 'Education',
        'isLoaded': true,
        'color1': Color(0xFF6C5CE7),
        'color2': Color(0xFFA29BFE),
      },
    ],
    'Fitness': [
      {
        'creator': '@fitnessguru',
        'initials': 'FG',
        'caption': '30-day transformation that shocked everyone',
        'views': '10.3M',
        'likes': '1.3M',
        'comments': '38K',
        'shares': '310K',
        'growthRate': '+560%',
        'daysAgo': 1,
        'hoursAgo': '1h',
        'category': 'Fitness',
        'isLoaded': true,
        'color1': Color(0xFF00B894),
        'color2': Color(0xFF55EFC4),
      },
      {
        'creator': '@yogawithme',
        'initials': 'YW',
        'caption': '5-minute morning routine for energy',
        'views': '3.9M',
        'likes': '480K',
        'comments': '12K',
        'shares': '170K',
        'growthRate': '+240%',
        'daysAgo': 2,
        'hoursAgo': '9h',
        'category': 'Fitness',
        'isLoaded': false,
        'color1': Color(0xFFC5E84D),
        'color2': Color(0xFFAACC30),
      },
      {
        'creator': '@homeworkouts',
        'initials': 'HW',
        'caption': 'No gym needed full body in 10 min',
        'views': '6.7M',
        'likes': '850K',
        'comments': '22K',
        'shares': '230K',
        'growthRate': '+380%',
        'daysAgo': 1,
        'hoursAgo': '3h',
        'category': 'Fitness',
        'isLoaded': true,
        'color1': Color(0xFF0984E3),
        'color2': Color(0xFF74B9FF),
      },
    ],
    'Food': [
      {
        'creator': '@chefmaster',
        'initials': 'CM',
        'caption': '60-second recipe that went mega viral',
        'views': '14.2M',
        'likes': '2.3M',
        'comments': '56K',
        'shares': '480K',
        'growthRate': '+720%',
        'daysAgo': 1,
        'hoursAgo': '1h',
        'category': 'Food',
        'isLoaded': true,
        'color1': Color(0xFFE17055),
        'color2': Color(0xFFFF7675),
      },
      {
        'creator': '@streetfoodlover',
        'initials': 'SF',
        'caption': 'This street food costs only 10rs but heavenly',
        'views': '8.9M',
        'likes': '1.1M',
        'comments': '34K',
        'shares': '290K',
        'growthRate': '+490%',
        'daysAgo': 2,
        'hoursAgo': '7h',
        'category': 'Food',
        'isLoaded': true,
        'color1': Color(0xFFFDAB40),
        'color2': Color(0xFFFCCB69),
      },
      {
        'creator': '@bakingqueen',
        'initials': 'BQ',
        'caption': 'Chocolate lava cake in microwave 2 min',
        'views': '5.5M',
        'likes': '670K',
        'comments': '18K',
        'shares': '150K',
        'growthRate': '+310%',
        'daysAgo': 3,
        'hoursAgo': '14h',
        'category': 'Food',
        'isLoaded': false,
        'color1': Color(0xFFFD79A8),
        'color2': Color(0xFFE84393),
      },
    ],
    'Tech': [
      {
        'creator': '@techbytes',
        'initials': 'TB',
        'caption': 'iPhone hidden feature 99% dont know',
        'views': '11.8M',
        'likes': '1.6M',
        'comments': '43K',
        'shares': '350K',
        'growthRate': '+580%',
        'daysAgo': 1,
        'hoursAgo': '2h',
        'category': 'Tech',
        'isLoaded': true,
        'color1': Color(0xFF0984E3),
        'color2': Color(0xFF74B9FF),
      },
      {
        'creator': '@aiupdates',
        'initials': 'AI',
        'caption': 'This AI tool replaces 10 apps at once',
        'views': '7.4M',
        'likes': '910K',
        'comments': '27K',
        'shares': '240K',
        'growthRate': '+430%',
        'daysAgo': 2,
        'hoursAgo': '5h',
        'category': 'Tech',
        'isLoaded': false,
        'color1': Color(0xFF6C5CE7),
        'color2': Color(0xFFA29BFE),
      },
      {
        'creator': '@gadgetreviews',
        'initials': 'GR',
        'caption': 'Best budget gadgets under 500rs',
        'views': '4.8M',
        'likes': '590K',
        'comments': '21K',
        'shares': '130K',
        'growthRate': '+260%',
        'daysAgo': 2,
        'hoursAgo': '10h',
        'category': 'Tech',
        'isLoaded': true,
        'color1': Color(0xFF00B894),
        'color2': Color(0xFF55EFC4),
      },
    ],
    'Fashion': [
      {
        'creator': '@styleicon',
        'initials': 'SI',
        'caption': 'Outfit ideas that are trending right now',
        'views': '9.1M',
        'likes': '1.2M',
        'comments': '36K',
        'shares': '270K',
        'growthRate': '+460%',
        'daysAgo': 1,
        'hoursAgo': '1h',
        'category': 'Fashion',
        'isLoaded': true,
        'color1': Color(0xFFC5E84D),
        'color2': Color(0xFFAACC30),
      },
      {
        'creator': '@thriftflips',
        'initials': 'TF',
        'caption': '200rs thrift flip into designer look',
        'views': '6.5M',
        'likes': '810K',
        'comments': '25K',
        'shares': '190K',
        'growthRate': '+370%',
        'daysAgo': 2,
        'hoursAgo': '8h',
        'category': 'Fashion',
        'isLoaded': true,
        'color1': Color(0xFFFD79A8),
        'color2': Color(0xFFE84393),
      },
      {
        'creator': '@sneakerhead',
        'initials': 'SH',
        'caption': 'Sneaker drop everyone is fighting for',
        'views': '5.2M',
        'likes': '640K',
        'comments': '19K',
        'shares': '160K',
        'growthRate': '+290%',
        'daysAgo': 1,
        'hoursAgo': '4h',
        'category': 'Fashion',
        'isLoaded': false,
        'color1': Color(0xFFE17055),
        'color2': Color(0xFFFF7675),
      },
    ],
    'Travel': [
      {
        'creator': '@wanderlust',
        'initials': 'WL',
        'caption': 'Hidden paradise no one talks about',
        'views': '13.6M',
        'likes': '2.0M',
        'comments': '51K',
        'shares': '420K',
        'growthRate': '+670%',
        'daysAgo': 1,
        'hoursAgo': '1h',
        'category': 'Travel',
        'isLoaded': true,
        'color1': Color(0xFF00B894),
        'color2': Color(0xFF55EFC4),
      },
      {
        'creator': '@budgettravel',
        'initials': 'BT',
        'caption': 'Full Goa trip in 5000rs complete guide',
        'views': '7.8M',
        'likes': '960K',
        'comments': '29K',
        'shares': '310K',
        'growthRate': '+440%',
        'daysAgo': 2,
        'hoursAgo': '6h',
        'category': 'Travel',
        'isLoaded': false,
        'color1': Color(0xFFFDAB40),
        'color2': Color(0xFFFCCB69),
      },
      {
        'creator': '@solobackpacker',
        'initials': 'SB',
        'caption': 'Solo travel tips that saved my life',
        'views': '4.5M',
        'likes': '550K',
        'comments': '16K',
        'shares': '120K',
        'growthRate': '+220%',
        'daysAgo': 3,
        'hoursAgo': '18h',
        'category': 'Travel',
        'isLoaded': true,
        'color1': Color(0xFF6C5CE7),
        'color2': Color(0xFFA29BFE),
      },
    ],
  };

  final List<Map<String, dynamic>> explodingAccounts = [
    {
      'username': '@risewithraj',
      'name': 'Raj Sharma',
      'initials': 'RS',
      'niche': 'Motivation',
      'followers': '1.2M',
      'followersGained': '+800K',
      'timeframe': '30 days',
      'avgViews': '5.2M',
      'engagementRate': '18.5%',
      'topContent': 'Morning routine reels',
      'color1': Color(0xFFC5E84D),
      'color2': Color(0xFFAACC30),
    },
    {
      'username': '@cookwithneha',
      'name': 'Neha Patel',
      'initials': 'NP',
      'niche': 'Food',
      'followers': '890K',
      'followersGained': '+650K',
      'timeframe': '45 days',
      'avgViews': '3.8M',
      'engagementRate': '22.1%',
      'topContent': 'Quick recipe shorts',
      'color1': Color(0xFFE17055),
      'color2': Color(0xFFFF7675),
    },
    {
      'username': '@techsavvy_arjun',
      'name': 'Arjun Mehta',
      'initials': 'AM',
      'niche': 'Tech',
      'followers': '2.1M',
      'followersGained': '+1.5M',
      'timeframe': '60 days',
      'avgViews': '8.4M',
      'engagementRate': '15.8%',
      'topContent': 'AI tool reviews',
      'color1': Color(0xFF0984E3),
      'color2': Color(0xFF74B9FF),
    },
    {
      'username': '@fitlife_priya',
      'name': 'Priya Singh',
      'initials': 'PS',
      'niche': 'Fitness',
      'followers': '670K',
      'followersGained': '+520K',
      'timeframe': '25 days',
      'avgViews': '2.9M',
      'engagementRate': '24.3%',
      'topContent': 'Home workout challenges',
      'color1': Color(0xFF00B894),
      'color2': Color(0xFF55EFC4),
    },
    {
      'username': '@travelvibe_sam',
      'name': 'Sam Wilson',
      'initials': 'SW',
      'niche': 'Travel',
      'followers': '1.5M',
      'followersGained': '+1.1M',
      'timeframe': '50 days',
      'avgViews': '6.1M',
      'engagementRate': '19.7%',
      'topContent': 'Hidden gems reels',
      'color1': Color(0xFF6C5CE7),
      'color2': Color(0xFFA29BFE),
    },
    {
      'username': '@fashionbyriya',
      'name': 'Riya Kapoor',
      'initials': 'RK',
      'niche': 'Fashion',
      'followers': '980K',
      'followersGained': '+720K',
      'timeframe': '35 days',
      'avgViews': '4.5M',
      'engagementRate': '20.9%',
      'topContent': 'Budget outfit ideas',
      'color1': Color(0xFFFD79A8),
      'color2': Color(0xFFE84393),
    },
    {
      'username': '@comedyking_amit',
      'name': 'Amit Kumar',
      'initials': 'AK',
      'niche': 'Comedy',
      'followers': '3.2M',
      'followersGained': '+2.4M',
      'timeframe': '40 days',
      'avgViews': '11.2M',
      'engagementRate': '16.4%',
      'topContent': 'Relatable comedy skits',
      'color1': Color(0xFFFF7675),
      'color2': Color(0xFFD63031),
    },
    {
      'username': '@learnwithlisa',
      'name': 'Lisa Chen',
      'initials': 'LC',
      'niche': 'Education',
      'followers': '450K',
      'followersGained': '+380K',
      'timeframe': '20 days',
      'avgViews': '2.1M',
      'engagementRate': '26.8%',
      'topContent': 'Study hack reels',
      'color1': Color(0xFFFDAB40),
      'color2': Color(0xFFFCCB69),
    },
  ];

  List<Map<String, dynamic>> get filteredReels {
    if (selectedCategory == 'All') {
      List<Map<String, dynamic>> all = [];
      trendingReels.forEach((key, value) {
        all.addAll(value);
      });
      all.sort((a, b) {
        String viewsA = (a['views'] as String).replaceAll(RegExp(r'[^0-9.]'), '');
        String viewsB = (b['views'] as String).replaceAll(RegExp(r'[^0-9.]'), '');
        return double.parse(viewsB).compareTo(double.parse(viewsA));
      });
      return all;
    }
    return trendingReels[selectedCategory] ?? [];
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {
        selectedSection = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 6),
            _buildTopBar(),
            const SizedBox(height: 14),
            _buildSearchBar(),
            const SizedBox(height: 14),
            _buildSectionTabs(),
            if (selectedSection == 0) ...[
              const SizedBox(height: 14),
              _buildCategoryChips(),
            ],
            const SizedBox(height: 14),
            Expanded(
              child: selectedSection == 0
                  ? _buildReelsGrid()
                  : _buildAccountsList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder, width: 0.5),
              ),
              child: Icon(
                Icons.menu_rounded,
                color: Colors.white.withOpacity(0.85),
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Row(
              children: [
                const Text(
                  'TREND',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: kLime,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.local_fire_department_rounded,
                        color: kLimeText,
                        size: 16,
                      ),
                      const SizedBox(width: 3),
                      const Text(
                        'HOOK',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: kLimeText,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (PremiumManager.isPremium)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: kLime,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                'PRO',
                style: TextStyle(
                  color: kLimeText,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 46,
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Row(
          children: [
            const SizedBox(width: 14),
            Icon(
              Icons.search_rounded,
              color: Colors.white.withOpacity(0.3),
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                decoration: InputDecoration(
                  hintText: 'Search trending reels & creators',
                  hintStyle: TextStyle(
                    color: Colors.white.withOpacity(0.22),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: TabBar(
          controller: _tabController,
          indicator: BoxDecoration(
            color: kLime,
            borderRadius: BorderRadius.circular(10),
          ),
          indicatorSize: TabBarIndicatorSize.tab,
          indicatorPadding: const EdgeInsets.all(3),
          dividerColor: Colors.transparent,
          labelColor: kLimeText,
          unselectedLabelColor: Colors.white.withOpacity(0.35),
          labelStyle: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.2,
          ),
          unselectedLabelStyle: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
          tabs: const [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.local_fire_department_rounded, size: 16),
                  SizedBox(width: 5),
                  Text('Trending Reels'),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.rocket_launch_rounded, size: 16),
                  SizedBox(width: 5),
                  Text('Rising Creators'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryChips() {
    return SizedBox(
      height: 38,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final cat = categories[index];
          final name = cat['name'] as String;
          final icon = cat['icon'] as IconData;
          final isSelected = selectedCategory == name;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => setState(() => selectedCategory = name),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? kLime : kSurface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? kLimeDark : kBorder,
                    width: isSelected ? 1 : 0.5,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: kLime.withOpacity(0.2),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      icon,
                      size: 14,
                      color: isSelected ? kLimeText : Colors.white.withOpacity(0.35),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      name,
                      style: TextStyle(
                        color: isSelected ? kLimeText : Colors.white.withOpacity(0.45),
                        fontSize: 12,
                        fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
                        letterSpacing: 0.1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildReelsGrid() {
    final reels = filteredReels;
    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.62,
      ),
      itemCount: reels.length,
      itemBuilder: (context, index) {
        final reel = reels[index];
        final isLocked = index >= 4 && !PremiumManager.isPremium;
        return GestureDetector(
          onTap: () {
            if (isLocked) {
              _showPremiumDialog();
              return;
            }
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ReelDetailPage(reel: reel),
              ),
            );
          },
          child: _buildReelCard(reel, isLocked),
        );
      },
    );
  }

  Widget _buildReelCard(Map<String, dynamic> reel, bool isLocked) {
    final bool isLoaded = reel['isLoaded'] as bool;
    final Color c1 = reel['color1'] as Color;
    final Color c2 = reel['color2'] as Color;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (isLoaded)
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      c1.withOpacity(0.35),
                      c2.withOpacity(0.2),
                      const Color(0xFF1A1A1A),
                    ],
                    stops: const [0.0, 0.4, 1.0],
                  ),
                ),
              )
            else
              _ReelShimmerLoader(color1: c1, color2: c2),

            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(isLoaded ? 0.7 : 0.4),
                    Colors.black.withOpacity(isLoaded ? 0.9 : 0.6),
                  ],
                  stops: const [0.0, 0.3, 0.7, 1.0],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [c1, c2]),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.2),
                            width: 1.5,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            reel['initials'] as String,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          reel['creator'] as String,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            letterSpacing: -0.1,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  if (!isLoaded)
                    Center(
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.play_arrow_rounded,
                          color: Colors.white.withOpacity(0.5),
                          size: 22,
                        ),
                      ),
                    ),
                  if (!isLoaded) const Spacer(),
                  Text(
                    (reel['caption'] as String).toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      height: 1.3,
                      letterSpacing: 0.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        width: 5,
                        height: 5,
                        decoration: const BoxDecoration(
                          color: kLime,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        reel['hoursAgo'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.45),
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(
                        Icons.play_circle_outline_rounded,
                        size: 11,
                        color: Colors.white.withOpacity(0.35),
                      ),
                      const SizedBox(width: 3),
                      Text(
                        reel['views'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.35),
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            if (isLoaded)
              Positioned(
                top: 10,
                right: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: kLime.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    reel['growthRate'] as String,
                    style: const TextStyle(
                      color: kLime,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),

            if (isLocked)
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
                  child: Container(
                    color: Colors.black.withOpacity(0.4),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.lock_rounded,
                            color: kLime.withOpacity(0.8),
                            size: 24,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'PRO',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountsList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: explodingAccounts.length,
      itemBuilder: (context, index) {
        final account = explodingAccounts[index];
        final isLocked = index >= 3 && !PremiumManager.isPremium;
        return GestureDetector(
          onTap: () {
            if (isLocked) {
              _showPremiumDialog();
              return;
            }
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AccountDetailPage(account: account),
              ),
            );
          },
          child: _buildAccountCard(account, isLocked),
        );
      },
    );
  }

  Widget _buildAccountCard(Map<String, dynamic> account, bool isLocked) {
    final Color c1 = account['color1'] as Color;
    final Color c2 = account['color2'] as Color;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [c1, c2]),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          account['initials'] as String,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            account['name'] as String,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                              letterSpacing: -0.2,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            account['username'] as String,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.35),
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: kLime,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: kLime.withOpacity(0.15),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.star_rounded, size: 12, color: kLimeText),
                          const SizedBox(width: 3),
                          Text(
                            account['niche'] as String,
                            style: const TextStyle(
                              color: kLimeText,
                              fontWeight: FontWeight.w800,
                              fontSize: 10,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _miniStat('Followers', account['followers'] as String),
                    _dividerDot(),
                    _miniStat('Gained', account['followersGained'] as String),
                    _dividerDot(),
                    _miniStat('In', account['timeframe'] as String),
                    _dividerDot(),
                    _miniStat('Engage', account['engagementRate'] as String),
                  ],
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.03),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.auto_awesome_rounded,
                        size: 12,
                        color: kLime.withOpacity(0.7),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        account['topContent'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.45),
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (isLocked)
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
                  child: Container(
                    color: Colors.black.withOpacity(0.45),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.lock_rounded,
                            color: kLime.withOpacity(0.8),
                            size: 24,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'PRO',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _miniStat(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              color: Colors.white.withOpacity(0.85),
              fontWeight: FontWeight.w700,
              fontSize: 13,
              letterSpacing: -0.2,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.25),
              fontSize: 9,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _dividerDot() {
    return Container(
      width: 2,
      height: 2,
      margin: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kBorder, width: 0.5),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: kLime,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Icon(
                        Icons.local_fire_department_rounded,
                        color: kLimeText,
                        size: 24,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        const Text(
                          'TREND',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: kLime,
                            borderRadius: BorderRadius.circular(7),
                          ),
                          child: const Text(
                            'HOOK',
                            style: TextStyle(
                              color: kLimeText,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      PremiumManager.isPremium ? 'PRO Member' : 'Free Plan',
                      style: TextStyle(
                        color: PremiumManager.isPremium
                            ? kLime
                            : Colors.white.withOpacity(0.35),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              _drawerItem(Icons.home_rounded, 'Home', () => Navigator.pop(context)),
              const SizedBox(height: 6),
              _drawerItem(Icons.local_fire_department_rounded, 'Trending Reels', () {
                setState(() {
                  selectedSection = 0;
                  _tabController.animateTo(0);
                });
                Navigator.pop(context);
              }),
              const SizedBox(height: 6),
              _drawerItem(Icons.rocket_launch_rounded, 'Rising Creators', () {
                setState(() {
                  selectedSection = 1;
                  _tabController.animateTo(1);
                });
                Navigator.pop(context);
              }),
              const SizedBox(height: 6),
              _drawerItem(Icons.bolt_rounded, 'Go PRO', () {
                Navigator.pop(context);
                _showPremiumDialog();
              }),
              const Spacer(),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kBorder, width: 0.5),
                ),
                child: Text(
                  'TREND HOOK v3.0',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.25),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white.withOpacity(0.5), size: 20),
            const SizedBox(width: 12),
            Text(
              title,
              style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showPremiumDialog() {
    final TextEditingController codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFF141414),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kBorder, width: 0.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: kLime,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(
                      Icons.bolt_rounded,
                      color: kLimeText,
                      size: 28,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'UNLOCK PRO',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Unlimited access to all trending data',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: kBorder, width: 0.5),
                    ),
                    child: TextField(
                      controller: codeController,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        letterSpacing: 4,
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'Enter code',
                        hintStyle: TextStyle(
                          color: Colors.white.withOpacity(0.15),
                          letterSpacing: 2,
                          fontWeight: FontWeight.w400,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  GestureDetector(
                    onTap: () async {
                      if (PremiumManager.validateCode(codeController.text.trim())) {
                        await PremiumManager.activate();
                        if (ctx.mounted) {
                          Navigator.pop(ctx);
                          setState(() {});
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: const Text(
                                'PRO activated',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: kLimeText,
                                ),
                              ),
                              backgroundColor: kLime,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              margin: const EdgeInsets.all(20),
                            ),
                          );
                        }
                      } else {
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: const Text(
                                'Invalid code',
                                style: TextStyle(fontWeight: FontWeight.w600),
                              ),
                              backgroundColor: const Color(0xFF333333),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              margin: const EdgeInsets.all(20),
                            ),
                          );
                        }
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      height: 48,
                      decoration: BoxDecoration(
                        color: kLime,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: kLime.withOpacity(0.25),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          'ACTIVATE',
                          style: TextStyle(
                            color: kLimeText,
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ReelShimmerLoader extends StatefulWidget {
  final Color color1;
  final Color color2;

  const _ReelShimmerLoader({required this.color1, required this.color2});

  @override
  State<_ReelShimmerLoader> createState() => _ReelShimmerLoaderState();
}

class _ReelShimmerLoaderState extends State<_ReelShimmerLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 2800),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final v = _controller.value;
        final sigma = 8.0 + (v * 6.0);
        return Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(v * 2 - 1, -1),
                  end: Alignment(1, v * 2 - 1),
                  colors: [
                    widget.color1.withOpacity(0.15 + v * 0.1),
                    widget.color2.withOpacity(0.1 + v * 0.08),
                    const Color(0xFF1A1A1A).withOpacity(0.8),
                    widget.color1.withOpacity(0.08 + (1 - v) * 0.1),
                  ],
                  stops: [
                    0.0,
                    (0.3 + v * 0.1).clamp(0.0, 1.0),
                    (0.6 + v * 0.1).clamp(0.0, 1.0),
                    1.0,
                  ],
                ),
              ),
            ),
            BackdropFilter(
              filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment(-1 + v * 2, -1),
                    end: Alignment(1, -1 + v * 2),
                    colors: [
                      Colors.white.withOpacity(0.0),
                      Colors.white.withOpacity(0.02 + v * 0.02),
                      Colors.white.withOpacity(0.04 + v * 0.03),
                      Colors.white.withOpacity(0.02 + v * 0.02),
                      Colors.white.withOpacity(0.0),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class ReelDetailPage extends StatelessWidget {
  final Map<String, dynamic> reel;
  const ReelDetailPage({super.key, required this.reel});

  @override
  Widget build(BuildContext context) {
    final Color c1 = reel['color1'] as Color;
    final Color c2 = reel['color2'] as Color;
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildPreview(c1, c2),
                    const SizedBox(height: 14),
                    _buildCreatorRow(c1, c2),
                    const SizedBox(height: 14),
                    _buildCaption(),
                    const SizedBox(height: 14),
                    _buildStats(),
                    const SizedBox(height: 14),
                    _buildInsight(c1),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder, width: 0.5),
              ),
              child: Icon(Icons.arrow_back_rounded, color: Colors.white.withOpacity(0.85), size: 20),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Text(
              'REEL DETAILS',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: reel['caption'] as String));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Copied', style: TextStyle(fontWeight: FontWeight.w700, color: kLimeText)),
                  backgroundColor: kLime,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  margin: const EdgeInsets.all(20),
                ),
              );
            },
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder, width: 0.5),
              ),
              child: Icon(Icons.copy_rounded, color: Colors.white.withOpacity(0.85), size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreview(Color c1, Color c2) {
    return Container(
      height: 240,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [c1.withOpacity(0.2), c2.withOpacity(0.12), const Color(0xFF1A1A1A)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Icon(Icons.play_circle_fill_rounded, size: 56, color: Colors.white.withOpacity(0.2)),
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: kLime,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.star_rounded, size: 12, color: kLimeText),
                  const SizedBox(width: 3),
                  Text(
                    reel['category'] as String,
                    style: const TextStyle(color: kLimeText, fontSize: 10, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreatorRow(Color c1, Color c2) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [c1, c2]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(
                reel['initials'] as String,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  reel['creator'] as String,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15, letterSpacing: -0.2),
                ),
                Text(
                  '${reel['daysAgo']} days ago',
                  style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: kLime.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              reel['growthRate'] as String,
              style: const TextStyle(color: kLime, fontWeight: FontWeight.w800, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCaption() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CAPTION',
            style: TextStyle(
              color: Colors.white.withOpacity(0.25),
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            reel['caption'] as String,
            style: TextStyle(
              color: Colors.white.withOpacity(0.85),
              fontSize: 15,
              fontWeight: FontWeight.w500,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStats() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PERFORMANCE',
            style: TextStyle(
              color: Colors.white.withOpacity(0.25),
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _tile(Icons.play_circle_outline_rounded, 'Views', reel['views'] as String),
              const SizedBox(width: 10),
              _tile(Icons.favorite_outline_rounded, 'Likes', reel['likes'] as String),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _tile(Icons.chat_bubble_outline_rounded, 'Comments', reel['comments'] as String),
              const SizedBox(width: 10),
              _tile(Icons.share_outlined, 'Shares', reel['shares'] as String),
            ],
          ),
        ],
      ),
    );
  }

  Widget _tile(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.03),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: Colors.white.withOpacity(0.3)),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17, letterSpacing: -0.3),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 10, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInsight(Color c1) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kLime.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kLime.withOpacity(0.12), width: 0.5),
      ),
      child: Row(
        children: [
          Icon(Icons.insights_rounded, color: kLime.withOpacity(0.7), size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Growth Insight',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.85),
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    letterSpacing: -0.1,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'Grew ${reel['growthRate']} in ${reel['daysAgo']}d — ${reel['category']} category',
                  style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AccountDetailPage extends StatelessWidget {
  final Map<String, dynamic> account;
  const AccountDetailPage({super.key, required this.account});

  @override
  Widget build(BuildContext context) {
    final Color c1 = account['color1'] as Color;
    final Color c2 = account['color2'] as Color;
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: kBorder, width: 0.5),
                      ),
                      child: Icon(Icons.arrow_back_rounded, color: Colors.white.withOpacity(0.85), size: 20),
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text(
                    'CREATOR PROFILE',
                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: 0.8),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: kBorder, width: 0.5),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [c1, c2]),
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                account['initials'] as String,
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 24),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            (account['name'] as String).toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 0.5),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            account['username'] as String,
                            style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 14),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: kLime,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.star_rounded, size: 14, color: kLimeText),
                                const SizedBox(width: 4),
                                Text(
                                  account['niche'] as String,
                                  style: const TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _statCard('Followers', account['followers'] as String, Icons.people_outline_rounded),
                        const SizedBox(width: 8),
                        _statCard('Gained', account['followersGained'] as String, Icons.trending_up_rounded),
                        const SizedBox(width: 8),
                        _statCard('Avg Views', account['avgViews'] as String, Icons.visibility_outlined),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: kBorder, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'GROWTH',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.25),
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 14),
                          _row('Followers Gained', account['followersGained'] as String),
                          _divider(),
                          _row('Timeframe', account['timeframe'] as String),
                          _divider(),
                          _row('Engagement Rate', account['engagementRate'] as String),
                          _divider(),
                          _row('Avg Views/Reel', account['avgViews'] as String),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: kLime.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: kLime.withOpacity(0.12), width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.auto_awesome_rounded, color: kLime.withOpacity(0.7), size: 18),
                              const SizedBox(width: 8),
                              Text(
                                'Content Strategy',
                                style: TextStyle(color: Colors.white.withOpacity(0.85), fontWeight: FontWeight.w700, fontSize: 14, letterSpacing: -0.1),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Top content: ${account['topContent']}',
                            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13, height: 1.5),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Gained ${account['followersGained']} in ${account['timeframe']} with ${account['engagementRate']} engagement.',
                            style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 12, height: 1.5),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: Colors.white.withOpacity(0.3)),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: -0.2),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13)),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _divider() {
    return Divider(height: 1, color: Colors.white.withOpacity(0.04));
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PremiumManager.init();
  runApp(const TrendHookApp());
}

class TrendHookApp extends StatelessWidget {
  const TrendHookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trend Hook',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
        primaryColor: const Color(0xFF1E1E1E),
      ),
      home: const HomePage(),
    );
  }
}

class PremiumManager {
  static bool _isPremium = false;
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _isPremium = _prefs?.getBool('premium') ?? false;
  }

  static bool get isPremium => _isPremium;

  static Future<void> activate() async {
    _isPremium = true;
    await _prefs?.setBool('premium', true);
  }

  static bool validateCode(String code) {
    return code == '000';
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int selectedSection = 0;
  String selectedCategory = 'All';
  late TabController _tabController;

  final List<String> categories = [
    'All',
    'Entertainment',
    'Comedy',
    'Education',
    'Fitness',
    'Food',
    'Tech',
    'Fashion',
    'Travel',
  ];

  final Map<String, List<Map<String, dynamic>>> trendingReels = {
    'Entertainment': [
      {
        'creator': '@viralking',
        'caption': 'This magic trick broke the internet 🎩✨',
        'views': '12.5M',
        'likes': '1.8M',
        'comments': '45.2K',
        'shares': '320K',
        'growthRate': '+540%',
        'daysAgo': 2,
        'category': 'Entertainment',
      },
      {
        'creator': '@funfactsdaily',
        'caption': 'Facts that will blow your mind 🤯',
        'views': '8.3M',
        'likes': '920K',
        'comments': '28.1K',
        'shares': '180K',
        'growthRate': '+320%',
        'daysAgo': 1,
        'category': 'Entertainment',
      },
      {
        'creator': '@dancemoves',
        'caption': 'New dance challenge everyone is doing 💃',
        'views': '15.1M',
        'likes': '2.1M',
        'comments': '67K',
        'shares': '450K',
        'growthRate': '+890%',
        'daysAgo': 1,
        'category': 'Entertainment',
      },
    ],
    'Comedy': [
      {
        'creator': '@laughoutloud',
        'caption': 'POV: When your mom finds your report card 😂',
        'views': '9.7M',
        'likes': '1.5M',
        'comments': '52K',
        'shares': '280K',
        'growthRate': '+410%',
        'daysAgo': 1,
        'category': 'Comedy',
      },
      {
        'creator': '@comedycentral_clips',
        'caption': 'This standup bit went viral overnight 🎤',
        'views': '6.2M',
        'likes': '780K',
        'comments': '19K',
        'shares': '140K',
        'growthRate': '+280%',
        'daysAgo': 3,
        'category': 'Comedy',
      },
      {
        'creator': '@pranksters',
        'caption': 'Prank gone wholesome 🥹',
        'views': '11.4M',
        'likes': '1.9M',
        'comments': '41K',
        'shares': '390K',
        'growthRate': '+620%',
        'daysAgo': 2,
        'category': 'Comedy',
      },
    ],
    'Education': [
      {
        'creator': '@sciencewithsam',
        'caption': 'Why the sky is actually violet, not blue 🔬',
        'views': '5.8M',
        'likes': '640K',
        'comments': '15K',
        'shares': '210K',
        'growthRate': '+350%',
        'daysAgo': 2,
        'category': 'Education',
      },
      {
        'creator': '@historybuff',
        'caption': 'The real story they never taught in school 📚',
        'views': '7.1M',
        'likes': '890K',
        'comments': '32K',
        'shares': '260K',
        'growthRate': '+470%',
        'daysAgo': 1,
        'category': 'Education',
      },
      {
        'creator': '@mathgenius',
        'caption': 'Solve this in 5 seconds if you can 🧮',
        'views': '4.2M',
        'likes': '520K',
        'comments': '48K',
        'shares': '95K',
        'growthRate': '+190%',
        'daysAgo': 3,
        'category': 'Education',
      },
    ],
    'Fitness': [
      {
        'creator': '@fitnessguru',
        'caption': '30-day transformation that shocked everyone 💪',
        'views': '10.3M',
        'likes': '1.3M',
        'comments': '38K',
        'shares': '310K',
        'growthRate': '+560%',
        'daysAgo': 1,
        'category': 'Fitness',
      },
      {
        'creator': '@yogawithme',
        'caption': '5-minute morning routine for energy ☀️',
        'views': '3.9M',
        'likes': '480K',
        'comments': '12K',
        'shares': '170K',
        'growthRate': '+240%',
        'daysAgo': 2,
        'category': 'Fitness',
      },
      {
        'creator': '@homeworkouts',
        'caption': 'No gym needed — full body in 10 min 🏠',
        'views': '6.7M',
        'likes': '850K',
        'comments': '22K',
        'shares': '230K',
        'growthRate': '+380%',
        'daysAgo': 1,
        'category': 'Fitness',
      },
    ],
    'Food': [
      {
        'creator': '@chefmaster',
        'caption': '60-second recipe that went mega viral 🍕',
        'views': '14.2M',
        'likes': '2.3M',
        'comments': '56K',
        'shares': '480K',
        'growthRate': '+720%',
        'daysAgo': 1,
        'category': 'Food',
      },
      {
        'creator': '@streetfoodlover',
        'caption': 'This street food costs only ₹10 but tastes like heaven 🤤',
        'views': '8.9M',
        'likes': '1.1M',
        'comments': '34K',
        'shares': '290K',
        'growthRate': '+490%',
        'daysAgo': 2,
        'category': 'Food',
      },
      {
        'creator': '@bakingqueen',
        'caption': 'Chocolate lava cake in microwave — 2 min 🍫',
        'views': '5.5M',
        'likes': '670K',
        'comments': '18K',
        'shares': '150K',
        'growthRate': '+310%',
        'daysAgo': 3,
        'category': 'Food',
      },
    ],
    'Tech': [
      {
        'creator': '@techbytes',
        'caption': 'iPhone hidden feature 99% people don\'t know 📱',
        'views': '11.8M',
        'likes': '1.6M',
        'comments': '43K',
        'shares': '350K',
        'growthRate': '+580%',
        'daysAgo': 1,
        'category': 'Tech',
      },
      {
        'creator': '@aiupdates',
        'caption': 'This AI tool replaces 10 apps at once 🤖',
        'views': '7.4M',
        'likes': '910K',
        'comments': '27K',
        'shares': '240K',
        'growthRate': '+430%',
        'daysAgo': 2,
        'category': 'Tech',
      },
      {
        'creator': '@gadgetreviews',
        'caption': 'Best budget gadgets under ₹500 🔥',
        'views': '4.8M',
        'likes': '590K',
        'comments': '21K',
        'shares': '130K',
        'growthRate': '+260%',
        'daysAgo': 2,
        'category': 'Tech',
      },
    ],
    'Fashion': [
      {
        'creator': '@styleicon',
        'caption': 'Outfit ideas that are trending right now 👗',
        'views': '9.1M',
        'likes': '1.2M',
        'comments': '36K',
        'shares': '270K',
        'growthRate': '+460%',
        'daysAgo': 1,
        'category': 'Fashion',
      },
      {
        'creator': '@thriftflips',
        'caption': '₹200 thrift flip into designer look 🧵',
        'views': '6.5M',
        'likes': '810K',
        'comments': '25K',
        'shares': '190K',
        'growthRate': '+370%',
        'daysAgo': 2,
        'category': 'Fashion',
      },
      {
        'creator': '@sneakerhead',
        'caption': 'Sneaker drop everyone is fighting for 👟',
        'views': '5.2M',
        'likes': '640K',
        'comments': '19K',
        'shares': '160K',
        'growthRate': '+290%',
        'daysAgo': 1,
        'category': 'Fashion',
      },
    ],
    'Travel': [
      {
        'creator': '@wanderlust',
        'caption': 'Hidden paradise no one talks about 🏝️',
        'views': '13.6M',
        'likes': '2.0M',
        'comments': '51K',
        'shares': '420K',
        'growthRate': '+670%',
        'daysAgo': 1,
        'category': 'Travel',
      },
      {
        'creator': '@budgettravel',
        'caption': 'Full Goa trip in ₹5000 — complete guide 🗺️',
        'views': '7.8M',
        'likes': '960K',
        'comments': '29K',
        'shares': '310K',
        'growthRate': '+440%',
        'daysAgo': 2,
        'category': 'Travel',
      },
      {
        'creator': '@solobackpacker',
        'caption': 'Solo travel tips that saved my life 🎒',
        'views': '4.5M',
        'likes': '550K',
        'comments': '16K',
        'shares': '120K',
        'growthRate': '+220%',
        'daysAgo': 3,
        'category': 'Travel',
      },
    ],
  };

  final List<Map<String, dynamic>> explodingAccounts = [
    {
      'username': '@risewithraj',
      'name': 'Raj Sharma',
      'niche': 'Motivation',
      'followers': '1.2M',
      'followersGained': '+800K',
      'timeframe': '30 days',
      'avgViews': '5.2M',
      'engagementRate': '18.5%',
      'topContent': 'Morning routine reels',
    },
    {
      'username': '@cookwithneha',
      'name': 'Neha Patel',
      'niche': 'Food',
      'followers': '890K',
      'followersGained': '+650K',
      'timeframe': '45 days',
      'avgViews': '3.8M',
      'engagementRate': '22.1%',
      'topContent': 'Quick recipe shorts',
    },
    {
      'username': '@techsavvy_arjun',
      'name': 'Arjun Mehta',
      'niche': 'Tech',
      'followers': '2.1M',
      'followersGained': '+1.5M',
      'timeframe': '60 days',
      'avgViews': '8.4M',
      'engagementRate': '15.8%',
      'topContent': 'AI tool reviews',
    },
    {
      'username': '@fitlife_priya',
      'name': 'Priya Singh',
      'niche': 'Fitness',
      'followers': '670K',
      'followersGained': '+520K',
      'timeframe': '25 days',
      'avgViews': '2.9M',
      'engagementRate': '24.3%',
      'topContent': 'Home workout challenges',
    },
    {
      'username': '@travelvibe_sam',
      'name': 'Sam Wilson',
      'niche': 'Travel',
      'followers': '1.5M',
      'followersGained': '+1.1M',
      'timeframe': '50 days',
      'avgViews': '6.1M',
      'engagementRate': '19.7%',
      'topContent': 'Hidden gems reels',
    },
    {
      'username': '@fashionbyriya',
      'name': 'Riya Kapoor',
      'niche': 'Fashion',
      'followers': '980K',
      'followersGained': '+720K',
      'timeframe': '35 days',
      'avgViews': '4.5M',
      'engagementRate': '20.9%',
      'topContent': 'Budget outfit ideas',
    },
    {
      'username': '@comedyking_amit',
      'name': 'Amit Kumar',
      'niche': 'Comedy',
      'followers': '3.2M',
      'followersGained': '+2.4M',
      'timeframe': '40 days',
      'avgViews': '11.2M',
      'engagementRate': '16.4%',
      'topContent': 'Relatable comedy skits',
    },
    {
      'username': '@learnwithlisa',
      'name': 'Lisa Chen',
      'niche': 'Education',
      'followers': '450K',
      'followersGained': '+380K',
      'timeframe': '20 days',
      'avgViews': '2.1M',
      'engagementRate': '26.8%',
      'topContent': 'Study hack reels',
    },
  ];

  List<Map<String, dynamic>> get filteredReels {
    if (selectedCategory == 'All') {
      List<Map<String, dynamic>> all = [];
      trendingReels.forEach((key, value) {
        all.addAll(value);
      });
      all.sort((a, b) {
        String viewsA = (a['views'] as String).replaceAll(RegExp(r'[^0-9.]'), '');
        String viewsB = (b['views'] as String).replaceAll(RegExp(r'[^0-9.]'), '');
        return double.parse(viewsB).compareTo(double.parse(viewsA));
      });
      return all;
    }
    return trendingReels[selectedCategory] ?? [];
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {
        selectedSection = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            _buildTopHeader(),
            const SizedBox(height: 12),
            _buildSectionTabs(),
            if (selectedSection == 0) ...[
              const SizedBox(height: 12),
              _buildCategoryChips(),
            ],
            const SizedBox(height: 12),
            Expanded(
              child: selectedSection == 0
                  ? _buildTrendingReelsGrid()
                  : _buildExplodingAccountsList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.12),
                      width: 1,
                    ),
                  ),
                  child: Icon(
                    Icons.menu_rounded,
                    color: Colors.white.withOpacity(0.9),
                    size: 22,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Color(0xFFE040FB), Color(0xFFFF5252), Color(0xFFFFAB40)],
                      ).createShader(bounds),
                      child: const Text(
                        'Trend Hook',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: -0.5,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Icon(
                      Icons.local_fire_department_rounded,
                      color: const Color(0xFFFF5252),
                      size: 20,
                    ),
                  ],
                ),
                Text(
                  'Catch trends before they blow up',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          if (PremiumManager.isPremium)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFE040FB), Color(0xFFFF5252)],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.bolt_rounded, color: Colors.white, size: 14),
                  SizedBox(width: 4),
                  Text(
                    'PRO',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
                width: 1,
              ),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFE040FB), Color(0xFFFF5252)],
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorPadding: const EdgeInsets.all(4),
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white.withOpacity(0.5),
              labelStyle: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              tabs: const [
                Tab(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.trending_up_rounded, size: 18),
                      SizedBox(width: 6),
                      Text('Trending Reels'),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_rounded, size: 18),
                      SizedBox(width: 6),
                      Text('Exploding Accounts'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryChips() {
    return SizedBox(
      height: 38,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final cat = categories[index];
          final isSelected = selectedCategory == cat;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  selectedCategory = cat;
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(
                          colors: [Color(0xFFE040FB), Color(0xFFFF5252)],
                        )
                      : null,
                  color: isSelected ? null : Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? Colors.transparent
                        : Colors.white.withOpacity(0.1),
                    width: 1,
                  ),
                ),
                child: Text(
                  cat,
                  style: TextStyle(
                    color: isSelected
                        ? Colors.white
                        : Colors.white.withOpacity(0.6),
                    fontSize: 13,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTrendingReelsGrid() {
    final reels = filteredReels;
    if (reels.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.trending_up_rounded,
              size: 60,
              color: Colors.white.withOpacity(0.2),
            ),
            const SizedBox(height: 12),
            Text(
              'No trending reels found',
              style: TextStyle(
                color: Colors.white.withOpacity(0.4),
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: reels.length,
      itemBuilder: (context, index) {
        final reel = reels[index];
        final isPremiumContent = index >= 3 && !PremiumManager.isPremium;
        return GestureDetector(
          onTap: () {
            if (isPremiumContent) {
              _showPremiumDialog();
              return;
            }
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ReelDetailPage(reel: reel),
              ),
            );
          },
          child: _buildReelCard(reel, isPremiumContent),
        );
      },
    );
  }

  Widget _buildReelCard(Map<String, dynamic> reel, bool isLocked) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
                width: 1,
              ),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFE040FB), Color(0xFFFF5252), Color(0xFFFFAB40)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Center(
                              child: Text(
                                (reel['creator'] as String).substring(1, 3).toUpperCase(),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  reel['creator'] as String,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.95),
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '${reel['daysAgo']}d ago • ${reel['category']}',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: const Color(0xFF00E676).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: const Color(0xFF00E676).withOpacity(0.3),
                              ),
                            ),
                            child: Text(
                              reel['growthRate'] as String,
                              style: const TextStyle(
                                color: Color(0xFF00E676),
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        reel['caption'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.85),
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          height: 1.4,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          _buildStatChip(Icons.play_circle_outline_rounded, reel['views'] as String),
                          const SizedBox(width: 12),
                          _buildStatChip(Icons.favorite_outline_rounded, reel['likes'] as String),
                          const SizedBox(width: 12),
                          _buildStatChip(Icons.chat_bubble_outline_rounded, reel['comments'] as String),
                          const SizedBox(width: 12),
                          _buildStatChip(Icons.share_outlined, reel['shares'] as String),
                        ],
                      ),
                    ],
                  ),
                ),
                if (isLocked)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.lock_rounded,
                                  color: Color(0xFFE040FB),
                                  size: 28,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'PRO Content',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.8),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatChip(IconData icon, String value) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 15, color: Colors.white.withOpacity(0.4)),
        const SizedBox(width: 4),
        Text(
          value,
          style: TextStyle(
            color: Colors.white.withOpacity(0.5),
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildExplodingAccountsList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: explodingAccounts.length,
      itemBuilder: (context, index) {
        final account = explodingAccounts[index];
        final isPremiumContent = index >= 3 && !PremiumManager.isPremium;
        return GestureDetector(
          onTap: () {
            if (isPremiumContent) {
              _showPremiumDialog();
              return;
            }
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AccountDetailPage(account: account),
              ),
            );
          },
          child: _buildAccountCard(account, isPremiumContent),
        );
      },
    );
  }

  Widget _buildAccountCard(Map<String, dynamic> account, bool isLocked) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
                width: 1,
              ),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFE040FB), Color(0xFFFF5252), Color(0xFFFFAB40)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                (account['name'] as String).split(' ').map((w) => w[0]).take(2).join(),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  account['name'] as String,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.95),
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  account['username'] as String,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.4),
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  const Color(0xFFE040FB).withOpacity(0.2),
                                  const Color(0xFFFF5252).withOpacity(0.2),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: const Color(0xFFE040FB).withOpacity(0.3),
                              ),
                            ),
                            child: Text(
                              account['niche'] as String,
                              style: const TextStyle(
                                color: Color(0xFFE040FB),
                                fontWeight: FontWeight.w600,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          _buildAccountStat('Followers', account['followers'] as String),
                          _buildAccountStat('Gained', account['followersGained'] as String),
                          _buildAccountStat('In', account['timeframe'] as String),
                          _buildAccountStat('Engagement', account['engagementRate'] as String),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.auto_awesome_rounded,
                              size: 14,
                              color: const Color(0xFFFFAB40),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'Top: ${account['topContent']}',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.6),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                if (isLocked)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.lock_rounded,
                                  color: Color(0xFFE040FB),
                                  size: 28,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'PRO Content',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.8),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAccountStat(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.35),
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: const Color(0xFF0A0A0A),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDrawerHeader(),
              const SizedBox(height: 32),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildDrawerItem(
                        Icons.home_rounded,
                        'Home',
                        () => Navigator.pop(context),
                      ),
                      const SizedBox(height: 8),
                      _buildDrawerItem(
                        Icons.trending_up_rounded,
                        'Trending Reels',
                        () {
                          setState(() {
                            selectedSection = 0;
                            _tabController.animateTo(0);
                          });
                          Navigator.pop(context);
                        },
                      ),
                      const SizedBox(height: 8),
                      _buildDrawerItem(
                        Icons.rocket_launch_rounded,
                        'Exploding Accounts',
                        () {
                          setState(() {
                            selectedSection = 1;
                            _tabController.animateTo(1);
                          });
                          Navigator.pop(context);
                        },
                      ),
                      const SizedBox(height: 8),
                      _buildDrawerItem(
                        Icons.bolt_rounded,
                        'Go Premium',
                        () {
                          Navigator.pop(context);
                          _showPremiumDialog();
                        },
                      ),
                    ],
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFFE040FB).withOpacity(0.15),
                          const Color(0xFFFF5252).withOpacity(0.15),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFFE040FB).withOpacity(0.2),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Trend Hook v1.0',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Catch Instagram trends early',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerHeader() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFE040FB).withOpacity(0.12),
                const Color(0xFFFF5252).withOpacity(0.12),
                const Color(0xFFFFAB40).withOpacity(0.08),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFE040FB), Color(0xFFFF5252), Color(0xFFFFAB40)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(
                  Icons.local_fire_department_rounded,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'Trend Hook',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                PremiumManager.isPremium ? 'PRO Member' : 'Free Plan',
                style: TextStyle(
                  color: PremiumManager.isPremium
                      ? const Color(0xFFE040FB)
                      : Colors.white.withOpacity(0.5),
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withOpacity(0.06),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: Colors.white.withOpacity(0.7), size: 22),
                const SizedBox(width: 14),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.8),
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showPremiumDialog() {
    final TextEditingController codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A1A).withOpacity(0.9),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: Colors.white.withOpacity(0.1),
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFE040FB), Color(0xFFFF5252)],
                      ),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Icon(
                      Icons.bolt_rounded,
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Unlock PRO',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Get unlimited access to all trending data',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.1),
                      ),
                    ),
                    child: TextField(
                      controller: codeController,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        letterSpacing: 4,
                      ),
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        hintText: 'Enter code',
                        hintStyle: TextStyle(
                          color: Colors.white.withOpacity(0.2),
                          letterSpacing: 2,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.all(16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  GestureDetector(
                    onTap: () async {
                      if (PremiumManager.validateCode(codeController.text.trim())) {
                        await PremiumManager.activate();
                        if (context.mounted) {
                          Navigator.pop(context);
                          setState(() {});
                          ScaffoldMessenger.of(this.context).showSnackBar(
                            SnackBar(
                              content: const Text('PRO activated! 🔥'),
                              backgroundColor: const Color(0xFFE040FB),
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          );
                        }
                      } else {
                        if (context.mounted) {
                          ScaffoldMessenger.of(this.context).showSnackBar(
                            SnackBar(
                              content: const Text('Invalid code'),
                              backgroundColor: Colors.red,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          );
                        }
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE040FB), Color(0xFFFF5252)],
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Text(
                        'Activate PRO',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ReelDetailPage extends StatelessWidget {
  final Map<String, dynamic> reel;
  const ReelDetailPage({super.key, required this.reel});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildReelPreview(),
                    const SizedBox(height: 16),
                    _buildCreatorInfo(),
                    const SizedBox(height: 16),
                    _buildCaptionSection(),
                    const SizedBox(height: 16),
                    _buildStatsGrid(),
                    const SizedBox(height: 16),
                    _buildGrowthInsight(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.12)),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: Colors.white.withOpacity(0.9), size: 20),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              'Reel Details',
              style: TextStyle(
                color: Colors.white.withOpacity(0.9),
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: reel['caption'] as String));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Caption copied!'),
                  backgroundColor: const Color(0xFFE040FB),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              );
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withOpacity(0.12)),
                ),
                child: Icon(Icons.copy_rounded, color: Colors.white.withOpacity(0.9), size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReelPreview() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 280,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFFE040FB).withOpacity(0.15),
              const Color(0xFFFF5252).withOpacity(0.1),
              const Color(0xFFFFAB40).withOpacity(0.08),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(Icons.play_circle_fill_rounded, size: 64, color: Colors.white.withOpacity(0.3)),
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  reel['category'] as String,
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCreatorInfo() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFE040FB), Color(0xFFFF5252), Color(0xFFFFAB40)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Text(
                    (reel['creator'] as String).substring(1, 3).toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      reel['creator'] as String,
                      style: TextStyle(color: Colors.white.withOpacity(0.95), fontWeight: FontWeight.w700, fontSize: 16),
                    ),
                    Text(
                      '${reel['daysAgo']} days ago',
                      style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF00E676).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  reel['growthRate'] as String,
                  style: const TextStyle(color: Color(0xFF00E676), fontWeight: FontWeight.w700, fontSize: 13),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCaptionSection() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Caption',
                style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                reel['caption'] as String,
                style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 16, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsGrid() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Performance',
                style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  _statTile(Icons.play_circle_outline_rounded, 'Views', reel['views'] as String),
                  const SizedBox(width: 10),
                  _statTile(Icons.favorite_outline_rounded, 'Likes', reel['likes'] as String),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  _statTile(Icons.chat_bubble_outline_rounded, 'Comments', reel['comments'] as String),
                  const SizedBox(width: 10),
                  _statTile(Icons.share_outlined, 'Shares', reel['shares'] as String),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statTile(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 20, color: Colors.white.withOpacity(0.4)),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(color: Colors.white.withOpacity(0.95), fontWeight: FontWeight.w700, fontSize: 18),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGrowthInsight() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFE040FB).withOpacity(0.1),
                const Color(0xFFFF5252).withOpacity(0.08),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE040FB).withOpacity(0.15)),
          ),
          child: Row(
            children: [
              const Icon(Icons.insights_rounded, color: Color(0xFFE040FB), size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Growth Insight',
                      style: TextStyle(color: Colors.white.withOpacity(0.9), fontWeight: FontWeight.w700, fontSize: 14),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'This reel grew ${reel['growthRate']} in ${reel['daysAgo']} day(s). Category: ${reel['category']}.',
                      style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12, height: 1.4),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AccountDetailPage extends StatelessWidget {
  final Map<String, dynamic> account;
  const AccountDetailPage({super.key, required this.account});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(context),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildProfileHeader(),
                    const SizedBox(height: 16),
                    _buildStatsRow(),
                    const SizedBox(height: 16),
                    _buildGrowthCard(),
                    const SizedBox(height: 16),
                    _buildContentStrategy(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.12)),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: Colors.white.withOpacity(0.9), size: 20),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              'Account Details',
              style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 18, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileHeader() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFE040FB).withOpacity(0.1),
                const Color(0xFFFF5252).withOpacity(0.08),
                const Color(0xFFFFAB40).withOpacity(0.05),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFE040FB), Color(0xFFFF5252), Color(0xFFFFAB40)],
                  ),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    (account['name'] as String).split(' ').map((w) => w[0]).take(2).join(),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 26),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                account['name'] as String,
                style: TextStyle(color: Colors.white.withOpacity(0.95), fontWeight: FontWeight.w800, fontSize: 22),
              ),
              const SizedBox(height: 4),
              Text(
                account['username'] as String,
                style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 15),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [const Color(0xFFE040FB).withOpacity(0.2), const Color(0xFFFF5252).withOpacity(0.2)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  account['niche'] as String,
                  style: const TextStyle(color: Color(0xFFE040FB), fontWeight: FontWeight.w600, fontSize: 13),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(
      children: [
        _buildStatCard('Followers', account['followers'] as String, Icons.people_outline_rounded),
        const SizedBox(width: 10),
        _buildStatCard('Gained', account['followersGained'] as String, Icons.trending_up_rounded),
        const SizedBox(width: 10),
        _buildStatCard('Avg Views', account['avgViews'] as String, Icons.visibility_outlined),
      ],
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon) {
    return Expanded(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
            ),
            child: Column(
              children: [
                Icon(icon, size: 22, color: Colors.white.withOpacity(0.4)),
                const SizedBox(height: 8),
                Text(
                  value,
                  style: TextStyle(color: Colors.white.withOpacity(0.95), fontWeight: FontWeight.w700, fontSize: 16),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGrowthCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Growth Summary',
                style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 16),
              _growthRow('Followers Gained', account['followersGained'] as String),
              const SizedBox(height: 12),
              _growthRow('Timeframe', account['timeframe'] as String),
              const SizedBox(height: 12),
              _growthRow('Engagement Rate', account['engagementRate'] as String),
              const SizedBox(height: 12),
              _growthRow('Avg Views/Reel', account['avgViews'] as String),
            ],
          ),
        ),
      ),
    );
  }

  Widget _growthRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 14)),
        Text(value, style: TextStyle(color: Colors.white.withOpacity(0.95), fontWeight: FontWeight.w700, fontSize: 14)),
      ],
    );
  }

  Widget _buildContentStrategy() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFE040FB).withOpacity(0.1),
                const Color(0xFFFF5252).withOpacity(0.08),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE040FB).withOpacity(0.15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFAB40), size: 22),
                  const SizedBox(width: 10),
                  Text(
                    'Content Strategy',
                    style: TextStyle(color: Colors.white.withOpacity(0.9), fontWeight: FontWeight.w700, fontSize: 16),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'Top performing content: ${account['topContent']}',
                style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 14, height: 1.5),
              ),
              const SizedBox(height: 8),
              Text(
                'This account gained ${account['followersGained']} followers in just ${account['timeframe']} with ${account['engagementRate']} engagement rate — significantly above average.',
                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

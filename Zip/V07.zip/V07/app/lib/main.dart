import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'dart:math';
import 'dart:async';

const Color kLime = Color(0xFFC5E84D);
const Color kLimeDark = Color(0xFFAACC30);
const Color kLimeText = Color(0xFF1A2E05);
const Color kBg = Color(0xFF0A0A0A);
const Color kCard = Color(0xFF131313);
const Color kSurface = Color(0xFF161616);
const Color kBorder = Color(0x0DFFFFFF);

const String kApiUrl = 'https://development.avsvishalmedia.com/viralhook/data.json';

String _s(dynamic v, [String fallback = '']) {
  if (v == null) return fallback;
  return v.toString();
}

int _i(dynamic v, [int fallback = 0]) {
  if (v == null) return fallback;
  if (v is int) return v;
  return int.tryParse(v.toString()) ?? fallback;
}

double _viewsToNum(String views) {
  try {
    final clean = views.replaceAll(RegExp(r'[^0-9.]'), '');
    if (clean.isEmpty) return 0;
    return double.parse(clean);
  } catch (_) {
    return 0;
  }
}

Color _parseColor(dynamic v, Color fallback) {
  if (v == null) return fallback;
  if (v is Color) return v;
  try {
    final s = v.toString();
    final hex = s.replaceAll('0x', '').replaceAll('#', '');
    if (hex.length < 6) return fallback;
    return Color(int.parse(hex, radix: 16));
  } catch (_) {
    return fallback;
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PremiumManager.init();
  runApp(const TrendHookApp());
}

class TrendHookApp extends StatelessWidget {
  const TrendHookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TREND HOOK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        primaryColor: kCard,
      ),
      home: const HomePage(),
    );
  }
}

class PremiumManager {
  static bool _isPremium = false;
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      _isPremium = _prefs?.getBool('premium') ?? false;
    } catch (_) {
      _isPremium = false;
    }
  }

  static bool get isPremium => _isPremium;

  static Future<void> activate() async {
    _isPremium = true;
    try {
      await _prefs?.setBool('premium', true);
    } catch (_) {}
  }

  static bool validateCode(String code) {
    return code == '000';
  }
}

class DemoData {
  static Map<String, List<Map<String, dynamic>>> get reels => {
    'Entertainment': [
      {'creator': '@viralking', 'initials': 'VK', 'caption': 'This magic trick broke the internet', 'views': '12.5M', 'likes': '1.8M', 'comments': '45.2K', 'shares': '320K', 'growthRate': '+540%', 'daysAgo': 2, 'hoursAgo': '3h', 'category': 'Entertainment', 'isLoaded': true, 'color1': const Color(0xFF6C5CE7), 'color2': const Color(0xFFA29BFE)},
      {'creator': '@funfactsdaily', 'initials': 'FF', 'caption': 'Facts that will blow your mind', 'views': '8.3M', 'likes': '920K', 'comments': '28.1K', 'shares': '180K', 'growthRate': '+320%', 'daysAgo': 1, 'hoursAgo': '6h', 'category': 'Entertainment', 'isLoaded': false, 'color1': const Color(0xFFE17055), 'color2': const Color(0xFFFF7675)},
      {'creator': '@dancemoves', 'initials': 'DM', 'caption': 'New dance challenge everyone is doing', 'views': '15.1M', 'likes': '2.1M', 'comments': '67K', 'shares': '450K', 'growthRate': '+890%', 'daysAgo': 1, 'hoursAgo': '1h', 'category': 'Entertainment', 'isLoaded': true, 'color1': const Color(0xFFC5E84D), 'color2': const Color(0xFFAACC30)},
    ],
    'Comedy': [
      {'creator': '@laughoutloud', 'initials': 'LL', 'caption': 'POV: When your mom finds your report card', 'views': '9.7M', 'likes': '1.5M', 'comments': '52K', 'shares': '280K', 'growthRate': '+410%', 'daysAgo': 1, 'hoursAgo': '2h', 'category': 'Comedy', 'isLoaded': true, 'color1': const Color(0xFFFD79A8), 'color2': const Color(0xFFE84393)},
      {'creator': '@comedycentral_clips', 'initials': 'CC', 'caption': 'This standup bit went viral overnight', 'views': '6.2M', 'likes': '780K', 'comments': '19K', 'shares': '140K', 'growthRate': '+280%', 'daysAgo': 3, 'hoursAgo': '12h', 'category': 'Comedy', 'isLoaded': false, 'color1': const Color(0xFF00B894), 'color2': const Color(0xFF55EFC4)},
      {'creator': '@pranksters', 'initials': 'PR', 'caption': 'Prank gone wholesome', 'views': '11.4M', 'likes': '1.9M', 'comments': '41K', 'shares': '390K', 'growthRate': '+620%', 'daysAgo': 2, 'hoursAgo': '5h', 'category': 'Comedy', 'isLoaded': true, 'color1': const Color(0xFFFF7675), 'color2': const Color(0xFFD63031)},
    ],
    'Education': [
      {'creator': '@sciencewithsam', 'initials': 'SS', 'caption': 'Why the sky is actually violet not blue', 'views': '5.8M', 'likes': '640K', 'comments': '15K', 'shares': '210K', 'growthRate': '+350%', 'daysAgo': 2, 'hoursAgo': '8h', 'category': 'Education', 'isLoaded': true, 'color1': const Color(0xFF0984E3), 'color2': const Color(0xFF74B9FF)},
      {'creator': '@historybuff', 'initials': 'HB', 'caption': 'The real story they never taught in school', 'views': '7.1M', 'likes': '890K', 'comments': '32K', 'shares': '260K', 'growthRate': '+470%', 'daysAgo': 1, 'hoursAgo': '4h', 'category': 'Education', 'isLoaded': false, 'color1': const Color(0xFFFDAB40), 'color2': const Color(0xFFFCCB69)},
      {'creator': '@mathgenius', 'initials': 'MG', 'caption': 'Solve this in 5 seconds if you can', 'views': '4.2M', 'likes': '520K', 'comments': '48K', 'shares': '95K', 'growthRate': '+190%', 'daysAgo': 3, 'hoursAgo': '16h', 'category': 'Education', 'isLoaded': true, 'color1': const Color(0xFF6C5CE7), 'color2': const Color(0xFFA29BFE)},
    ],
    'Fitness': [
      {'creator': '@fitnessguru', 'initials': 'FG', 'caption': '30-day transformation that shocked everyone', 'views': '10.3M', 'likes': '1.3M', 'comments': '38K', 'shares': '310K', 'growthRate': '+560%', 'daysAgo': 1, 'hoursAgo': '1h', 'category': 'Fitness', 'isLoaded': true, 'color1': const Color(0xFF00B894), 'color2': const Color(0xFF55EFC4)},
      {'creator': '@yogawithme', 'initials': 'YW', 'caption': '5-minute morning routine for energy', 'views': '3.9M', 'likes': '480K', 'comments': '12K', 'shares': '170K', 'growthRate': '+240%', 'daysAgo': 2, 'hoursAgo': '9h', 'category': 'Fitness', 'isLoaded': false, 'color1': const Color(0xFFC5E84D), 'color2': const Color(0xFFAACC30)},
    ],
    'Food': [
      {'creator': '@chefmaster', 'initials': 'CM', 'caption': '60-second recipe that went mega viral', 'views': '14.2M', 'likes': '2.3M', 'comments': '56K', 'shares': '480K', 'growthRate': '+720%', 'daysAgo': 1, 'hoursAgo': '1h', 'category': 'Food', 'isLoaded': true, 'color1': const Color(0xFFE17055), 'color2': const Color(0xFFFF7675)},
      {'creator': '@streetfoodlover', 'initials': 'SF', 'caption': 'Best street food you have never tried', 'views': '8.9M', 'likes': '1.1M', 'comments': '34K', 'shares': '290K', 'growthRate': '+490%', 'daysAgo': 2, 'hoursAgo': '7h', 'category': 'Food', 'isLoaded': true, 'color1': const Color(0xFFFDAB40), 'color2': const Color(0xFFFCCB69)},
    ],
    'Tech': [
      {'creator': '@techbytes', 'initials': 'TB', 'caption': 'iPhone hidden feature 99% dont know', 'views': '11.8M', 'likes': '1.6M', 'comments': '43K', 'shares': '350K', 'growthRate': '+580%', 'daysAgo': 1, 'hoursAgo': '2h', 'category': 'Tech', 'isLoaded': true, 'color1': const Color(0xFF0984E3), 'color2': const Color(0xFF74B9FF)},
      {'creator': '@aiupdates', 'initials': 'AI', 'caption': 'This AI tool replaces 10 apps at once', 'views': '7.4M', 'likes': '910K', 'comments': '27K', 'shares': '240K', 'growthRate': '+430%', 'daysAgo': 2, 'hoursAgo': '5h', 'category': 'Tech', 'isLoaded': false, 'color1': const Color(0xFF6C5CE7), 'color2': const Color(0xFFA29BFE)},
    ],
    'Fashion': [
      {'creator': '@styleicon', 'initials': 'SI', 'caption': 'Outfit ideas that are trending right now', 'views': '9.1M', 'likes': '1.2M', 'comments': '36K', 'shares': '270K', 'growthRate': '+460%', 'daysAgo': 1, 'hoursAgo': '1h', 'category': 'Fashion', 'isLoaded': true, 'color1': const Color(0xFFC5E84D), 'color2': const Color(0xFFAACC30)},
      {'creator': '@thriftflips', 'initials': 'TF', 'caption': 'Thrift flip into designer look', 'views': '6.5M', 'likes': '810K', 'comments': '25K', 'shares': '190K', 'growthRate': '+370%', 'daysAgo': 2, 'hoursAgo': '8h', 'category': 'Fashion', 'isLoaded': true, 'color1': const Color(0xFFFD79A8), 'color2': const Color(0xFFE84393)},
    ],
    'Travel': [
      {'creator': '@wanderlust', 'initials': 'WL', 'caption': 'Hidden paradise no one talks about', 'views': '13.6M', 'likes': '2.0M', 'comments': '51K', 'shares': '420K', 'growthRate': '+670%', 'daysAgo': 1, 'hoursAgo': '1h', 'category': 'Travel', 'isLoaded': true, 'color1': const Color(0xFF00B894), 'color2': const Color(0xFF55EFC4)},
      {'creator': '@budgettravel', 'initials': 'BT', 'caption': 'Full trip in 5000rs complete guide', 'views': '7.8M', 'likes': '960K', 'comments': '29K', 'shares': '310K', 'growthRate': '+440%', 'daysAgo': 2, 'hoursAgo': '6h', 'category': 'Travel', 'isLoaded': false, 'color1': const Color(0xFFFDAB40), 'color2': const Color(0xFFFCCB69)},
    ],
  };

  static List<Map<String, dynamic>> get accounts => [
    {'username': '@risewithraj', 'name': 'Raj Sharma', 'initials': 'RS', 'niche': 'Motivation', 'followers': '1.2M', 'followersGained': '+800K', 'timeframe': '30 days', 'avgViews': '5.2M', 'engagementRate': '18.5%', 'topContent': 'Morning routine reels', 'color1': const Color(0xFFC5E84D), 'color2': const Color(0xFFAACC30)},
    {'username': '@cookwithneha', 'name': 'Neha Patel', 'initials': 'NP', 'niche': 'Food', 'followers': '890K', 'followersGained': '+650K', 'timeframe': '45 days', 'avgViews': '3.8M', 'engagementRate': '22.1%', 'topContent': 'Quick recipe shorts', 'color1': const Color(0xFFE17055), 'color2': const Color(0xFFFF7675)},
    {'username': '@techsavvy_arjun', 'name': 'Arjun Mehta', 'initials': 'AM', 'niche': 'Tech', 'followers': '2.1M', 'followersGained': '+1.5M', 'timeframe': '60 days', 'avgViews': '8.4M', 'engagementRate': '15.8%', 'topContent': 'AI tool reviews', 'color1': const Color(0xFF0984E3), 'color2': const Color(0xFF74B9FF)},
    {'username': '@fitlife_priya', 'name': 'Priya Singh', 'initials': 'PS', 'niche': 'Fitness', 'followers': '670K', 'followersGained': '+520K', 'timeframe': '25 days', 'avgViews': '2.9M', 'engagementRate': '24.3%', 'topContent': 'Home workout challenges', 'color1': const Color(0xFF00B894), 'color2': const Color(0xFF55EFC4)},
    {'username': '@travelvibe_sam', 'name': 'Sam Wilson', 'initials': 'SW', 'niche': 'Travel', 'followers': '1.5M', 'followersGained': '+1.1M', 'timeframe': '50 days', 'avgViews': '6.1M', 'engagementRate': '19.7%', 'topContent': 'Hidden gems reels', 'color1': const Color(0xFF6C5CE7), 'color2': const Color(0xFFA29BFE)},
    {'username': '@fashionbyriya', 'name': 'Riya Kapoor', 'initials': 'RK', 'niche': 'Fashion', 'followers': '980K', 'followersGained': '+720K', 'timeframe': '35 days', 'avgViews': '4.5M', 'engagementRate': '20.9%', 'topContent': 'Budget outfit ideas', 'color1': const Color(0xFFFD79A8), 'color2': const Color(0xFFE84393)},
    {'username': '@comedyking_amit', 'name': 'Amit Kumar', 'initials': 'AK', 'niche': 'Comedy', 'followers': '3.2M', 'followersGained': '+2.4M', 'timeframe': '40 days', 'avgViews': '11.2M', 'engagementRate': '16.4%', 'topContent': 'Relatable comedy skits', 'color1': const Color(0xFFFF7675), 'color2': const Color(0xFFD63031)},
    {'username': '@learnwithlisa', 'name': 'Lisa Chen', 'initials': 'LC', 'niche': 'Education', 'followers': '450K', 'followersGained': '+380K', 'timeframe': '20 days', 'avgViews': '2.1M', 'engagementRate': '26.8%', 'topContent': 'Study hack reels', 'color1': const Color(0xFFFDAB40), 'color2': const Color(0xFFFCCB69)},
  ];
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int selectedSection = 0;
  String selectedCategory = 'All';
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  bool _isLoading = true;
  bool _usingDemo = false;

  final List<Map<String, dynamic>> categories = [
    {'name': 'All', 'icon': Icons.grid_view_rounded},
    {'name': 'Entertainment', 'icon': Icons.movie_filter_rounded},
    {'name': 'Comedy', 'icon': Icons.sentiment_very_satisfied_rounded},
    {'name': 'Education', 'icon': Icons.school_rounded},
    {'name': 'Fitness', 'icon': Icons.fitness_center_rounded},
    {'name': 'Food', 'icon': Icons.restaurant_rounded},
    {'name': 'Tech', 'icon': Icons.devices_rounded},
    {'name': 'Fashion', 'icon': Icons.checkroom_rounded},
    {'name': 'Travel', 'icon': Icons.flight_rounded},
  ];

  Map<String, List<Map<String, dynamic>>> trendingReels = {};
  List<Map<String, dynamic>> explodingAccounts = [];

  List<Map<String, dynamic>> get filteredReels {
    try {
      final query = _searchController.text.toLowerCase();
      List<Map<String, dynamic>> reels;
      if (selectedCategory == 'All') {
        reels = [];
        trendingReels.forEach((key, value) {
          reels.addAll(value);
        });
        reels.sort((a, b) {
          final numA = _viewsToNum(_s(a['views'], '0'));
          final numB = _viewsToNum(_s(b['views'], '0'));
          return numB.compareTo(numA);
        });
      } else {
        reels = List<Map<String, dynamic>>.from(trendingReels[selectedCategory] ?? []);
      }
      if (query.isEmpty) return reels;
      return reels.where((r) {
        final creator = _s(r['creator']).toLowerCase();
        final caption = _s(r['caption']).toLowerCase();
        return creator.contains(query) || caption.contains(query);
      }).toList();
    } catch (_) {
      return [];
    }
  }

  List<Map<String, dynamic>> get filteredAccounts {
    try {
      final query = _searchController.text.toLowerCase();
      if (query.isEmpty) return explodingAccounts;
      return explodingAccounts.where((a) {
        final username = _s(a['username']).toLowerCase();
        final name = _s(a['name']).toLowerCase();
        final niche = _s(a['niche']).toLowerCase();
        return username.contains(query) || name.contains(query) || niche.contains(query);
      }).toList();
    } catch (_) {
      return [];
    }
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (mounted) setState(() => selectedSection = _tabController.index);
    });
    _searchController.addListener(() {
      if (mounted) setState(() {});
    });
    _loadData();
  }

  void _loadDemoData() {
    trendingReels = DemoData.reels;
    explodingAccounts = DemoData.accounts;
    _usingDemo = true;
  }

  Future<void> _loadData() async {
    if (mounted) setState(() => _isLoading = true);
    try {
      final response = await http.get(Uri.parse(kApiUrl)).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final body = response.body;
        if (body.isEmpty) {
          _loadDemoData();
        } else {
          _parseApiData(body);
        }
      } else {
        _loadDemoData();
      }
    } catch (_) {
      _loadDemoData();
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _parseApiData(String body) {
    try {
      final data = json.decode(body);
      if (data == null || data is! Map) {
        _loadDemoData();
        return;
      }

      final dynamic reelsRaw = data['trendingReels'];
      if (reelsRaw != null && reelsRaw is Map) {
        final Map<String, List<Map<String, dynamic>>> parsedReels = {};
        reelsRaw.forEach((key, value) {
          if (value is List) {
            final String catKey = key.toString();
            final List<Map<String, dynamic>> parsed = [];
            for (var r in value) {
              try {
                if (r is Map) {
                  final reel = Map<String, dynamic>.from(r);
                  reel['color1'] = _parseColor(reel['color1'], const Color(0xFF6C5CE7));
                  reel['color2'] = _parseColor(reel['color2'], const Color(0xFFA29BFE));
                  reel['isLoaded'] = Random().nextBool();
                  reel['daysAgo'] = _i(reel['daysAgo']);
                  reel['creator'] = _s(reel['creator'], '@unknown');
                  reel['initials'] = _s(reel['initials'], '??');
                  reel['caption'] = _s(reel['caption'], 'Trending reel');
                  reel['views'] = _s(reel['views'], '0');
                  reel['likes'] = _s(reel['likes'], '0');
                  reel['comments'] = _s(reel['comments'], '0');
                  reel['shares'] = _s(reel['shares'], '0');
                  reel['growthRate'] = _s(reel['growthRate'], '+0%');
                  reel['hoursAgo'] = _s(reel['hoursAgo'], '0h');
                  reel['category'] = _s(reel['category'], catKey);
                  parsed.add(reel);
                }
              } catch (_) {}
            }
            if (parsed.isNotEmpty) parsedReels[catKey] = parsed;
          }
        });
        if (parsedReels.isNotEmpty) {
          trendingReels = parsedReels;
          _usingDemo = false;
        } else {
          trendingReels = DemoData.reels;
          _usingDemo = true;
        }
      } else {
        trendingReels = DemoData.reels;
        _usingDemo = true;
      }

      final dynamic accountsRaw = data['explodingAccounts'];
      if (accountsRaw != null && accountsRaw is List && accountsRaw.isNotEmpty) {
        final List<Map<String, dynamic>> parsedAccounts = [];
        for (var a in accountsRaw) {
          try {
            if (a is Map) {
              final account = Map<String, dynamic>.from(a);
              account['color1'] = _parseColor(account['color1'], const Color(0xFFC5E84D));
              account['color2'] = _parseColor(account['color2'], const Color(0xFFAACC30));
              account['username'] = _s(account['username'], '@unknown');
              account['name'] = _s(account['name'], 'Unknown');
              account['initials'] = _s(account['initials'], '??');
              account['niche'] = _s(account['niche'], 'General');
              account['followers'] = _s(account['followers'], '0');
              account['followersGained'] = _s(account['followersGained'], '+0');
              account['timeframe'] = _s(account['timeframe'], '30 days');
              account['avgViews'] = _s(account['avgViews'], '0');
              account['engagementRate'] = _s(account['engagementRate'], '0%');
              account['topContent'] = _s(account['topContent'], 'Content');
              parsedAccounts.add(account);
            }
          } catch (_) {}
        }
        explodingAccounts = parsedAccounts.isNotEmpty ? parsedAccounts : DemoData.accounts;
      } else {
        explodingAccounts = DemoData.accounts;
      }
    } catch (_) {
      _loadDemoData();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 6),
            _buildTopBar(),
            const SizedBox(height: 14),
            _buildSearchBar(),
            const SizedBox(height: 14),
            _buildSectionTabs(),
            if (selectedSection == 0) ...[
              const SizedBox(height: 14),
              _buildCategoryChips(),
            ],
            const SizedBox(height: 14),
            Expanded(
              child: _isLoading
                  ? _buildLoadingState()
                  : RefreshIndicator(
                      color: kLime,
                      backgroundColor: kCard,
                      onRefresh: _loadData,
                      child: selectedSection == 0
                          ? _buildReelsGrid()
                          : _buildAccountsList(),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 40,
            height: 40,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              valueColor: AlwaysStoppedAnimation<Color>(kLime),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'Loading trends...',
            style: TextStyle(
              color: Colors.white.withOpacity(0.35),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder, width: 0.5),
              ),
              child: Icon(Icons.menu_rounded, color: Colors.white.withOpacity(0.85), size: 20),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Row(
              children: [
                const Text('TREND', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.5)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.local_fire_department_rounded, color: kLimeText, size: 16),
                      const SizedBox(width: 3),
                      const Text('HOOK', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: kLimeText, letterSpacing: 1.2)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (_usingDemo)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.orange.withOpacity(0.3)),
              ),
              child: const Text('DEMO', style: TextStyle(color: Colors.orange, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
            ),
          if (PremiumManager.isPremium)
            Padding(
              padding: const EdgeInsets.only(left: 6),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(8)),
                child: const Text('PRO', style: TextStyle(color: kLimeText, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 46,
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Row(
          children: [
            const SizedBox(width: 14),
            Icon(Icons.search_rounded, color: Colors.white.withOpacity(0.3), size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14, fontWeight: FontWeight.w400),
                decoration: InputDecoration(
                  hintText: 'Search trending reels & creators',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.22), fontSize: 14, fontWeight: FontWeight.w400),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: TabBar(
          controller: _tabController,
          indicator: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(10)),
          indicatorSize: TabBarIndicatorSize.tab,
          labelColor: kLimeText,
          unselectedLabelColor: Colors.white.withOpacity(0.35),
          labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
          dividerColor: Colors.transparent,
          indicatorPadding: const EdgeInsets.all(3),
          tabs: const [Tab(text: 'Trending Reels'), Tab(text: 'Rising Creators')],
        ),
      ),
    );
  }

  Widget _buildCategoryChips() {
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final cat = categories[index];
          final isSelected = selectedCategory == cat['name'];
          return GestureDetector(
            onTap: () => setState(() => selectedCategory = _s(cat['name'], 'All')),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: isSelected ? kLime : kSurface,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: isSelected ? kLime : kBorder, width: isSelected ? 1.5 : 0.5),
              ),
              child: Row(
                children: [
                  Icon(cat['icon'] as IconData, size: 15, color: isSelected ? kLimeText : Colors.white.withOpacity(0.35)),
                  const SizedBox(width: 6),
                  Text(
                    _s(cat['name']),
                    style: TextStyle(fontSize: 12, fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500, color: isSelected ? kLimeText : Colors.white.withOpacity(0.45)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildReelsGrid() {
    final reels = filteredReels;
    if (reels.isEmpty) {
      return ListView(children: [
        SizedBox(height: MediaQuery.of(context).size.height * 0.2),
        Center(child: Icon(Icons.search_off_rounded, size: 48, color: Colors.white.withOpacity(0.15))),
        const SizedBox(height: 12),
        Center(child: Text('No reels found', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 15, fontWeight: FontWeight.w600))),
      ]);
    }
    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.68),
      itemCount: reels.length,
      itemBuilder: (context, index) {
        final reel = reels[index];
        return _ReelCard(
          reel: reel,
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => ReelDetailPage(reel: reel)));
          },
        );
      },
    );
  }

  Widget _buildAccountsList() {
    final accounts = filteredAccounts;
    if (accounts.isEmpty) {
      return ListView(children: [
        SizedBox(height: MediaQuery.of(context).size.height * 0.2),
        Center(child: Icon(Icons.search_off_rounded, size: 48, color: Colors.white.withOpacity(0.15))),
        const SizedBox(height: 12),
        Center(child: Text('No accounts found', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 15, fontWeight: FontWeight.w600))),
      ]);
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: accounts.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final account = accounts[index];
        final c1 = (account['color1'] is Color) ? account['color1'] as Color : _parseColor(account['color1'], const Color(0xFFC5E84D));
        final c2 = (account['color2'] is Color) ? account['color2'] as Color : _parseColor(account['color2'], const Color(0xFFAACC30));
        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AccountDetailPage(account: account))),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: kBorder, width: 0.5)),
            child: Row(
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(gradient: LinearGradient(colors: [c1, c2]), borderRadius: BorderRadius.circular(14)),
                  child: Center(child: Text(_s(account['initials'], '??'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_s(account['name'], 'Unknown'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15, letterSpacing: -0.2)),
                      const SizedBox(height: 2),
                      Text(_s(account['username']), style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12)),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: kLime.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(_s(account['niche']), style: TextStyle(color: kLime.withOpacity(0.8), fontSize: 10, fontWeight: FontWeight.w600)),
                          ),
                          const SizedBox(width: 8),
                          Icon(Icons.people_outline_rounded, size: 12, color: Colors.white.withOpacity(0.25)),
                          const SizedBox(width: 3),
                          Text(_s(account['followers']), style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11, fontWeight: FontWeight.w500)),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(_s(account['followersGained']), style: const TextStyle(color: kLime, fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: -0.3)),
                    const SizedBox(height: 2),
                    Text(_s(account['timeframe']), style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 10)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const Text('TREND', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1)),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(8)),
                    child: const Text('HOOK', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: kLimeText, letterSpacing: 1)),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: Colors.white.withOpacity(0.04)),
            _drawerItem(Icons.trending_up_rounded, 'Trending', true),
            _drawerItem(Icons.explore_rounded, 'Discover', false),
            _drawerItem(Icons.bookmark_outline_rounded, 'Saved', false),
            Divider(height: 1, color: Colors.white.withOpacity(0.04)),
            const Spacer(),
            if (!PremiumManager.isPremium)
              Padding(
                padding: const EdgeInsets.all(20),
                child: GestureDetector(
                  onTap: _showPremiumDialog,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: kLime.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: kLime.withOpacity(0.15)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Icon(Icons.workspace_premium_rounded, color: kLime, size: 20),
                          const SizedBox(width: 8),
                          Text('Go Premium', style: TextStyle(color: kLime, fontWeight: FontWeight.w700, fontSize: 15)),
                        ]),
                        const SizedBox(height: 6),
                        Text('Unlock all features', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12)),
                      ],
                    ),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Text('V1.0.7', style: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 11)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, bool isActive) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(color: isActive ? kLime.withOpacity(0.08) : Colors.transparent, borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: isActive ? kLime : Colors.white.withOpacity(0.3), size: 22),
        title: Text(label, style: TextStyle(color: isActive ? kLime : Colors.white.withOpacity(0.5), fontWeight: isActive ? FontWeight.w700 : FontWeight.w400, fontSize: 14)),
        dense: true,
        visualDensity: const VisualDensity(vertical: -1),
      ),
    );
  }

  void _showPremiumDialog() {
    final codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(color: kLime.withOpacity(0.1), borderRadius: BorderRadius.circular(16)),
                child: Icon(Icons.workspace_premium_rounded, color: kLime, size: 28),
              ),
              const SizedBox(height: 16),
              const Text('Enter Premium Code', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 18),
              Container(
                decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                child: TextField(
                  controller: codeController,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 4),
                  decoration: InputDecoration(hintText: 'CODE', hintStyle: TextStyle(color: Colors.white.withOpacity(0.15)), border: InputBorder.none, contentPadding: const EdgeInsets.all(16)),
                ),
              ),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: () async {
                  if (PremiumManager.validateCode(codeController.text.trim())) {
                    await PremiumManager.activate();
                    if (ctx.mounted) Navigator.pop(ctx);
                    if (mounted) setState(() {});
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: const Text('Premium activated!', style: TextStyle(fontWeight: FontWeight.w600)),
                        backgroundColor: kLime, behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ));
                    }
                  } else {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: const Text('Invalid code', style: TextStyle(fontWeight: FontWeight.w600)),
                        backgroundColor: Colors.red, behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ));
                    }
                  }
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(12)),
                  child: const Center(child: Text('Activate', style: TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 15))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReelCard extends StatefulWidget {
  final Map<String, dynamic> reel;
  final VoidCallback onTap;
  const _ReelCard({required this.reel, required this.onTap});
  @override
  State<_ReelCard> createState() => _ReelCardState();
}

class _ReelCardState extends State<_ReelCard> with SingleTickerProviderStateMixin {
  late AnimationController _shimmerController;

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500));
    if (widget.reel['isLoaded'] != true) {
      _shimmerController.repeat();
    }
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reel = widget.reel;
    final c1 = (reel['color1'] is Color) ? reel['color1'] as Color : _parseColor(reel['color1'], const Color(0xFF6C5CE7));
    final c2 = (reel['color2'] is Color) ? reel['color2'] as Color : _parseColor(reel['color2'], const Color(0xFFA29BFE));
    final isLoaded = reel['isLoaded'] == true;

    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: kBorder, width: 0.5)),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [c1, c2, c1.withOpacity(0.8)]))),
              if (!isLoaded)
                AnimatedBuilder(
                  animation: _shimmerController,
                  builder: (context, child) {
                    final v = _shimmerController.value;
                    return BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 12 + (sin(v * pi * 2) * 4), sigmaY: 12 + (sin(v * pi * 2) * 4)),
                      child: Container(color: Colors.black.withOpacity(0.15 + (v * 0.1))),
                    );
                  },
                ),
              Positioned(
                bottom: 0, left: 0, right: 0,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black.withOpacity(0.85), Colors.black.withOpacity(0.0)])),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(children: [
                        Container(
                          width: 24, height: 24,
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(7)),
                          child: Center(child: Text(_s(reel['initials'], '??'), style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w800))),
                        ),
                        const SizedBox(width: 6),
                        Expanded(child: Text(_s(reel['creator']), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 11), overflow: TextOverflow.ellipsis)),
                      ]),
                      const SizedBox(height: 6),
                      Text(_s(reel['caption']), style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11, fontWeight: FontWeight.w400, height: 1.3), maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 8),
                      Row(children: [
                        Icon(Icons.visibility_outlined, size: 11, color: Colors.white.withOpacity(0.5)),
                        const SizedBox(width: 3),
                        Text(_s(reel['views']), style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10, fontWeight: FontWeight.w600)),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: kLime.withOpacity(0.9), borderRadius: BorderRadius.circular(5)),
                          child: Text(_s(reel['growthRate']), style: const TextStyle(color: kLimeText, fontSize: 9, fontWeight: FontWeight.w800)),
                        ),
                      ]),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 8, right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(6)),
                  child: Text(_s(reel['hoursAgo']), style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ReelDetailPage extends StatelessWidget {
  final Map<String, dynamic> reel;
  const ReelDetailPage({super.key, required this.reel});

  @override
  Widget build(BuildContext context) {
    final c1 = (reel['color1'] is Color) ? reel['color1'] as Color : _parseColor(reel['color1'], const Color(0xFF6C5CE7));
    final c2 = (reel['color2'] is Color) ? reel['color2'] as Color : _parseColor(reel['color2'], const Color(0xFFA29BFE));

    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300, pinned: true, backgroundColor: kBg,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [c1, c2, kBg])),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      Container(
                        width: 72, height: 72,
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                        child: Center(child: Text(_s(reel['initials'], '??'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 24))),
                      ),
                      const SizedBox(height: 14),
                      Text(_s(reel['creator']), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20, letterSpacing: -0.3)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(8)),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.local_fire_department_rounded, size: 14, color: kLimeText),
                            const SizedBox(width: 4),
                            Text(_s(reel['category']), style: const TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: kBorder, width: 0.5)),
                    child: Text(_s(reel['caption']), style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 16, fontWeight: FontWeight.w500, height: 1.5)),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [_statCard('Views', _s(reel['views']), Icons.visibility_outlined), const SizedBox(width: 8), _statCard('Likes', _s(reel['likes']), Icons.favorite_outline_rounded)]),
                  const SizedBox(height: 8),
                  Row(children: [_statCard('Comments', _s(reel['comments']), Icons.chat_bubble_outline_rounded), const SizedBox(width: 8), _statCard('Shares', _s(reel['shares']), Icons.share_outlined)]),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: kLime.withOpacity(0.06), borderRadius: BorderRadius.circular(14), border: Border.all(color: kLime.withOpacity(0.12))),
                    child: Row(children: [
                      Icon(Icons.trending_up_rounded, color: kLime, size: 22),
                      const SizedBox(width: 10),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Growth Rate', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 2),
                        Text(_s(reel['growthRate']), style: const TextStyle(color: kLime, fontWeight: FontWeight.w800, fontSize: 22, letterSpacing: -0.5)),
                      ]),
                      const Spacer(),
                      Text('Posted ${_s(reel['hoursAgo'])} ago', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12)),
                    ]),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder, width: 0.5)),
        child: Row(children: [
          Icon(icon, size: 18, color: Colors.white.withOpacity(0.3)),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 11)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16, letterSpacing: -0.3)),
          ]),
        ]),
      ),
    );
  }
}

class AccountDetailPage extends StatelessWidget {
  final Map<String, dynamic> account;
  const AccountDetailPage({super.key, required this.account});

  @override
  Widget build(BuildContext context) {
    final c1 = (account['color1'] is Color) ? account['color1'] as Color : _parseColor(account['color1'], const Color(0xFFC5E84D));
    final c2 = (account['color2'] is Color) ? account['color2'] as Color : _parseColor(account['color2'], const Color(0xFFAACC30));

    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200, pinned: true, backgroundColor: kBg,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [c1, c2, kBg]))),
            ),
          ),
          SliverToBoxAdapter(
            child: Transform.translate(
              offset: const Offset(0, -30),
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: kBorder, width: 0.5)),
                    child: Column(children: [
                      Container(
                        width: 72, height: 72,
                        decoration: BoxDecoration(gradient: LinearGradient(colors: [c1, c2]), shape: BoxShape.circle),
                        child: Center(child: Text(_s(account['initials'], '??'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 24))),
                      ),
                      const SizedBox(height: 14),
                      Text(_s(account['name'], 'Unknown').toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 0.5)),
                      const SizedBox(height: 3),
                      Text(_s(account['username']), style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 14)),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(color: kLime, borderRadius: BorderRadius.circular(10)),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.star_rounded, size: 14, color: kLimeText),
                          const SizedBox(width: 4),
                          Text(_s(account['niche']), style: const TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 12)),
                        ]),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [
                    _statCard('Followers', _s(account['followers']), Icons.people_outline_rounded),
                    const SizedBox(width: 8),
                    _statCard('Gained', _s(account['followersGained']), Icons.trending_up_rounded),
                    const SizedBox(width: 8),
                    _statCard('Avg Views', _s(account['avgViews']), Icons.visibility_outlined),
                  ]),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder, width: 0.5)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('GROWTH', style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
                      const SizedBox(height: 14),
                      _row('Followers Gained', _s(account['followersGained'])),
                      _divider(),
                      _row('Timeframe', _s(account['timeframe'])),
                      _divider(),
                      _row('Engagement Rate', _s(account['engagementRate'])),
                      _divider(),
                      _row('Avg Views/Reel', _s(account['avgViews'])),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: kLime.withOpacity(0.06), borderRadius: BorderRadius.circular(14), border: Border.all(color: kLime.withOpacity(0.12), width: 0.5)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Icon(Icons.auto_awesome_rounded, color: kLime.withOpacity(0.7), size: 18),
                        const SizedBox(width: 8),
                        Text('Content Strategy', style: TextStyle(color: Colors.white.withOpacity(0.85), fontWeight: FontWeight.w700, fontSize: 14, letterSpacing: -0.1)),
                      ]),
                      const SizedBox(height: 10),
                      Text('Top content: ${_s(account['topContent'])}', style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13, height: 1.5)),
                      const SizedBox(height: 4),
                      Text('Gained ${_s(account['followersGained'])} in ${_s(account['timeframe'])} with ${_s(account['engagementRate'])} engagement.', style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 12, height: 1.5)),
                    ]),
                  ),
                  const SizedBox(height: 20),
                ]),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder, width: 0.5)),
        child: Column(children: [
          Icon(icon, size: 18, color: Colors.white.withOpacity(0.3)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: -0.2)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 10)),
        ]),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13)),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _divider() => Divider(height: 1, color: Colors.white.withOpacity(0.04));
}

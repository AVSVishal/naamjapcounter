<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Cache-Control: public, max-age=60');

$jsonFile = __DIR__ . '/data.json';

if (file_exists($jsonFile)) {
    readfile($jsonFile);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Data not available yet. Please add content via admin panel.']);
}

<?php
session_start();
require_once __DIR__ . '/config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'login') {
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    if ($email === ADMIN_EMAIL && $pass === ADMIN_PASS) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_email'] = $email;
        header('Location: admin.php');
        exit;
    }
    $loginError = 'Invalid email or password';
}

if ($action === 'logout') {
    session_destroy();
    header('Location: admin.php');
    exit;
}

$isLoggedIn = !empty($_SESSION['admin_logged_in']);

if ($isLoggedIn && $action) {
    $pdo = getDB();
    $msg = '';

    if ($action === 'add_reel') {
        $stmt = $pdo->prepare("INSERT INTO reels (creator, initials, caption, reel_url, views, likes, comments, shares, growth_rate, days_ago, hours_ago, category_id, color1, color2) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $initials = !empty($_POST['initials']) ? $_POST['initials'] : makeInitials($_POST['creator']);
        $stmt->execute([
            $_POST['creator'], $initials, $_POST['caption'], $_POST['reel_url'] ?? '',
            $_POST['views'], $_POST['likes'], $_POST['comments'], $_POST['shares'],
            $_POST['growth_rate'], (int)$_POST['days_ago'], $_POST['hours_ago'],
            (int)$_POST['category_id'], $_POST['color1'], $_POST['color2']
        ]);
        generateJSON();
        $msg = 'Reel added successfully';
    }

    if ($action === 'update_reel') {
        $stmt = $pdo->prepare("UPDATE reels SET creator=?, initials=?, caption=?, reel_url=?, views=?, likes=?, comments=?, shares=?, growth_rate=?, days_ago=?, hours_ago=?, category_id=?, color1=?, color2=? WHERE id=?");
        $initials = !empty($_POST['initials']) ? $_POST['initials'] : makeInitials($_POST['creator']);
        $stmt->execute([
            $_POST['creator'], $initials, $_POST['caption'], $_POST['reel_url'] ?? '',
            $_POST['views'], $_POST['likes'], $_POST['comments'], $_POST['shares'],
            $_POST['growth_rate'], (int)$_POST['days_ago'], $_POST['hours_ago'],
            (int)$_POST['category_id'], $_POST['color1'], $_POST['color2'], (int)$_POST['id']
        ]);
        generateJSON();
        $msg = 'Reel updated successfully';
    }

    if ($action === 'delete_reel') {
        $pdo->prepare("DELETE FROM reels WHERE id=?")->execute([(int)$_POST['id']]);
        generateJSON();
        $msg = 'Reel deleted';
    }

    if ($action === 'add_account') {
        $stmt = $pdo->prepare("INSERT INTO accounts (username, name, initials, niche, followers, followers_gained, timeframe, avg_views, engagement_rate, top_content, color1, color2) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $initials = !empty($_POST['initials']) ? $_POST['initials'] : makeInitials($_POST['name']);
        $stmt->execute([
            $_POST['username'], $_POST['name'], $initials, $_POST['niche'],
            $_POST['followers'], $_POST['followers_gained'], $_POST['timeframe'],
            $_POST['avg_views'], $_POST['engagement_rate'], $_POST['top_content'],
            $_POST['color1'], $_POST['color2']
        ]);
        generateJSON();
        $msg = 'Account added successfully';
    }

    if ($action === 'update_account') {
        $stmt = $pdo->prepare("UPDATE accounts SET username=?, name=?, initials=?, niche=?, followers=?, followers_gained=?, timeframe=?, avg_views=?, engagement_rate=?, top_content=?, color1=?, color2=? WHERE id=?");
        $initials = !empty($_POST['initials']) ? $_POST['initials'] : makeInitials($_POST['name']);
        $stmt->execute([
            $_POST['username'], $_POST['name'], $initials, $_POST['niche'],
            $_POST['followers'], $_POST['followers_gained'], $_POST['timeframe'],
            $_POST['avg_views'], $_POST['engagement_rate'], $_POST['top_content'],
            $_POST['color1'], $_POST['color2'], (int)$_POST['id']
        ]);
        generateJSON();
        $msg = 'Account updated';
    }

    if ($action === 'delete_account') {
        $pdo->prepare("DELETE FROM accounts WHERE id=?")->execute([(int)$_POST['id']]);
        generateJSON();
        $msg = 'Account deleted';
    }

    if ($action === 'regenerate_json') {
        generateJSON();
        $msg = 'data.json regenerated';
    }

    if ($action === 'setup_db') {
        try {
            $sql = file_get_contents(__DIR__ . '/setup.sql');
            $pdo->exec($sql);
            $hash = password_hash(ADMIN_PASS, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE admin_users SET password_hash=? WHERE email=?")->execute([$hash, ADMIN_EMAIL]);
            $msg = 'Database setup complete';
        } catch (Exception $e) {
            $msg = 'Setup error: ' . $e->getMessage();
        }
    }

    if ($action === 'extract_reel_info') {
        header('Content-Type: application/json');
        $info = extractReelInfo($_POST['url'] ?? '');
        echo json_encode($info);
        exit;
    }

    if ($msg && in_array($action, ['add_reel','update_reel','delete_reel','add_account','update_account','delete_account','regenerate_json','setup_db'])) {
        $_SESSION['flash_msg'] = $msg;
        header('Location: admin.php' . (isset($_GET['tab']) ? '?tab=' . $_GET['tab'] : ''));
        exit;
    }
}

$flashMsg = $_SESSION['flash_msg'] ?? '';
unset($_SESSION['flash_msg']);

$reels = [];
$accounts = [];
$categories = [];
if ($isLoggedIn) {
    $pdo = getDB();
    $categories = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order")->fetchAll();
    $reels = $pdo->query("SELECT r.*, c.name as category_name FROM reels r JOIN categories c ON r.category_id=c.id ORDER BY r.created_at DESC")->fetchAll();
    $accounts = $pdo->query("SELECT * FROM accounts ORDER BY created_at DESC")->fetchAll();
}

$tab = $_GET['tab'] ?? 'reels';
$editReel = null;
$editAccount = null;
if (isset($_GET['edit_reel'])) {
    foreach ($reels as $r) { if ($r['id'] == $_GET['edit_reel']) { $editReel = $r; break; } }
}
if (isset($_GET['edit_account'])) {
    foreach ($accounts as $a) { if ($a['id'] == $_GET['edit_account']) { $editAccount = $a; break; } }
}

$colorPresets = [
    ['0xFF6C5CE7', '0xFFA29BFE'], ['0xFFE17055', '0xFFFF7675'], ['0xFFC5E84D', '0xFFAACC30'],
    ['0xFFFD79A8', '0xFFE84393'], ['0xFF00B894', '0xFF55EFC4'], ['0xFFFF7675', '0xFFD63031'],
    ['0xFF0984E3', '0xFF74B9FF'], ['0xFFFDAB40', '0xFFFCCB69'], ['0xFF636E72', '0xFFB2BEC3'],
    ['0xFFD63031', '0xFFFF7675'], ['0xFF00CEC9', '0xFF81ECEC'], ['0xFFE84393', '0xFFFD79A8'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trend Hook Admin</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:#0a0a0a;color:#e0e0e0;min-height:100vh}
.login-wrap{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
.login-box{background:#131313;border:1px solid rgba(255,255,255,0.05);border-radius:20px;padding:48px;width:100%;max-width:420px}
.login-box h1{font-size:28px;font-weight:800;margin-bottom:6px;letter-spacing:-0.5px}
.login-box h1 span{color:#C5E84D}
.login-box p{color:rgba(255,255,255,0.35);font-size:14px;margin-bottom:32px}
.form-group{margin-bottom:18px}
.form-group label{display:block;font-size:12px;font-weight:600;color:rgba(255,255,255,0.4);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;background:#0a0a0a;border:1px solid rgba(255,255,255,0.08);border-radius:12px;color:#fff;font-size:14px;outline:none;transition:border-color 0.2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:#C5E84D}
.form-group textarea{resize:vertical;min-height:70px}
.form-group select{cursor:pointer;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%23666' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center}
.btn{padding:12px 24px;border:none;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;transition:all 0.2s;display:inline-flex;align-items:center;gap:6px}
.btn-lime{background:#C5E84D;color:#1A2E05}
.btn-lime:hover{background:#d4f06a;transform:translateY(-1px)}
.btn-red{background:rgba(231,76,60,0.15);color:#e74c3c;border:1px solid rgba(231,76,60,0.2)}
.btn-red:hover{background:rgba(231,76,60,0.25)}
.btn-ghost{background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.6);border:1px solid rgba(255,255,255,0.08)}
.btn-ghost:hover{background:rgba(255,255,255,0.1)}
.btn-sm{padding:8px 14px;font-size:12px;border-radius:8px}
.error-msg{background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.2);color:#e74c3c;padding:12px;border-radius:10px;margin-bottom:16px;font-size:13px}
.success-msg{background:rgba(197,232,77,0.1);border:1px solid rgba(197,232,77,0.2);color:#C5E84D;padding:12px;border-radius:10px;margin-bottom:16px;font-size:13px}
.topbar{background:#131313;border-bottom:1px solid rgba(255,255,255,0.05);padding:16px 32px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;backdrop-filter:blur(20px)}
.topbar h1{font-size:20px;font-weight:800;letter-spacing:-0.3px}
.topbar h1 span{color:#C5E84D}
.topbar-right{display:flex;align-items:center;gap:12px}
.topbar-right span{font-size:13px;color:rgba(255,255,255,0.35)}
.tabs{display:flex;gap:4px;background:#0a0a0a;border-radius:14px;padding:4px;margin:24px 32px 0}
.tab{padding:10px 22px;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;color:rgba(255,255,255,0.4);transition:all 0.2s;text-decoration:none}
.tab.active{background:#C5E84D;color:#1A2E05}
.tab:hover:not(.active){color:rgba(255,255,255,0.7)}
.content{padding:24px 32px}
.card{background:#131313;border:1px solid rgba(255,255,255,0.05);border-radius:16px;padding:24px;margin-bottom:20px}
.card h2{font-size:18px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.card h2 .badge{background:rgba(197,232,77,0.12);color:#C5E84D;font-size:11px;padding:4px 10px;border-radius:6px;font-weight:600}
table{width:100%;border-collapse:collapse}
table th{text-align:left;padding:10px 14px;font-size:11px;font-weight:600;color:rgba(255,255,255,0.3);text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.05)}
table td{padding:12px 14px;font-size:13px;border-bottom:1px solid rgba(255,255,255,0.03);vertical-align:middle}
table tr:hover td{background:rgba(255,255,255,0.02)}
.color-dot{width:24px;height:24px;border-radius:8px;display:inline-block;vertical-align:middle}
.row-2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.row-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
.row-4{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:14px}
.color-presets{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
.color-preset{width:36px;height:36px;border-radius:10px;cursor:pointer;border:2px solid transparent;transition:all 0.2s}
.color-preset:hover,.color-preset.active{border-color:#C5E84D;transform:scale(1.1)}
.stat-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px}
.stat-card{background:#131313;border:1px solid rgba(255,255,255,0.05);border-radius:14px;padding:18px}
.stat-card .num{font-size:28px;font-weight:800;letter-spacing:-0.5px}
.stat-card .label{font-size:12px;color:rgba(255,255,255,0.3);margin-top:4px}
.actions{display:flex;gap:6px}
.url-extract{display:flex;gap:8px;align-items:flex-end}
.url-extract .form-group{flex:1;margin-bottom:0}
@media(max-width:768px){
  .topbar{padding:14px 16px}
  .tabs{margin:16px}
  .content{padding:16px}
  .row-2,.row-3,.row-4{grid-template-columns:1fr}
  .stat-cards{grid-template-columns:1fr 1fr}
  table{display:block;overflow-x:auto}
}
</style>
</head>
<body>

<?php if (!$isLoggedIn): ?>
<div class="login-wrap">
  <div class="login-box">
    <h1>TREND <span>HOOK</span></h1>
    <p>Admin Panel — Sign in to manage content</p>
    <?php if (!empty($loginError)): ?>
      <div class="error-msg"><?= htmlspecialchars($loginError) ?></div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="login">
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="admin@example.com" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required>
      </div>
      <button type="submit" class="btn btn-lime" style="width:100%;justify-content:center;margin-top:8px">Sign In</button>
    </form>
  </div>
</div>

<?php else: ?>

<div class="topbar">
  <h1>TREND <span>HOOK</span></h1>
  <div class="topbar-right">
    <span><?= htmlspecialchars($_SESSION['admin_email']) ?></span>
    <form method="POST" style="display:inline"><input type="hidden" name="action" value="logout"><button class="btn btn-ghost btn-sm">Logout</button></form>
    <form method="POST" style="display:inline"><input type="hidden" name="action" value="regenerate_json"><button class="btn btn-ghost btn-sm">↻ Rebuild JSON</button></form>
  </div>
</div>

<div class="tabs">
  <a href="?tab=reels" class="tab <?= $tab==='reels'?'active':'' ?>">Trending Reels</a>
  <a href="?tab=accounts" class="tab <?= $tab==='accounts'?'active':'' ?>">Rising Accounts</a>
  <a href="?tab=settings" class="tab <?= $tab==='settings'?'active':'' ?>">Settings</a>
</div>

<div class="content">
  <?php if ($flashMsg): ?>
    <div class="success-msg"><?= htmlspecialchars($flashMsg) ?></div>
  <?php endif; ?>

  <div class="stat-cards">
    <div class="stat-card"><div class="num" style="color:#C5E84D"><?= count($reels) ?></div><div class="label">Total Reels</div></div>
    <div class="stat-card"><div class="num"><?= count($accounts) ?></div><div class="label">Total Accounts</div></div>
    <div class="stat-card"><div class="num"><?= count($categories) ?></div><div class="label">Categories</div></div>
    <div class="stat-card"><div class="num" style="color:#C5E84D"><?= file_exists(JSON_OUTPUT_PATH) ? '✓' : '✗' ?></div><div class="label">data.json</div></div>
  </div>

  <?php if ($tab === 'reels'): ?>

    <div class="card">
      <h2><?= $editReel ? 'Edit Reel' : 'Add New Reel' ?> <span class="badge">REEL</span></h2>
      <form method="POST" action="admin.php?tab=reels">
        <input type="hidden" name="action" value="<?= $editReel ? 'update_reel' : 'add_reel' ?>">
        <?php if ($editReel): ?><input type="hidden" name="id" value="<?= $editReel['id'] ?>"><?php endif; ?>

        <div class="form-group" style="margin-bottom:20px">
          <label>Instagram Reel URL (paste link to auto-extract shortcode)</label>
          <div class="url-extract">
            <div class="form-group">
              <input type="text" name="reel_url" id="reel_url" placeholder="https://www.instagram.com/reel/ABC123/" value="<?= htmlspecialchars($editReel['reel_url'] ?? '') ?>">
            </div>
          </div>
        </div>

        <div class="row-2">
          <div class="form-group">
            <label>Creator Handle</label>
            <input type="text" name="creator" id="creator" placeholder="@username" value="<?= htmlspecialchars($editReel['creator'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Initials (auto-generated if empty)</label>
            <input type="text" name="initials" id="initials" placeholder="VK" maxlength="3" value="<?= htmlspecialchars($editReel['initials'] ?? '') ?>">
          </div>
        </div>

        <div class="form-group">
          <label>Caption</label>
          <textarea name="caption" placeholder="Reel caption or description" required><?= htmlspecialchars($editReel['caption'] ?? '') ?></textarea>
        </div>

        <div class="row-2">
          <div class="form-group">
            <label>Category</label>
            <select name="category_id" required>
              <?php foreach ($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= ($editReel && $editReel['category_id']==$c['id'])?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Growth Rate</label>
            <input type="text" name="growth_rate" placeholder="+540%" value="<?= htmlspecialchars($editReel['growth_rate'] ?? '+0%') ?>" required>
          </div>
        </div>

        <div class="row-4">
          <div class="form-group">
            <label>Views</label>
            <input type="text" name="views" placeholder="12.5M" value="<?= htmlspecialchars($editReel['views'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Likes</label>
            <input type="text" name="likes" placeholder="1.8M" value="<?= htmlspecialchars($editReel['likes'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Comments</label>
            <input type="text" name="comments" placeholder="45.2K" value="<?= htmlspecialchars($editReel['comments'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Shares</label>
            <input type="text" name="shares" placeholder="320K" value="<?= htmlspecialchars($editReel['shares'] ?? '') ?>" required>
          </div>
        </div>

        <div class="row-2">
          <div class="form-group">
            <label>Days Ago</label>
            <input type="number" name="days_ago" placeholder="2" value="<?= $editReel['days_ago'] ?? '0' ?>" required>
          </div>
          <div class="form-group">
            <label>Hours Ago</label>
            <input type="text" name="hours_ago" placeholder="3h" value="<?= htmlspecialchars($editReel['hours_ago'] ?? '0h') ?>" required>
          </div>
        </div>

        <div class="row-2">
          <div class="form-group">
            <label>Color 1 (Hex Flutter format)</label>
            <input type="text" name="color1" id="color1" placeholder="0xFF6C5CE7" value="<?= htmlspecialchars($editReel['color1'] ?? '0xFF6C5CE7') ?>">
          </div>
          <div class="form-group">
            <label>Color 2 (Hex Flutter format)</label>
            <input type="text" name="color2" id="color2" placeholder="0xFFA29BFE" value="<?= htmlspecialchars($editReel['color2'] ?? '0xFFA29BFE') ?>">
          </div>
        </div>

        <div class="form-group">
          <label>Color Presets (click to apply)</label>
          <div class="color-presets">
            <?php foreach ($colorPresets as $i => $cp): ?>
              <div class="color-preset" style="background:linear-gradient(135deg, #<?= substr($cp[0],4) ?>, #<?= substr($cp[1],4) ?>)" onclick="document.getElementById('color1').value='<?= $cp[0] ?>';document.getElementById('color2').value='<?= $cp[1] ?>'"></div>
            <?php endforeach; ?>
          </div>
        </div>

        <div style="display:flex;gap:10px;margin-top:20px">
          <button type="submit" class="btn btn-lime"><?= $editReel ? 'Update Reel' : 'Add Reel' ?></button>
          <?php if ($editReel): ?><a href="?tab=reels" class="btn btn-ghost">Cancel</a><?php endif; ?>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>All Reels <span class="badge"><?= count($reels) ?></span></h2>
      <?php if (empty($reels)): ?>
        <p style="color:rgba(255,255,255,0.3);font-size:14px">No reels added yet. Use the form above to add your first reel.</p>
      <?php else: ?>
        <table>
          <thead><tr><th>Creator</th><th>Caption</th><th>Category</th><th>Views</th><th>Growth</th><th>Color</th><th>Actions</th></tr></thead>
          <tbody>
            <?php foreach ($reels as $r): ?>
              <tr>
                <td><strong><?= htmlspecialchars($r['creator']) ?></strong><br><span style="color:rgba(255,255,255,0.3);font-size:11px"><?= htmlspecialchars($r['initials']) ?></span></td>
                <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($r['caption']) ?></td>
                <td><span style="background:rgba(197,232,77,0.1);color:#C5E84D;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600"><?= htmlspecialchars($r['category_name']) ?></span></td>
                <td><?= htmlspecialchars($r['views']) ?></td>
                <td style="color:#C5E84D;font-weight:700"><?= htmlspecialchars($r['growth_rate']) ?></td>
                <td><span class="color-dot" style="background:linear-gradient(135deg, #<?= substr($r['color1'],4) ?>, #<?= substr($r['color2'],4) ?>)"></span></td>
                <td class="actions">
                  <a href="?tab=reels&edit_reel=<?= $r['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
                  <form method="POST" style="display:inline" onsubmit="return confirm('Delete this reel?')"><input type="hidden" name="action" value="delete_reel"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-red btn-sm">Delete</button></form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

  <?php elseif ($tab === 'accounts'): ?>

    <div class="card">
      <h2><?= $editAccount ? 'Edit Account' : 'Add Rising Account' ?> <span class="badge">ACCOUNT</span></h2>
      <form method="POST" action="admin.php?tab=accounts">
        <input type="hidden" name="action" value="<?= $editAccount ? 'update_account' : 'add_account' ?>">
        <?php if ($editAccount): ?><input type="hidden" name="id" value="<?= $editAccount['id'] ?>"><?php endif; ?>

        <div class="row-3">
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="@creator" value="<?= htmlspecialchars($editAccount['username'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Display Name</label>
            <input type="text" name="name" placeholder="Creator Name" value="<?= htmlspecialchars($editAccount['name'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Initials</label>
            <input type="text" name="initials" placeholder="CN" maxlength="3" value="<?= htmlspecialchars($editAccount['initials'] ?? '') ?>">
          </div>
        </div>

        <div class="row-3">
          <div class="form-group">
            <label>Niche</label>
            <select name="niche" required>
              <?php foreach ($categories as $c): ?>
                <option value="<?= htmlspecialchars($c['name']) ?>" <?= ($editAccount && $editAccount['niche']==$c['name'])?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Followers</label>
            <input type="text" name="followers" placeholder="2.1M" value="<?= htmlspecialchars($editAccount['followers'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Followers Gained</label>
            <input type="text" name="followers_gained" placeholder="+450K" value="<?= htmlspecialchars($editAccount['followers_gained'] ?? '') ?>" required>
          </div>
        </div>

        <div class="row-3">
          <div class="form-group">
            <label>Timeframe</label>
            <input type="text" name="timeframe" placeholder="30 days" value="<?= htmlspecialchars($editAccount['timeframe'] ?? '30 days') ?>" required>
          </div>
          <div class="form-group">
            <label>Avg Views</label>
            <input type="text" name="avg_views" placeholder="5.2M" value="<?= htmlspecialchars($editAccount['avg_views'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label>Engagement Rate</label>
            <input type="text" name="engagement_rate" placeholder="12.4%" value="<?= htmlspecialchars($editAccount['engagement_rate'] ?? '') ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label>Top Content</label>
          <textarea name="top_content" placeholder="Magic tricks, illusions, street performances"><?= htmlspecialchars($editAccount['top_content'] ?? '') ?></textarea>
        </div>

        <div class="row-2">
          <div class="form-group">
            <label>Color 1</label>
            <input type="text" name="color1" id="acolor1" placeholder="0xFFC5E84D" value="<?= htmlspecialchars($editAccount['color1'] ?? '0xFFC5E84D') ?>">
          </div>
          <div class="form-group">
            <label>Color 2</label>
            <input type="text" name="color2" id="acolor2" placeholder="0xFFAACC30" value="<?= htmlspecialchars($editAccount['color2'] ?? '0xFFAACC30') ?>">
          </div>
        </div>

        <div class="form-group">
          <label>Color Presets</label>
          <div class="color-presets">
            <?php foreach ($colorPresets as $cp): ?>
              <div class="color-preset" style="background:linear-gradient(135deg, #<?= substr($cp[0],4) ?>, #<?= substr($cp[1],4) ?>)" onclick="document.getElementById('acolor1').value='<?= $cp[0] ?>';document.getElementById('acolor2').value='<?= $cp[1] ?>'"></div>
            <?php endforeach; ?>
          </div>
        </div>

        <div style="display:flex;gap:10px;margin-top:20px">
          <button type="submit" class="btn btn-lime"><?= $editAccount ? 'Update Account' : 'Add Account' ?></button>
          <?php if ($editAccount): ?><a href="?tab=accounts" class="btn btn-ghost">Cancel</a><?php endif; ?>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>All Accounts <span class="badge"><?= count($accounts) ?></span></h2>
      <?php if (empty($accounts)): ?>
        <p style="color:rgba(255,255,255,0.3);font-size:14px">No accounts added yet.</p>
      <?php else: ?>
        <table>
          <thead><tr><th>Username</th><th>Name</th><th>Niche</th><th>Followers</th><th>Gained</th><th>Engagement</th><th>Color</th><th>Actions</th></tr></thead>
          <tbody>
            <?php foreach ($accounts as $a): ?>
              <tr>
                <td><strong><?= htmlspecialchars($a['username']) ?></strong></td>
                <td><?= htmlspecialchars($a['name']) ?></td>
                <td><span style="background:rgba(197,232,77,0.1);color:#C5E84D;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600"><?= htmlspecialchars($a['niche']) ?></span></td>
                <td><?= htmlspecialchars($a['followers']) ?></td>
                <td style="color:#C5E84D;font-weight:700"><?= htmlspecialchars($a['followers_gained']) ?></td>
                <td><?= htmlspecialchars($a['engagement_rate']) ?></td>
                <td><span class="color-dot" style="background:linear-gradient(135deg, #<?= substr($a['color1'],4) ?>, #<?= substr($a['color2'],4) ?>)"></span></td>
                <td class="actions">
                  <a href="?tab=accounts&edit_account=<?= $a['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
                  <form method="POST" style="display:inline" onsubmit="return confirm('Delete this account?')"><input type="hidden" name="action" value="delete_account"><input type="hidden" name="id" value="<?= $a['id'] ?>"><button class="btn btn-red btn-sm">Delete</button></form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

  <?php elseif ($tab === 'settings'): ?>

    <div class="card">
      <h2>Database Setup</h2>
      <p style="color:rgba(255,255,255,0.35);font-size:13px;margin-bottom:16px">Run this once to initialize the database tables and default categories. Edit <code>config.php</code> to set your MySQL credentials before running setup.</p>
      <form method="POST" onsubmit="return confirm('This will create/update database tables. Continue?')">
        <input type="hidden" name="action" value="setup_db">
        <button class="btn btn-lime">Initialize Database</button>
      </form>
    </div>

    <div class="card">
      <h2>Configuration</h2>
      <table>
        <tr><td style="color:rgba(255,255,255,0.4)">JSON Path</td><td><code><?= JSON_OUTPUT_PATH ?></code></td></tr>
        <tr><td style="color:rgba(255,255,255,0.4)">API URL</td><td><code>https://development.avsvishalmedia.com/viralhook/data.json</code></td></tr>
        <tr><td style="color:rgba(255,255,255,0.4)">Database</td><td><code><?= DB_NAME ?></code></td></tr>
        <tr><td style="color:rgba(255,255,255,0.4)">Categories</td><td><?= count($categories) ?> active</td></tr>
      </table>
    </div>

    <div class="card">
      <h2>How To Use</h2>
      <ol style="color:rgba(255,255,255,0.5);font-size:13px;line-height:2;padding-left:20px">
        <li>Edit <strong>config.php</strong> → Set your Hostinger MySQL host, database name, username, password</li>
        <li>Go to <strong>Settings</strong> tab → Click <strong>Initialize Database</strong></li>
        <li>Go to <strong>Trending Reels</strong> tab → Paste reel URL, fill stats, select category, click Add</li>
        <li>Go to <strong>Rising Accounts</strong> tab → Add creator accounts with growth data</li>
        <li>JSON file auto-generates on every add/edit/delete. Use <strong>Rebuild JSON</strong> button if needed</li>
        <li>App fetches data from <code>data.json</code> automatically</li>
      </ol>
    </div>

  <?php endif; ?>
</div>

<?php endif; ?>

<script>
document.getElementById('reel_url')?.addEventListener('paste', function(e) {
    setTimeout(() => {
        const url = this.value;
        const match = url.match(/(?:reel|reels|p)\/([A-Za-z0-9_-]+)/);
        if (match) {
            const cField = document.getElementById('creator');
            if (!cField.value) cField.focus();
        }
    }, 100);
});
</script>
</body>
</html>

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'dart:math';

const Color kLime = Color(0xFFC5E84D);
const Color kLimeDark = Color(0xFFAACC30);
const Color kLimeText = Color(0xFF1A2E05);
const Color kBg = Color(0xFF0A0A0A);
const Color kCard = Color(0xFF131313);
const Color kSurface = Color(0xFF161616);
const Color kBorder = Color(0x0DFFFFFF);

const String kApiUrl = 'https://development.avsvishalmedia.com/viralhook/data.json';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PremiumManager.init();
  runApp(const TrendHookApp());
}

class TrendHookApp extends StatelessWidget {
  const TrendHookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TREND HOOK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        primaryColor: kCard,
      ),
      home: const HomePage(),
    );
  }
}

class PremiumManager {
  static bool _isPremium = false;
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _isPremium = _prefs?.getBool('premium') ?? false;
  }

  static bool get isPremium => _isPremium;

  static Future<void> activate() async {
    _isPremium = true;
    await _prefs?.setBool('premium', true);
  }

  static bool validateCode(String code) {
    return code == '000';
  }
}

Color parseColorString(String colorStr) {
  try {
    final hex = colorStr.replaceAll('0x', '').replaceAll('#', '');
    return Color(int.parse(hex, radix: 16));
  } catch (_) {
    return const Color(0xFF6C5CE7);
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int selectedSection = 0;
  String selectedCategory = 'All';
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  final List<Map<String, dynamic>> categories = [
    {'name': 'All', 'icon': Icons.grid_view_rounded},
    {'name': 'Entertainment', 'icon': Icons.movie_filter_rounded},
    {'name': 'Comedy', 'icon': Icons.sentiment_very_satisfied_rounded},
    {'name': 'Education', 'icon': Icons.school_rounded},
    {'name': 'Fitness', 'icon': Icons.fitness_center_rounded},
    {'name': 'Food', 'icon': Icons.restaurant_rounded},
    {'name': 'Tech', 'icon': Icons.devices_rounded},
    {'name': 'Fashion', 'icon': Icons.checkroom_rounded},
    {'name': 'Travel', 'icon': Icons.flight_rounded},
  ];

  Map<String, List<Map<String, dynamic>>> trendingReels = {};
  List<Map<String, dynamic>> explodingAccounts = [];

  List<Map<String, dynamic>> get filteredReels {
    final query = _searchController.text.toLowerCase();
    List<Map<String, dynamic>> reels;
    if (selectedCategory == 'All') {
      reels = [];
      trendingReels.forEach((key, value) {
        reels.addAll(value);
      });
      reels.sort((a, b) {
        String viewsA = (a['views'] as String).replaceAll(RegExp(r'[^0-9.]'), '');
        String viewsB = (b['views'] as String).replaceAll(RegExp(r'[^0-9.]'), '');
        return double.parse(viewsB).compareTo(double.parse(viewsA));
      });
    } else {
      reels = trendingReels[selectedCategory] ?? [];
    }
    if (query.isEmpty) return reels;
    return reels.where((r) {
      final creator = (r['creator'] as String).toLowerCase();
      final caption = (r['caption'] as String).toLowerCase();
      return creator.contains(query) || caption.contains(query);
    }).toList();
  }

  List<Map<String, dynamic>> get filteredAccounts {
    final query = _searchController.text.toLowerCase();
    if (query.isEmpty) return explodingAccounts;
    return explodingAccounts.where((a) {
      final username = (a['username'] as String).toLowerCase();
      final name = (a['name'] as String).toLowerCase();
      final niche = (a['niche'] as String).toLowerCase();
      return username.contains(query) || name.contains(query) || niche.contains(query);
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {
        selectedSection = _tabController.index;
      });
    });
    _searchController.addListener(() => setState(() {}));
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });
    try {
      final response = await http.get(Uri.parse(kApiUrl)).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final Map<String, dynamic> reelsJson = data['trendingReels'] ?? {};
        final Map<String, List<Map<String, dynamic>>> parsedReels = {};
        reelsJson.forEach((category, reelsList) {
          final List<Map<String, dynamic>> parsed = [];
          for (var r in (reelsList as List)) {
            final reel = Map<String, dynamic>.from(r);
            reel['color1'] = parseColorString(reel['color1'] ?? '0xFF6C5CE7');
            reel['color2'] = parseColorString(reel['color2'] ?? '0xFFA29BFE');
            reel['isLoaded'] = Random().nextBool();
            reel['daysAgo'] = reel['daysAgo'] ?? 0;
            parsed.add(reel);
          }
          parsedReels[category] = parsed;
        });
        final List<dynamic> accountsJson = data['explodingAccounts'] ?? [];
        final List<Map<String, dynamic>> parsedAccounts = [];
        for (var a in accountsJson) {
          final account = Map<String, dynamic>.from(a);
          account['color1'] = parseColorString(account['color1'] ?? '0xFFC5E84D');
          account['color2'] = parseColorString(account['color2'] ?? '0xFFAACC30');
          parsedAccounts.add(account);
        }
        setState(() {
          trendingReels = parsedReels;
          explodingAccounts = parsedAccounts;
          _isLoading = false;
        });
      } else {
        setState(() {
          _hasError = true;
          _errorMessage = 'Server error (${response.statusCode})';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _hasError = true;
        _errorMessage = 'Failed to load data. Check your connection.';
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 6),
            _buildTopBar(),
            const SizedBox(height: 14),
            _buildSearchBar(),
            const SizedBox(height: 14),
            _buildSectionTabs(),
            if (selectedSection == 0) ...[
              const SizedBox(height: 14),
              _buildCategoryChips(),
            ],
            const SizedBox(height: 14),
            Expanded(
              child: _isLoading
                  ? _buildLoadingState()
                  : _hasError
                      ? _buildErrorState()
                      : RefreshIndicator(
                          color: kLime,
                          backgroundColor: kCard,
                          onRefresh: _fetchData,
                          child: selectedSection == 0
                              ? _buildReelsGrid()
                              : _buildAccountsList(),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 40,
            height: 40,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              valueColor: AlwaysStoppedAnimation<Color>(kLime),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'Loading trends...',
            style: TextStyle(
              color: Colors.white.withOpacity(0.35),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.08),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                Icons.wifi_off_rounded,
                color: Colors.red.withOpacity(0.5),
                size: 30,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              _errorMessage,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: _fetchData,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                decoration: BoxDecoration(
                  color: kLime,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  'Retry',
                  style: TextStyle(
                    color: kLimeText,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder, width: 0.5),
              ),
              child: Icon(
                Icons.menu_rounded,
                color: Colors.white.withOpacity(0.85),
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Row(
              children: [
                const Text(
                  'TREND',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: kLime,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.local_fire_department_rounded,
                        color: kLimeText,
                        size: 16,
                      ),
                      const SizedBox(width: 3),
                      const Text(
                        'HOOK',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: kLimeText,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (PremiumManager.isPremium)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: kLime,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                'PRO',
                style: TextStyle(
                  color: kLimeText,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 46,
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Row(
          children: [
            const SizedBox(width: 14),
            Icon(
              Icons.search_rounded,
              color: Colors.white.withOpacity(0.3),
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                decoration: InputDecoration(
                  hintText: 'Search trending reels & creators',
                  hintStyle: TextStyle(
                    color: Colors.white.withOpacity(0.22),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTabs() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: TabBar(
          controller: _tabController,
          indicator: BoxDecoration(
            color: kLime,
            borderRadius: BorderRadius.circular(10),
          ),
          indicatorSize: TabBarIndicatorSize.tab,
          labelColor: kLimeText,
          unselectedLabelColor: Colors.white.withOpacity(0.35),
          labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
          dividerColor: Colors.transparent,
          indicatorPadding: const EdgeInsets.all(3),
          tabs: const [
            Tab(text: 'Trending Reels'),
            Tab(text: 'Rising Creators'),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryChips() {
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final cat = categories[index];
          final isSelected = selectedCategory == cat['name'];
          return GestureDetector(
            onTap: () => setState(() => selectedCategory = cat['name'] as String),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: isSelected ? kLime : kSurface,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(
                  color: isSelected ? kLime : kBorder,
                  width: isSelected ? 1.5 : 0.5,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    cat['icon'] as IconData,
                    size: 15,
                    color: isSelected ? kLimeText : Colors.white.withOpacity(0.35),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    cat['name'] as String,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                      color: isSelected ? kLimeText : Colors.white.withOpacity(0.45),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildReelsGrid() {
    final reels = filteredReels;
    if (reels.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off_rounded, size: 48, color: Colors.white.withOpacity(0.15)),
            const SizedBox(height: 12),
            Text(
              'No reels found',
              style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 15, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      );
    }
    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.68,
      ),
      itemCount: reels.length,
      itemBuilder: (context, index) {
        final reel = reels[index];
        return _ReelCard(
          reel: reel,
          onTap: () {
            Navigator.push(context, MaterialPageRoute(
              builder: (_) => ReelDetailPage(reel: reel),
            ));
          },
        );
      },
    );
  }

  Widget _buildAccountsList() {
    final accounts = filteredAccounts;
    if (accounts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off_rounded, size: 48, color: Colors.white.withOpacity(0.15)),
            const SizedBox(height: 12),
            Text(
              'No accounts found',
              style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 15, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: accounts.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final account = accounts[index];
        final c1 = account['color1'] as Color;
        final c2 = account['color2'] as Color;
        return GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(
              builder: (_) => AccountDetailPage(account: account),
            ));
          },
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kBorder, width: 0.5),
            ),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [c1, c2]),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: Text(
                      account['initials'] as String,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        account['name'] as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                          letterSpacing: -0.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        account['username'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: kLime.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              account['niche'] as String,
                              style: TextStyle(
                                color: kLime.withOpacity(0.8),
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(Icons.people_outline_rounded, size: 12, color: Colors.white.withOpacity(0.25)),
                          const SizedBox(width: 3),
                          Text(
                            account['followers'] as String,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.4),
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      account['followersGained'] as String,
                      style: const TextStyle(
                        color: kLime,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      account['timeframe'] as String,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.25),
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const Text(
                    'TREND',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: kLime,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'HOOK',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: kLimeText, letterSpacing: 1),
                    ),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: Colors.white.withOpacity(0.04)),
            _drawerItem(Icons.trending_up_rounded, 'Trending', true),
            _drawerItem(Icons.explore_rounded, 'Discover', false),
            _drawerItem(Icons.bookmark_outline_rounded, 'Saved', false),
            Divider(height: 1, color: Colors.white.withOpacity(0.04)),
            const Spacer(),
            if (!PremiumManager.isPremium)
              Padding(
                padding: const EdgeInsets.all(20),
                child: GestureDetector(
                  onTap: _showPremiumDialog,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: kLime.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: kLime.withOpacity(0.15)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.workspace_premium_rounded, color: kLime, size: 20),
                            const SizedBox(width: 8),
                            Text(
                              'Go Premium',
                              style: TextStyle(color: kLime, fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Unlock all features',
                          style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Text(
                'V1.0.6',
                style: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, bool isActive) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        color: isActive ? kLime.withOpacity(0.08) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Icon(icon, color: isActive ? kLime : Colors.white.withOpacity(0.3), size: 22),
        title: Text(
          label,
          style: TextStyle(
            color: isActive ? kLime : Colors.white.withOpacity(0.5),
            fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
            fontSize: 14,
          ),
        ),
        dense: true,
        visualDensity: const VisualDensity(vertical: -1),
      ),
    );
  }

  void _showPremiumDialog() {
    final codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: kLime.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(Icons.workspace_premium_rounded, color: kLime, size: 28),
              ),
              const SizedBox(height: 16),
              const Text(
                'Enter Premium Code',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18),
              ),
              const SizedBox(height: 18),
              Container(
                decoration: BoxDecoration(
                  color: kBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kBorder),
                ),
                child: TextField(
                  controller: codeController,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 4),
                  decoration: InputDecoration(
                    hintText: 'CODE',
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.15)),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(16),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: () async {
                  if (PremiumManager.validateCode(codeController.text.trim())) {
                    await PremiumManager.activate();
                    Navigator.pop(ctx);
                    setState(() {});
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text('Premium activated!', style: TextStyle(fontWeight: FontWeight.w600)),
                        backgroundColor: kLime,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text('Invalid code', style: TextStyle(fontWeight: FontWeight.w600)),
                        backgroundColor: Colors.red,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    );
                  }
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: kLime,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      'Activate',
                      style: TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 15),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReelCard extends StatefulWidget {
  final Map<String, dynamic> reel;
  final VoidCallback onTap;

  const _ReelCard({required this.reel, required this.onTap});

  @override
  State<_ReelCard> createState() => _ReelCardState();
}

class _ReelCardState extends State<_ReelCard> with SingleTickerProviderStateMixin {
  late AnimationController _shimmerController;

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );
    if (widget.reel['isLoaded'] == false) {
      _shimmerController.repeat();
    }
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reel = widget.reel;
    final c1 = reel['color1'] as Color;
    final c2 = reel['color2'] as Color;
    final isLoaded = reel['isLoaded'] == true;

    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [c1, c2, c1.withOpacity(0.8)],
                  ),
                ),
              ),
              if (!isLoaded)
                AnimatedBuilder(
                  animation: _shimmerController,
                  builder: (context, child) {
                    final v = _shimmerController.value;
                    return BackdropFilter(
                      filter: ImageFilter.blur(
                        sigmaX: 12 + (sin(v * 3.14159 * 2) * 4),
                        sigmaY: 12 + (sin(v * 3.14159 * 2) * 4),
                      ),
                      child: Container(
                        color: Colors.black.withOpacity(0.15 + (v * 0.1)),
                      ),
                    );
                  },
                ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withOpacity(0.85),
                        Colors.black.withOpacity(0.0),
                      ],
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Center(
                              child: Text(
                                reel['initials'] as String,
                                style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              reel['creator'] as String,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 11),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        reel['caption'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 11,
                          fontWeight: FontWeight.w400,
                          height: 1.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.visibility_outlined, size: 11, color: Colors.white.withOpacity(0.5)),
                          const SizedBox(width: 3),
                          Text(
                            reel['views'] as String,
                            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10, fontWeight: FontWeight.w600),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: kLime.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Text(
                              reel['growthRate'] as String,
                              style: const TextStyle(color: kLimeText, fontSize: 9, fontWeight: FontWeight.w800),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    reel['hoursAgo'] as String,
                    style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ReelDetailPage extends StatelessWidget {
  final Map<String, dynamic> reel;

  const ReelDetailPage({super.key, required this.reel});

  @override
  Widget build(BuildContext context) {
    final c1 = reel['color1'] as Color;
    final c2 = reel['color2'] as Color;

    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: kBg,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [c1, c2, kBg],
                  ),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Text(
                            reel['initials'] as String,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 24),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        reel['creator'] as String,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20, letterSpacing: -0.3),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: kLime,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.local_fire_department_rounded, size: 14, color: kLimeText),
                            const SizedBox(width: 4),
                            Text(
                              reel['category'] as String,
                              style: const TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: kCard,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: kBorder, width: 0.5),
                    ),
                    child: Text(
                      reel['caption'] as String,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        height: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _statCard('Views', reel['views'] as String, Icons.visibility_outlined),
                      const SizedBox(width: 8),
                      _statCard('Likes', reel['likes'] as String, Icons.favorite_outline_rounded),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _statCard('Comments', reel['comments'] as String, Icons.chat_bubble_outline_rounded),
                      const SizedBox(width: 8),
                      _statCard('Shares', reel['shares'] as String, Icons.share_outlined),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: kLime.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: kLime.withOpacity(0.12)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.trending_up_rounded, color: kLime, size: 22),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Growth Rate',
                              style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11, fontWeight: FontWeight.w500),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              reel['growthRate'] as String,
                              style: const TextStyle(color: kLime, fontWeight: FontWeight.w800, fontSize: 22, letterSpacing: -0.5),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Text(
                          'Posted ${reel['hoursAgo']} ago',
                          style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: Colors.white.withOpacity(0.3)),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 11),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16, letterSpacing: -0.3),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AccountDetailPage extends StatelessWidget {
  final Map<String, dynamic> account;

  const AccountDetailPage({super.key, required this.account});

  @override
  Widget build(BuildContext context) {
    final c1 = account['color1'] as Color;
    final c2 = account['color2'] as Color;

    return Scaffold(
      backgroundColor: kBg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            backgroundColor: kBg,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [c1, c2, kBg],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Transform.translate(
              offset: const Offset(0, -30),
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: kBorder, width: 0.5),
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [c1, c2]),
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                account['initials'] as String,
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 24),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            (account['name'] as String).toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 0.5),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            account['username'] as String,
                            style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 14),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: kLime,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.star_rounded, size: 14, color: kLimeText),
                                const SizedBox(width: 4),
                                Text(
                                  account['niche'] as String,
                                  style: const TextStyle(color: kLimeText, fontWeight: FontWeight.w800, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _statCard('Followers', account['followers'] as String, Icons.people_outline_rounded),
                        const SizedBox(width: 8),
                        _statCard('Gained', account['followersGained'] as String, Icons.trending_up_rounded),
                        const SizedBox(width: 8),
                        _statCard('Avg Views', account['avgViews'] as String, Icons.visibility_outlined),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: kBorder, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'GROWTH',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.25),
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 14),
                          _row('Followers Gained', account['followersGained'] as String),
                          _divider(),
                          _row('Timeframe', account['timeframe'] as String),
                          _divider(),
                          _row('Engagement Rate', account['engagementRate'] as String),
                          _divider(),
                          _row('Avg Views/Reel', account['avgViews'] as String),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: kLime.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: kLime.withOpacity(0.12), width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.auto_awesome_rounded, color: kLime.withOpacity(0.7), size: 18),
                              const SizedBox(width: 8),
                              Text(
                                'Content Strategy',
                                style: TextStyle(color: Colors.white.withOpacity(0.85), fontWeight: FontWeight.w700, fontSize: 14, letterSpacing: -0.1),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Top content: ${account['topContent']}',
                            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13, height: 1.5),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Gained ${account['followersGained']} in ${account['timeframe']} with ${account['engagementRate']} engagement.',
                            style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 12, height: 1.5),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: Colors.white.withOpacity(0.3)),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: -0.2),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13)),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _divider() {
    return Divider(height: 1, color: Colors.white.withOpacity(0.04));
  }
}

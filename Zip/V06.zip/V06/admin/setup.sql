CREATE DATABASE IF NOT EXISTS `viralhook_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `viralhook_db`;

CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(100) DEFAULT 'star',
  `sort_order` INT DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `reels` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `creator` VARCHAR(255) NOT NULL,
  `initials` VARCHAR(10) NOT NULL,
  `caption` TEXT NOT NULL,
  `reel_url` VARCHAR(500) DEFAULT '',
  `views` VARCHAR(50) DEFAULT '0',
  `likes` VARCHAR(50) DEFAULT '0',
  `comments` VARCHAR(50) DEFAULT '0',
  `shares` VARCHAR(50) DEFAULT '0',
  `growth_rate` VARCHAR(50) DEFAULT '+0%',
  `days_ago` INT DEFAULT 0,
  `hours_ago` VARCHAR(20) DEFAULT '0h',
  `category_id` INT NOT NULL,
  `color1` VARCHAR(12) DEFAULT '0xFF6C5CE7',
  `color2` VARCHAR(12) DEFAULT '0xFFA29BFE',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(255) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `initials` VARCHAR(10) NOT NULL,
  `niche` VARCHAR(100) NOT NULL,
  `followers` VARCHAR(50) DEFAULT '0',
  `followers_gained` VARCHAR(50) DEFAULT '0',
  `timeframe` VARCHAR(50) DEFAULT '30 days',
  `avg_views` VARCHAR(50) DEFAULT '0',
  `engagement_rate` VARCHAR(20) DEFAULT '0%',
  `top_content` TEXT,
  `color1` VARCHAR(12) DEFAULT '0xFFC5E84D',
  `color2` VARCHAR(12) DEFAULT '0xFFAACC30',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `categories` (`name`, `icon`, `sort_order`) VALUES
('Entertainment', 'movie_filter_rounded', 1),
('Comedy', 'sentiment_very_satisfied_rounded', 2),
('Education', 'school_rounded', 3),
('Fitness', 'fitness_center_rounded', 4),
('Food', 'restaurant_rounded', 5),
('Tech', 'devices_rounded', 6),
('Fashion', 'checkroom_rounded', 7),
('Travel', 'flight_rounded', 8)
ON DUPLICATE KEY UPDATE `name`=`name`;

INSERT INTO `admin_users` (`email`, `password_hash`) VALUES
('admin@avsvishalmedia.com', '$2y$12$PLACEHOLDER_HASH')
ON DUPLICATE KEY UPDATE `email`=`email`;

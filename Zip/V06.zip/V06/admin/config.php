<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'viralhook_db');
define('DB_USER', 'root');
define('DB_PASS', '');

define('ADMIN_EMAIL', 'admin@avsvishalmedia.com');
define('ADMIN_PASS', '@Vishal700');

define('JSON_OUTPUT_PATH', __DIR__ . '/data.json');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed']));
        }
    }
    return $pdo;
}

function generateJSON() {
    $pdo = getDB();

    $cats = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order")->fetchAll();
    $categoryNames = array_column($cats, 'name');
    $categoryMap = [];
    foreach ($cats as $c) $categoryMap[$c['id']] = $c['name'];

    $reels = $pdo->query("SELECT r.*, c.name as category_name FROM reels r JOIN categories c ON r.category_id=c.id WHERE r.is_active=1 ORDER BY r.created_at DESC")->fetchAll();

    $trendingReels = [];
    foreach ($categoryNames as $cn) $trendingReels[$cn] = [];

    foreach ($reels as $r) {
        $catName = $r['category_name'];
        $trendingReels[$catName][] = [
            'id' => (int)$r['id'],
            'creator' => $r['creator'],
            'initials' => $r['initials'],
            'caption' => $r['caption'],
            'reelUrl' => $r['reel_url'],
            'views' => $r['views'],
            'likes' => $r['likes'],
            'comments' => $r['comments'],
            'shares' => $r['shares'],
            'growthRate' => $r['growth_rate'],
            'daysAgo' => (int)$r['days_ago'],
            'hoursAgo' => $r['hours_ago'],
            'category' => $catName,
            'color1' => $r['color1'],
            'color2' => $r['color2']
        ];
    }

    foreach ($trendingReels as $k => $v) {
        if (empty($v)) unset($trendingReels[$k]);
    }

    $accounts = $pdo->query("SELECT * FROM accounts WHERE is_active=1 ORDER BY created_at DESC")->fetchAll();
    $explodingAccounts = [];
    foreach ($accounts as $a) {
        $explodingAccounts[] = [
            'id' => (int)$a['id'],
            'username' => $a['username'],
            'name' => $a['name'],
            'initials' => $a['initials'],
            'niche' => $a['niche'],
            'followers' => $a['followers'],
            'followersGained' => $a['followers_gained'],
            'timeframe' => $a['timeframe'],
            'avgViews' => $a['avg_views'],
            'engagementRate' => $a['engagement_rate'],
            'topContent' => $a['top_content'],
            'color1' => $a['color1'],
            'color2' => $a['color2']
        ];
    }

    $data = [
        'version' => '1.0',
        'lastUpdated' => date('c'),
        'categories' => $categoryNames,
        'trendingReels' => (object)$trendingReels,
        'explodingAccounts' => $explodingAccounts
    ];

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    file_put_contents(JSON_OUTPUT_PATH, $json);
    return true;
}

function extractReelInfo($url) {
    $info = ['shortcode' => '', 'creator' => '', 'initials' => ''];
    if (preg_match('/(?:reel|reels|p)\/([A-Za-z0-9_-]+)/', $url, $m)) {
        $info['shortcode'] = $m[1];
    }
    return $info;
}

function makeInitials($name) {
    $name = ltrim($name, '@');
    $parts = preg_split('/[\s._-]+/', $name);
    if (count($parts) >= 2) {
        return strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1));
    }
    return strtoupper(mb_substr($name, 0, 2));
}

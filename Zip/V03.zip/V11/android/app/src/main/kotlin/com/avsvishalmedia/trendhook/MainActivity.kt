package com.avsvishalmedia.trendhook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

# Face Maxxing - Flutter App

A Flutter application for face analysis and AI features.

## Getting Started

### Run the app:
```bash
flutter pub get
flutter run
```

### Build APK:
```bash
flutter build apk --release
```

## Project Structure
- `lib/` - Dart source code
- `android/` - Android native configuration
- `pubspec.yaml` - Flutter dependencies

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:trend_hook/main.dart';

void main() {
  testWidgets('App loads smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const TrendHookApp());
    expect(find.text('Trend Hook'), findsOneWidget);
  });
}

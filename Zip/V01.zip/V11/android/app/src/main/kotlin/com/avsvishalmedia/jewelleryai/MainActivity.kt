package com.avsvishalmedia.jewelleryai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

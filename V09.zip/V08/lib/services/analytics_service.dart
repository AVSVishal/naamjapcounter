import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/foundation.dart';

/// Service for tracking all user interactions and events in Google Analytics
class AnalyticsService {
  static final AnalyticsService _instance = AnalyticsService._internal();
  factory AnalyticsService() => _instance;
  AnalyticsService._internal();

  final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;

  /// Initialize analytics
  Future<void> initialize() async {
    await _analytics.setAnalyticsCollectionEnabled(true);
    if (kDebugMode) {
      print('Analytics initialized');
    }
  }

  /// Track screen view
  Future<void> logScreenView({
    required String screenName,
    String? screenClass,
  }) async {
    await _analytics.logScreenView(
      screenName: screenName,
      screenClass: screenClass ?? screenName,
    );
    if (kDebugMode) {
      print('Screen view: $screenName');
    }
  }

  /// Track when user selects a country
  Future<void> logCountrySelection(String country, String currency) async {
    await _analytics.logEvent(
      name: 'country_selected',
      parameters: {
        'country': country,
        'currency': currency,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track when user selects a budget
  Future<void> logBudgetSelection(double amount, String label) async {
    await _analytics.logEvent(
      name: 'budget_selected',
      parameters: {
        'amount': amount,
        'budget_label': label,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track when user starts a new game
  Future<void> logGameStart(double budget, String country) async {
    await _analytics.logEvent(
      name: 'game_started',
      parameters: {
        'budget': budget,
        'country': country,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track item purchase
  Future<void> logItemPurchase({
    required String itemName,
    required int quantity,
    required double price,
    required double totalSpent,
    required double remaining,
  }) async {
    await _analytics.logEvent(
      name: 'item_purchased',
      parameters: {
        'item_name': itemName,
        'quantity': quantity,
        'price': price,
        'total_spent': totalSpent,
        'remaining_balance': remaining,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track item sale
  Future<void> logItemSale({
    required String itemName,
    required int quantity,
    required double price,
    required double totalSpent,
    required double remaining,
  }) async {
    await _analytics.logEvent(
      name: 'item_sold',
      parameters: {
        'item_name': itemName,
        'quantity': quantity,
        'price': price,
        'total_spent': totalSpent,
        'remaining_balance': remaining,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track game mode change
  Future<void> logGameModeChange(String mode) async {
    await _analytics.logEvent(
      name: 'game_mode_changed',
      parameters: {
        'mode': mode,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track view receipt action
  Future<void> logReceiptViewed(double totalSpent, double budget, int itemsCount) async {
    await _analytics.logEvent(
      name: 'receipt_viewed',
      parameters: {
        'total_spent': totalSpent,
        'budget': budget,
        'items_count': itemsCount,
        'percentage_spent': (totalSpent / budget * 100).toStringAsFixed(2),
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track new game button click
  Future<void> logNewGameStarted() async {
    await _analytics.logEvent(
      name: 'new_game_clicked',
      parameters: {
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track continue game action
  Future<void> logContinueGame() async {
    await _analytics.logEvent(
      name: 'continue_game',
      parameters: {
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track quit game action
  Future<void> logQuitGame(double spent, double budget) async {
    await _analytics.logEvent(
      name: 'game_quit',
      parameters: {
        'total_spent': spent,
        'budget': budget,
        'percentage_spent': (spent / budget * 100).toStringAsFixed(2),
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track settings menu opened
  Future<void> logSettingsOpened() async {
    await _analytics.logEvent(
      name: 'settings_opened',
      parameters: {
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track ads toggle
  Future<void> logAdsToggle(bool adsEnabled) async {
    await _analytics.logEvent(
      name: 'ads_toggled',
      parameters: {
        'ads_enabled': adsEnabled,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track ad impression
  Future<void> logAdImpression(String adType) async {
    await _analytics.logEvent(
      name: 'ad_impression',
      parameters: {
        'ad_type': adType,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track user properties for segmentation
  Future<void> setUserProperties({
    required bool adsEnabled,
    String? country,
  }) async {
    await _analytics.setUserProperty(
      name: 'ads_enabled',
      value: adsEnabled.toString(),
    );
    if (country != null) {
      await _analytics.setUserProperty(
        name: 'country',
        value: country,
      );
    }
  }

  /// Track session duration custom metric
  Future<void> logSessionDuration(int seconds) async {
    await _analytics.logEvent(
      name: 'session_duration',
      parameters: {
        'duration_seconds': seconds,
        'duration_minutes': (seconds / 60).toStringAsFixed(2),
      },
    );
  }

  /// Track item navigation (next/prev)
  Future<void> logItemNavigation(String direction, String currentItem) async {
    await _analytics.logEvent(
      name: 'item_navigation',
      parameters: {
        'direction': direction,
        'current_item': currentItem,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track quantity change
  Future<void> logQuantityChange(String item, int oldQty, int newQty) async {
    await _analytics.logEvent(
      name: 'quantity_changed',
      parameters: {
        'item_name': item,
        'old_quantity': oldQty,
        'new_quantity': newQty,
        'change': newQty - oldQty,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
  }

  /// Track app open
  Future<void> logAppOpen() async {
    await _analytics.logAppOpen();
  }

  /// Track search (if implemented)
  Future<void> logSearch(String searchTerm) async {
    await _analytics.logSearch(searchTerm: searchTerm);
  }

  /// Track share (if implemented)
  Future<void> logShare({
    required String contentType,
    required String itemId,
    String? method,
  }) async {
    await _analytics.logShare(
      contentType: contentType,
      itemId: itemId,
      method: method ?? 'unknown',
    );
  }

  /// Get analytics instance for advanced usage
  FirebaseAnalytics get analytics => _analytics;
}

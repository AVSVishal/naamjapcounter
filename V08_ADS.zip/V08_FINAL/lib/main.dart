import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'theme/app_theme.dart';
import 'router/app_router.dart';
import 'providers/game_provider.dart';
import 'services/ad_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Ad Service
  AdService().initialize();
  
  runApp(
    ChangeNotifierProvider(
      create: (_) => GameProvider(),
      child: const SpendTheMoneyApp(),
    ),
  );
}

class SpendTheMoneyApp extends StatefulWidget {
  const SpendTheMoneyApp({super.key});

  @override
  State<SpendTheMoneyApp> createState() => _SpendTheMoneyAppState();
}

class _SpendTheMoneyAppState extends State<SpendTheMoneyApp>
    with WidgetsBindingObserver {
  
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    // Show app open ad on first launch (after init)
    Future.delayed(const Duration(seconds: 2), () {
      AdService().showAppOpenAd();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AdService().dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Show app open ad when app comes to foreground
    if (state == AppLifecycleState.resumed) {
      AdService().showAppOpenAd();
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Spend The Money',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.light,
      routerConfig: appRouter,
    );
  }
}

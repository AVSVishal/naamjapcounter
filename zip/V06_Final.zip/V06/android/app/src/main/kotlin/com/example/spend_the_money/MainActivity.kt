package com.example.spend_the_money

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

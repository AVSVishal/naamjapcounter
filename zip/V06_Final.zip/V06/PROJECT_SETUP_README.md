# 🚀 Spend The Money - One Click Build System

## ⚡ QUICK START (Sirf 1 Click mein Sab Kuch!)

### Step 1: Project Extract Karo
V06 folder ko kahi bhi extract karo

### Step 2: Terminal Open Karo (Android Studio ya VS Code)
V06 folder mein jaao:
```bash
cd V06
```

### Step 3: EK COMMAND RUN KARO! 🎯
```bash
bash ONE_CLICK_BUILD.sh
```

**Bas Itna Hi!** Script automatically:
1. ✅ Keystore generate karega
2. ✅ key.properties file create karega  
3. ✅ Flutter clean karega
4. ✅ Dependencies download karega
5. ✅ App Bundle (AAB) build karega

---

## 📋 Script Kya Karega (Step by Step)

Jab aap `bash ONE_CLICK_BUILD.sh` run karte ho:

### 1️⃣ Keystore Details Maangega:
```
🔑 Enter keystore password (min 6 chars): ********
🔑 Re-enter password: ********
👤 Your First and Last Name: Vishal Sharma
🏢 Organization: AVSVishalMedia
🌆 City: Mumbai
🗺️  State: Maharashtra
🇮🇳 Country Code: IN
```

### 2️⃣ Automatic Ho Jaayega:
- `android/spend-money.keystore` create
- `android/key.properties` create
- `flutter clean`
- `flutter pub get`
- `flutter build appbundle`

### 3️⃣ Output Milega:
```
✅ BUILD SUCCESSFUL!
📦 AAB File: build/app/outputs/bundle/release/app-release.aab
📊 File Size: 25MB
```

---

## 🎯 Ab Play Store Pe Upload Karo!

### 1. Google Play Console Open Karo
https://play.google.com/console

### 2. Production → Create New Release

### 3. AAB File Upload Karo
File location: `build/app/outputs/bundle/release/app-release.aab`

### 4. Rollout! 🎉

---

## ⚠️ IMPORTANT WARNINGS

### 🔐 Keystore Backup Zaroori Hai!
```
android/spend-money.keystore
```
Is file ko KHO MAT DENA! Iske bina future updates nahi dal paoge.

**Backup Locations:**
- Google Drive
- External Hard Drive
- Email yourself

### 🔑 Password Yaad Rakho!
Key.properties mein password save hai. Isko secure jagah pe likh lo.

---

## 🐛 Agar Error Aaye To

### Error 1: "pubspec.yaml not found"
**Solution:** V06 folder mein jaao:
```bash
cd V06
bash ONE_CLICK_BUILD.sh
```

### Error 2: "keytool not found"
**Solution:** Java install karo ya Android Studio ke bundled Java use karo:
```bash
export PATH="$PATH:/path/to/android-studio/jbr/bin"
```

### Error 3: "flutter: command not found"
**Solution:** Flutter path add karo:
```bash
export PATH="$PATH:/path/to/flutter/bin"
```

---

## 📱 Manual Commands (Agar Script Use Nahi Karna)

### Keystore Manually:
```bash
cd android
keytool -genkey -v -keystore spend-money.keystore -alias spendmoney -keyalg RSA -keysize 2048 -validity 10000
```

### Key.properties Manually:
```bash
cd android
cat > key.properties << EOF
storePassword=YOUR_PASSWORD
keyPassword=YOUR_PASSWORD
keyAlias=spendmoney
storeFile=spend-money.keystore
EOF
```

### Build Manually:
```bash
flutter clean
flutter pub get
flutter build appbundle
```

---

## 🎓 Project Structure

```
V06/
├── android/
│   ├── app/
│   │   └── build.gradle.kts    ← Already configured for signing
│   ├── spend-money.keystore    ← Script creates this
│   └── key.properties          ← Script creates this
├── lib/                         ← All Dart code
├── assets/images/               ← Game images
├── ONE_CLICK_BUILD.sh          ← 🔥 ONE CLICK SCRIPT
├── pubspec.yaml                ← Dependencies
└── PROJECT_SETUP_README.md     ← This file
```

---

## ✅ Pre-Build Checklist

- [ ] Flutter installed hai
- [ ] Android Studio/VS Code mein project open kiya
- [ ] Terminal ready hai
- [ ] Internet connection hai (dependencies ke liye)

---

**Ready? Run: `bash ONE_CLICK_BUILD.sh`** 🚀

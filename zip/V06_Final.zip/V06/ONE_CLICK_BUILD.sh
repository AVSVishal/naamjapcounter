#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# 🚀 SPEND THE MONEY - ONE CLICK BUILD & KEYSTORE SETUP
# ═══════════════════════════════════════════════════════════════════
# Bas is script ko run karo - sab kuch automatic ho jaayega!
# Ye script: Keystore generate karega + key.properties create karega + AAB build karega
# ═══════════════════════════════════════════════════════════════════

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║     🚀 SPEND THE MONEY - ONE CLICK BUILD SYSTEM                  ║"
echo "║        Keystore + Key.properties + AAB Build                   ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Check if we're in project root
if [ ! -f "pubspec.yaml" ]; then
    echo -e "${RED}❌ ERROR: pubspec.yaml not found!${NC}"
    echo "Please run this script from the project root folder (V06/)"
    echo "Example: cd V06 && bash ONE_CLICK_BUILD.sh"
    exit 1
fi

PROJECT_ROOT=$(pwd)
echo -e "${BLUE}📁 Project root: $PROJECT_ROOT${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════
# STEP 1: KEYSTORE SETUP (in android/ folder)
# ═══════════════════════════════════════════════════════════════════
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}🔐 STEP 1: KEYSTORE SETUP${NC}"
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════${NC}"
echo ""

cd android

KEYSTORE_FILE="spend-money.keystore"
ALIAS_NAME="spendmoney"

# Check if keystore already exists
if [ -f "$KEYSTORE_FILE" ]; then
    echo -e "${YELLOW}⚠️  Keystore already exists: $KEYSTORE_FILE${NC}"
    read -p "Do you want to use existing keystore? (Y/n): " use_existing
    if [[ $use_existing =~ ^[Nn]$ ]]; then
        read -p "Delete old keystore and create new? (y/N): " delete_old
        if [[ $delete_old =~ ^[Yy]$ ]]; then
            rm "$KEYSTORE_FILE"
            echo -e "${GREEN}✅ Old keystore deleted${NC}"
        else
            echo -e "${YELLOW}Using existing keystore...${NC}"
            # Check if key.properties exists
            if [ ! -f "key.properties" ]; then
                echo -e "${YELLOW}⚠️  key.properties not found. Creating from existing keystore...${NC}"
                read -s -p "Enter keystore password: " EXISTING_PASS
                echo ""
                cat > key.properties << EOF
storePassword=$EXISTING_PASS
keyPassword=$EXISTING_PASS
keyAlias=$ALIAS_NAME
storeFile=$KEYSTORE_FILE
EOF
                echo -e "${GREEN}✅ key.properties created!${NC}"
            fi
            SKIP_KEYSTORE=true
        fi
    else
        SKIP_KEYSTORE=true
    fi
else
    SKIP_KEYSTORE=false
fi

# Generate new keystore if needed
if [ "$SKIP_KEYSTORE" != "true" ]; then
    echo ""
    echo -e "${BLUE}📋 Please enter keystore details:${NC}"
    echo "═══════════════════════════════════════"
    echo ""
    
    read -s -p "🔑 Enter keystore password (min 6 chars): " PASSWORD
    echo ""
    read -s -p "🔑 Re-enter password: " PASSWORD_CONFIRM
    echo ""
    
    if [ "$PASSWORD" != "$PASSWORD_CONFIRM" ]; then
        echo -e "${RED}❌ ERROR: Passwords do not match!${NC}"
        exit 1
    fi
    
    if [ ${#PASSWORD} -lt 6 ]; then
        echo -e "${RED}❌ ERROR: Password must be at least 6 characters!${NC}"
        exit 1
    fi
    
    echo ""
    read -p "👤 Your First and Last Name (e.g., Vishal Sharma): " NAME
    read -p "🏢 Organization (e.g., AVSVishalMedia): " ORG
    read -p "🌆 City (e.g., Mumbai): " CITY
    read -p "🗺️  State (e.g., Maharashtra): " STATE
    read -p "🇮🇳 Country Code (2 letters, e.g., IN): " COUNTRY
    
    echo ""
    echo -e "${YELLOW}🔨 Generating keystore...${NC}"
    echo ""
    
    keytool -genkey -v \
        -keystore "$KEYSTORE_FILE" \
        -alias "$ALIAS_NAME" \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass "$PASSWORD" \
        -keypass "$PASSWORD" \
        -dname "CN=$NAME, OU=$ORG, O=$ORG, L=$CITY, ST=$STATE, C=$COUNTRY" \
        2>&1
    
    if [ $? -eq 0 ]; then
        echo ""
        echo -e "${GREEN}✅ Keystore created successfully!${NC}"
        
        # Create key.properties
        cat > key.properties << EOF
storePassword=$PASSWORD
keyPassword=$PASSWORD
keyAlias=$ALIAS_NAME
storeFile=$KEYSTORE_FILE
EOF
        echo -e "${GREEN}✅ key.properties created!${NC}"
        
        # Show info
        echo ""
        echo -e "${BLUE}📊 Keystore Info:${NC}"
        keytool -list -v -keystore "$KEYSTORE_FILE" -alias "$ALIAS_NAME" -storepass "$PASSWORD" 2>&1 | grep -E "(Alias|Creation|Owner|Valid)"
    else
        echo -e "${RED}❌ Keystore generation failed!${NC}"
        exit 1
    fi
fi

cd "$PROJECT_ROOT"

# ═══════════════════════════════════════════════════════════════════
# STEP 2: FLUTTER CLEAN & GET DEPENDENCIES
# ═══════════════════════════════════════════════════════════════════
echo ""
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}📦 STEP 2: CLEAN & GET DEPENDENCIES${NC}"
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${BLUE}🧹 Running flutter clean...${NC}"
flutter clean

echo -e "${BLUE}📥 Running flutter pub get...${NC}"
flutter pub get

# ═══════════════════════════════════════════════════════════════════
# STEP 3: BUILD APP BUNDLE
# ═══════════════════════════════════════════════════════════════════
echo ""
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}🏗️  STEP 3: BUILD APP BUNDLE (AAB)${NC}"
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${BLUE}🔨 Building App Bundle for Play Store...${NC}"
flutter build appbundle

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                   ✅ BUILD SUCCESSFUL!                           ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    AAB_PATH="build/app/outputs/bundle/release/app-release.aab"
    
    if [ -f "$AAB_PATH" ]; then
        FILE_SIZE=$(ls -lh "$AAB_PATH" | awk '{print $5}')
        echo -e "${GREEN}📦 AAB File: $AAB_PATH${NC}"
        echo -e "${GREEN}📊 File Size: $FILE_SIZE${NC}"
        echo ""
        echo -e "${YELLOW}⚠️  IMPORTANT:${NC}"
        echo -e "${YELLOW}   • Backup your keystore: android/$KEYSTORE_FILE${NC}"
        echo -e "${YELLOW}   • Save password safely - you'll need it for updates${NC}"
        echo -e "${YELLOW}   • Upload this AAB to Google Play Console${NC}"
        echo ""
        echo -e "${BLUE}🎉 Ready to upload to Play Store!${NC}"
    else
        echo -e "${RED}❌ AAB file not found at expected location${NC}"
    fi
else
    echo ""
    echo -e "${RED}❌ BUILD FAILED!${NC}"
    echo "Check the error messages above."
    exit 1
fi

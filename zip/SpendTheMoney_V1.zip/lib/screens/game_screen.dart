import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:gap/gap.dart';
import '../models/shop_item.dart';
import '../providers/game_provider.dart';
import '../theme/app_theme.dart';
import '../utils/currency_formatter.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  final _qtyController = TextEditingController(text: '1');
  final _qtyFocus = FocusNode();
  GameMode _mode = GameMode.normal;

  late AnimationController _balanceAnimController;
  int _displayedBalance = 0;
  int _previousBalance = 0;

  final Map<int, int> _gridQty = {};

  @override
  void initState() {
    super.initState();
    _balanceAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    final provider = context.read<GameProvider>();
    _displayedBalance = provider.balance;
    _previousBalance = provider.balance;
  }

  @override
  void dispose() {
    _qtyController.dispose();
    _qtyFocus.dispose();
    _balanceAnimController.dispose();
    super.dispose();
  }

  void _animateBalance(int from, int to) {
    _previousBalance = from;
    _balanceAnimController.reset();
    _balanceAnimController.addListener(_balanceListener);
    _balanceAnimController.forward().then((_) {
      _balanceAnimController.removeListener(_balanceListener);
      setState(() => _displayedBalance = to);
    });
  }

  void _balanceListener() {
    final provider = context.read<GameProvider>();
    setState(() {
      _displayedBalance = (_previousBalance +
              (_balanceAnimController.value * (provider.balance - _previousBalance)))
          .round();
    });
  }

  void _onBuy() {
    final provider = context.read<GameProvider>();
    final qty = int.tryParse(_qtyController.text) ?? 0;
    final oldBal = provider.balance;
    if (provider.buyItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      FocusScope.of(context).unfocus();
    } else {
      _showSnack(provider.lastMessage);
    }
  }

  void _onSell() {
    final provider = context.read<GameProvider>();
    final qty = int.tryParse(_qtyController.text) ?? 0;
    final oldBal = provider.balance;
    if (provider.sellItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      FocusScope.of(context).unfocus();
    } else {
      _showSnack(provider.lastMessage);
    }
  }

  void _onGridBuy(int itemIndex, int qty) {
    final provider = context.read<GameProvider>();
    final oldIdx = provider.currentIndex;
    provider.goToItem(itemIndex);
    final oldBal = provider.balance;
    if (provider.buyItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      setState(() => _gridQty[itemIndex] = 1);
    } else {
      _showSnack(provider.lastMessage);
    }
    provider.goToItem(oldIdx);
  }

  void _onGridSell(int itemIndex, int qty) {
    final provider = context.read<GameProvider>();
    final oldIdx = provider.currentIndex;
    provider.goToItem(itemIndex);
    final oldBal = provider.balance;
    if (provider.sellItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      setState(() => _gridQty[itemIndex] = 1);
    } else {
      _showSnack(provider.lastMessage);
    }
    provider.goToItem(oldIdx);
  }

  void _showSnack(String msg) {
    if (msg.isEmpty) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(msg),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 80),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  void _navigateItem(int dir) {
    final provider = context.read<GameProvider>();
    _qtyController.text = '1';
    FocusScope.of(context).unfocus();
    if (dir > 0) provider.nextItem();
    if (dir < 0) provider.prevItem();
  }

  void _incrementQty() {
    final current = int.tryParse(_qtyController.text) ?? 0;
    _qtyController.text = '${current + 1}';
  }

  void _decrementQty() {
    final current = int.tryParse(_qtyController.text) ?? 0;
    if (current > 1) _qtyController.text = '${current - 1}';
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<GameProvider>();

    if (_displayedBalance != provider.balance && !_balanceAnimController.isAnimating) {
      _displayedBalance = provider.balance;
    }

    final balanceText = CurrencyFormatter.format(
      _displayedBalance,
      indian: provider.isIndia,
      symbol: provider.country.currencySymbol,
    );

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _showExitDialog();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _buildTopBar(provider),
              Expanded(
                child: switch (_mode) {
                  GameMode.normal => _buildNormalMode(provider),
                  GameMode.grid => _buildGridMode(provider),
                  GameMode.reel => _buildReelMode(provider),
                },
              ),
              _buildBalanceBar(balanceText),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(GameProvider provider) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          IconButton(
            onPressed: _showExitDialog,
            icon: const Icon(Icons.close_rounded, color: Color(0xFF666666)),
          ),
          const Spacer(),
          _buildModeChip(GameMode.normal, Icons.view_agenda_outlined, 'Normal'),
          const Gap(4),
          _buildModeChip(GameMode.grid, Icons.grid_view_outlined, 'Grid'),
          const Gap(4),
          _buildModeChip(GameMode.reel, Icons.videocam_outlined, 'Reel'),
          const Spacer(),
          IconButton(
            onPressed: () => _showReceiptSheet(provider),
            icon: const Icon(Icons.receipt_long_outlined, color: Color(0xFF666666)),
          ),
        ],
      ),
    );
  }

  Widget _buildModeChip(GameMode mode, IconData icon, String label) {
    final isActive = _mode == mode;
    return GestureDetector(
      onTap: () => setState(() => _mode = mode),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? AppTheme.buyColor : const Color(0xFFF3F4F6),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: isActive ? Colors.white : const Color(0xFF666666)),
            if (isActive) ...[
              const Gap(4),
              Text(label,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: isActive ? Colors.white : const Color(0xFF666666),
                  )),
            ],
          ],
        ),
      ),
    );
  }

  // ─── NORMAL MODE ───────────────────────────────────────
  Widget _buildNormalMode(GameProvider provider) {
    final item = provider.currentItem;
    final price = item.price(provider.isIndia);
    final formattedPrice = provider.formatPrice(price);

    return Column(
      children: [
        Expanded(
          child: GestureDetector(
            onHorizontalDragEnd: (d) {
              if (d.primaryVelocity != null) {
                if (d.primaryVelocity! < -100) _navigateItem(1);
                if (d.primaryVelocity! > 100) _navigateItem(-1);
              }
            },
            behavior: HitTestBehavior.opaque,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: Column(
                key: ValueKey(provider.currentIndex),
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildItemImage(item, size: 160),
                  const Gap(16),
                  Text(item.name,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF111827))),
                  const Gap(4),
                  Text(formattedPrice,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w700, color: AppTheme.priceColor)),
                  const Gap(8),
                  if (item.owned > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text('Owned: ${item.owned}',
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF374151))),
                    ),
                ],
              ),
            ),
          ),
        ),
        _buildNavArrows(provider),
        _buildQuantityRow(),
        const Gap(8),
        _buildBuySellRow(),
        const Gap(12),
      ],
    );
  }

  Widget _buildNavArrows(GameProvider provider) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          IconButton(
            onPressed: provider.currentIndex > 0 ? () => _navigateItem(-1) : null,
            icon: Icon(Icons.chevron_left_rounded,
                size: 36,
                color: provider.currentIndex > 0
                    ? const Color(0xFF111827)
                    : const Color(0xFFD1D5DB)),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text('${provider.currentIndex + 1} / ${provider.totalItems}',
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF6B7280))),
          ),
          const Spacer(),
          IconButton(
            onPressed: provider.currentIndex < provider.totalItems - 1
                ? () => _navigateItem(1)
                : null,
            icon: Icon(Icons.chevron_right_rounded,
                size: 36,
                color: provider.currentIndex < provider.totalItems - 1
                    ? const Color(0xFF111827)
                    : const Color(0xFFD1D5DB)),
          ),
        ],
      ),
    );
  }

  Widget _buildQuantityRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildCircleBtn(Icons.remove, _decrementQty),
          const Gap(12),
          Expanded(
            child: SizedBox(
              height: 48,
              child: TextField(
                controller: _qtyController,
                focusNode: _qtyFocus,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Color(0xFF111827)),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(9),
                ],
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.black, width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.black, width: 2),
                  ),
                ),
              ),
            ),
          ),
          const Gap(12),
          _buildCircleBtn(Icons.add, _incrementQty),
        ],
      ),
    );
  }

  Widget _buildCircleBtn(IconData icon, VoidCallback onTap) {
    return Material(
      color: const Color(0xFFF3F4F6),
      shape: const CircleBorder(),
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 48,
          height: 48,
          alignment: Alignment.center,
          child: Icon(icon, size: 24, color: const Color(0xFF111827)),
        ),
      ),
    );
  }

  Widget _buildBuySellRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Expanded(
            child: SizedBox(
              height: 54,
              child: ElevatedButton(
                onPressed: _onSell,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.sellColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: EdgeInsets.zero,
                ),
                child: const Text('Sell',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ),
          ),
          const Gap(12),
          Expanded(
            child: SizedBox(
              height: 54,
              child: ElevatedButton(
                onPressed: _onBuy,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.buyColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: EdgeInsets.zero,
                ),
                child: const Text('Buy',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── GRID MODE ─────────────────────────────────────────
  Widget _buildGridMode(GameProvider provider) {
    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.56,
      ),
      itemCount: provider.totalItems,
      itemBuilder: (ctx, index) => _buildGridCard(provider, index),
    );
  }

  Widget _buildGridCard(GameProvider provider, int idx) {
    final item = provider.items[idx];
    final price = item.price(provider.isIndia);
    final formattedPrice = provider.formatPrice(price);
    final qty = _gridQty[idx] ?? 1;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Expanded(
            flex: 5,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
              child: _buildNetworkImage(item, double.infinity),
            ),
          ),
          Expanded(
            flex: 6,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Column(
                children: [
                  Text(item.name,
                      style: const TextStyle(
                          fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF111827)),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  Text(formattedPrice,
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.priceColor)),
                  if (item.owned > 0)
                    Text('Owned: ${item.owned}',
                        style: const TextStyle(
                            fontSize: 10, fontWeight: FontWeight.w500, color: Color(0xFF9CA3AF))),
                  const Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _gridSmallBtn(Icons.remove, () {
                        if (qty > 1) setState(() => _gridQty[idx] = qty - 1);
                      }),
                      Container(
                        width: 36,
                        alignment: Alignment.center,
                        child: Text('$qty',
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
                      ),
                      _gridSmallBtn(Icons.add, () {
                        setState(() => _gridQty[idx] = qty + 1);
                      }),
                    ],
                  ),
                  const Gap(4),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 32,
                          child: ElevatedButton(
                            onPressed: () => _onGridSell(idx, qty),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.sellColor,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.zero,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('Sell',
                                style: TextStyle(
                                    fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
                          ),
                        ),
                      ),
                      const Gap(6),
                      Expanded(
                        child: SizedBox(
                          height: 32,
                          child: ElevatedButton(
                            onPressed: () => _onGridBuy(idx, qty),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.buyColor,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.zero,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('Buy',
                                style: TextStyle(
                                    fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _gridSmallBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: const Color(0xFFF3F4F6),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, size: 16, color: const Color(0xFF374151)),
      ),
    );
  }

  // ─── REEL MODE ─────────────────────────────────────────
  Widget _buildReelMode(GameProvider provider) {
    final item = provider.currentItem;
    final price = item.price(provider.isIndia);
    final formattedPrice = provider.formatPrice(price);

    return Column(
      children: [
        Expanded(
          flex: 4,
          child: Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF059669), Color(0xFF10B981)],
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('SPEND THE MONEY',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 2,
                    )),
                const Gap(8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Budget: ${provider.formattedBudget}',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white),
                  ),
                ),
                const Gap(8),
                Text(
                  '${provider.spentPercentage.toStringAsFixed(1)}% spent',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.white.withValues(alpha: 0.8)),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          flex: 6,
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                const Gap(10),
                Expanded(
                  child: GestureDetector(
                    onHorizontalDragEnd: (d) {
                      if (d.primaryVelocity != null) {
                        if (d.primaryVelocity! < -100) _navigateItem(1);
                        if (d.primaryVelocity! > 100) _navigateItem(-1);
                      }
                    },
                    behavior: HitTestBehavior.opaque,
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      child: Row(
                        key: ValueKey(provider.currentIndex),
                        children: [
                          IconButton(
                            onPressed: provider.currentIndex > 0
                                ? () => _navigateItem(-1)
                                : null,
                            icon: Icon(Icons.chevron_left_rounded,
                                size: 32,
                                color: provider.currentIndex > 0
                                    ? const Color(0xFF111827)
                                    : const Color(0xFFD1D5DB)),
                          ),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                _buildItemImage(item, size: 90),
                                const Gap(6),
                                Text(item.name,
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800,
                                        color: Color(0xFF111827))),
                                Text(formattedPrice,
                                    style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700,
                                        color: AppTheme.priceColor)),
                                if (item.owned > 0)
                                  Text('Owned: ${item.owned}',
                                      style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500,
                                          color: Color(0xFF9CA3AF))),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: provider.currentIndex < provider.totalItems - 1
                                ? () => _navigateItem(1)
                                : null,
                            icon: Icon(Icons.chevron_right_rounded,
                                size: 32,
                                color: provider.currentIndex < provider.totalItems - 1
                                    ? const Color(0xFF111827)
                                    : const Color(0xFFD1D5DB)),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildCircleBtn(Icons.remove, _decrementQty),
                      const Gap(8),
                      SizedBox(
                        width: 80,
                        height: 42,
                        child: TextField(
                          controller: _qtyController,
                          focusNode: _qtyFocus,
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF111827)),
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(9),
                          ],
                          decoration: InputDecoration(
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: Colors.black, width: 2),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: Colors.black, width: 2),
                            ),
                          ),
                        ),
                      ),
                      const Gap(8),
                      _buildCircleBtn(Icons.add, _incrementQty),
                    ],
                  ),
                ),
                const Gap(8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 46,
                          child: ElevatedButton(
                            onPressed: _onSell,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.sellColor,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              padding: EdgeInsets.zero,
                            ),
                            child: const Text('Sell',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white)),
                          ),
                        ),
                      ),
                      const Gap(10),
                      Expanded(
                        child: SizedBox(
                          height: 46,
                          child: ElevatedButton(
                            onPressed: _onBuy,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.buyColor,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              padding: EdgeInsets.zero,
                            ),
                            child: const Text('Buy',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const Gap(8),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── SHARED WIDGETS ────────────────────────────────────
  Widget _buildItemImage(ShopItem item, {double size = 140}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.network(
        item.imageUrl,
        width: size,
        height: size,
        fit: BoxFit.cover,
        loadingBuilder: (ctx, child, progress) {
          if (progress == null) return child;
          return Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: item.iconColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Center(
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color: item.iconColor,
                ),
              ),
            ),
          );
        },
        errorBuilder: (ctx, err, stack) {
          return Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: item.iconColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(item.icon, size: size * 0.45, color: item.iconColor),
          );
        },
      ),
    );
  }

  Widget _buildNetworkImage(ShopItem item, double width) {
    return Image.network(
      item.imageUrl,
      width: width,
      fit: BoxFit.cover,
      loadingBuilder: (ctx, child, progress) {
        if (progress == null) return child;
        return Container(
          color: item.iconColor.withValues(alpha: 0.08),
          child: Center(
            child: SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: item.iconColor),
            ),
          ),
        );
      },
      errorBuilder: (ctx, err, stack) {
        return Container(
          color: item.iconColor.withValues(alpha: 0.1),
          child: Icon(item.icon, size: 48, color: item.iconColor),
        );
      },
    );
  }

  Widget _buildBalanceBar(String balanceText) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: 16,
        bottom: MediaQuery.of(context).padding.bottom + 16,
        left: 16,
        right: 16,
      ),
      decoration: BoxDecoration(
        color: AppTheme.balanceBarColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.balanceBarColor.withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Text(
        balanceText,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w800,
          color: Colors.white,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  void _showExitDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Quit Game?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
        content: const Text('Your progress will be lost.',
            style: TextStyle(color: Color(0xFF6B7280))),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              context.read<GameProvider>().resetGame();
              context.go('/home');
            },
            child: const Text('Quit', style: TextStyle(color: AppTheme.sellColor)),
          ),
        ],
      ),
    );
  }

  void _showReceiptSheet(GameProvider provider) {
    final purchased = provider.items.where((i) => i.owned > 0).toList();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.3,
        maxChildSize: 0.9,
        builder: (ctx, scroll) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              const Gap(8),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFD1D5DB),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Gap(16),
              const Text('Your Purchases',
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
              const Gap(4),
              Text('Spent: ${provider.formattedSpent}',
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.sellColor)),
              const Gap(16),
              Expanded(
                child: purchased.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.shopping_cart_outlined,
                                size: 48, color: Color(0xFFD1D5DB)),
                            Gap(12),
                            Text('No purchases yet',
                                style: TextStyle(fontSize: 16, color: Color(0xFF9CA3AF))),
                          ],
                        ),
                      )
                    : ListView.separated(
                        controller: scroll,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: purchased.length,
                        separatorBuilder: (_, __) =>
                            const Divider(color: Color(0xFFF3F4F6)),
                        itemBuilder: (ctx, i) {
                          final p = purchased[i];
                          final total = p.owned * p.price(provider.isIndia);
                          return ListTile(
                            leading: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                p.imageUrl,
                                width: 44,
                                height: 44,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: p.iconColor.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(p.icon, color: p.iconColor, size: 24),
                                ),
                              ),
                            ),
                            title: Text(p.name,
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF111827))),
                            subtitle: Text('x${p.owned}',
                                style: const TextStyle(
                                    fontSize: 12, color: Color(0xFF9CA3AF))),
                            trailing: Text(provider.formatPrice(total),
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.priceColor)),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

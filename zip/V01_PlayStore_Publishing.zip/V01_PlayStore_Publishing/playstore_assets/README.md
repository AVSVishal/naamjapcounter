# 📱 Play Store Assets - Spend The Money

## Required Assets for Google Play Console

### 1. App Icon (MANDATORY)
- **File:** `app_icon.png`
- **Size:** 512 x 512 px
- **Format:** PNG (32-bit PNG with alpha)
- **Use:** Play Store listing and device icon

### 2. Feature Graphic (MANDATORY)
- **File:** `feature_graphic.png`
- **Size:** 1024 x 500 px
- **Format:** PNG or JPEG (no alpha)
- **Use:** Top banner on Play Store page

### 3. Phone Screenshots (MANDATORY - min 2, max 8)
- **Folder:** `screenshots/`
- **Size:** 1080 x 1920 px (or any 9:16 aspect ratio)
- **Format:** PNG or JPEG
- **Screenshots included:**
  1. `screenshot_01_home.png` - Home screen with country/budget selection
  2. `screenshot_02_game.png` - Game screen in Normal mode
  3. `screenshot_03_grid.png` - Grid mode view
  4. `screenshot_04_receipt.png` - Receipt/summary screen
  5. `screenshot_05_reel.png` - Reel mode view
  6. `screenshot_06_items.png` - Luxury items showcase

### 4. Tablet Screenshots (OPTIONAL but recommended)
- **7-inch tablet:** 1080 x 1920 px (portrait) or 1920 x 1080 (landscape)
- **10-inch tablet:** Same sizes as 7-inch

### 5. Additional Graphics (OPTIONAL)
- Promo video (30-120 seconds)
- Promo graphic (180 x 120 px) - for old devices
- TV banner (1280 x 720 px) - for Android TV
- Wear OS screenshots (if applicable)

---

## Upload Instructions

1. Go to [Google Play Console](https://play.google.com/console)
2. Select your app
3. Go to "Store presence" → "Main store listing"
4. Upload assets in these sections:
   - **App icon:** Upload `app_icon.png`
   - **Feature graphic:** Upload `feature_graphic.png`
   - **Phone screenshots:** Upload all from `screenshots/` folder
   - **Tablet screenshots:** Upload if available

---

## Tips for Better Conversion

✅ **DO:**
- Use actual app screenshots, not mockups
- Show the most exciting/engaging screens
- Include text overlays if needed (but minimal)
- Ensure high quality (no blur)
- Follow the order: Home → Gameplay → Features → Results

❌ **DON'T:**
- Include device frames (Play Store adds them automatically)
- Show notifications or status bars with personal info
- Use misleading screenshots
- Include pricing/promo text in screenshots

---

## File Structure
```
playstore_assets/
├── app_icon.png          # 512x512
├── feature_graphic.png   # 1024x500
├── screenshots/
│   ├── screenshot_01_home.png
│   ├── screenshot_02_game.png
│   ├── screenshot_03_grid.png
│   ├── screenshot_04_receipt.png
│   ├── screenshot_05_reel.png
│   └── screenshot_06_items.png
└── README.md             # This file
```

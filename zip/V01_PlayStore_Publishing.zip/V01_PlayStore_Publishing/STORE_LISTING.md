# 📱 Play Store Listing Details - Spend The Money

## App Name
**Spend The Money**

## Short Description (80 characters max)
Can you spend billions? A fun shopping simulation game with 26 unique items!

## Full Description

```
💰 Welcome to Spend The Money - The Ultimate Shopping Simulation Game!

Think spending money is easy? Think again! Challenge yourself to spend massive budgets on everything from candy bars to space rockets, private jets to luxury islands.

🎮 HOW TO PLAY:
• Select your country (India 🇮🇳 or USA 🇺🇸)
• Choose your budget level - from ₹1 Lakh to ₹10,000 Crore!
• Browse 26 unique items across 3 game modes
• Buy and sell items to spend your entire budget
• Try to reach 100% spent for the ultimate victory!

🛍️ 26 UNIQUE ITEMS TO PURCHASE:
Start small with candy bars, coffee, and pizza. Work your way up to smartphones, gaming consoles, luxury cars, private jets, yachts, skyscrapers, and even a SPACE ROCKET!

🎲 3 EXCITING GAME MODES:
• Normal Mode: Classic scrollable item browsing
• Grid Mode: See all items at once in a 2x2 grid
• Reel Mode: Horizontal swipe for quick shopping

💵 REALISTIC CURRENCY:
• India: ₹ Rupees with Lakh/Crore formatting (₹1,00,000)
• USA: $ Dollars with K/M/B formatting ($1.5M, $2.5B)

🏆 6 BUDGET LEVELS:
• Easy: ₹1 Lakh / $1,000
• Medium: ₹10 Lakhs / $100,000
• Hard: ₹50 Lakhs / $1 Million
• Expert: ₹1 Crore / $10 Million
• Tycoon: ₹100 Crore / $1 Billion
• Ambani/Elon Mode: ₹10,000 Crore / $100 Billion

✨ FEATURES:
• Beautiful Material 3 design with smooth animations
• Real-time balance tracking with spending percentage
• Receipt screen showing all purchases
• Buy/Sell any quantity of items
• Indian and Western number formatting
• Offline play - no internet required!
• No ads, no in-app purchases
• Lightweight and fast

🎯 PERFECT FOR:
• Casual gamers who love simulation games
• Anyone curious about big numbers
• Fans of idle and tycoon games
• People who dream of spending billions!

📊 Track your spending percentage and see how much you've spent vs. your total budget. Can you spend it ALL?

Download now and start spending! 💸

---

Note: This is a simulation game for entertainment purposes. No real money is involved.
```

## Category
**Primary:** Game > Simulation
**Secondary:** Game > Casual

## Tags
- Shopping
- Simulation
- Casual
- Money
- Billionaire
- Idle
- Tycoon
- Fun

## Contact Details
**Website:** (Add your website)
**Email:** (Add your support email)
**Phone:** (Optional)

## Privacy Policy URL
(Upload privacy_policy.html to GitHub Pages or any hosting, then add URL here)
Example: `https://yourusername.github.io/spend-the-money/privacy_policy.html`

## App Access
**All functionality is available without special access**

## Target Audience
**Primarily for ages 13-35**
- Children under 13: No
- Teen (13-17): Yes
- Adult (18+): Yes

## App Pricing
**Free** - No in-app purchases, No ads

## Release Notes (First Release)
```
🎉 Initial Release - Version 1.0.0

Welcome to the first release of Spend The Money!

Features in this release:
• 26 unique items to purchase from candy to space rockets
• Dual country support: India (₹) & USA ($)
• 6 budget difficulty levels
• 3 game modes: Normal, Grid, and Reel
• Beautiful Material 3 UI design
• Real-time spending tracking
• Receipt summary screen
• Offline play support
• No ads, completely free!

We hope you enjoy spending billions! 💰
```

## What's New (For Updates)
```
Version 1.X.X:
• Bug fixes and performance improvements
• New items added
• UI enhancements
```

## Localization (Future)
- English (default)
- Hindi (coming soon)

# 🖥️ Android Studio Commands - Quick Reference

## Project Open Karne Ke Baad

### Terminal Open Karo
```
Menu: View > Tool Windows > Terminal
Ya
Shortcut: Alt + F12 (Windows/Linux)
Shortcut: Cmd + ` (Mac)
```

---

## 🔧 Essential Commands

### 1. Flutter Commands
```bash
# Debug run on connected device
flutter run

# Release mode run
flutter run --release

# Specific device pe run
flutter run -d <device_id>

# Build APK (for testing)
flutter build apk --release

# Build App Bundle (for Play Store)
flutter build appbundle

# Clean project
flutter clean

# Get dependencies
flutter pub get

# Upgrade dependencies
flutter pub upgrade

# Doctor check (issues find karo)
flutter doctor

# Doctor verbose
flutter doctor -v
```

### 2. Android Specific Commands
```bash
# Android folder mein jao
cd android

# Gradle clean
./gradlew clean

# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Build App Bundle
./gradlew bundleRelease

# Check connected devices
adb devices

# Install APK to device
adb install path/to/app.apk

# Logcat view
adb logcat

# Specific package log
adb logcat -s "flutter"
```

### 3. Keystore Commands
```bash
# Generate new keystore
keytool -genkey -v -keystore spend-money.keystore -alias spendmoney -keyalg RSA -keysize 2048 -validity 10000

# Keystore info check
keytool -list -v -keystore spend-money.keystore -alias spendmoney

# Export certificate
keytool -exportcert -alias spendmoney -keystore spend-money.keystore -file upload_certificate.pem
```

---

## 📦 Play Store Publishing Commands

### Step-by-Step App Bundle Build
```bash
# 1. Project root mein jao
cd /path/to/V06

# 2. Dependencies check karo
flutter pub get

# 3. Clean build
flutter clean

# 4. Code analyze karo
flutter analyze

# 5. Tests run karo
flutter test

# 6. Build App Bundle
flutter build appbundle

# 7. Output check karo
ls -la build/app/outputs/bundle/release/
```

### Signing Report Check
```bash
cd android
./gradlew signingReport
```

---

## 🐛 Debug Commands

### Hot Reload (Development)
```bash
# Terminal mein 'r' press karo (jab app running)
# Ya
flutter run --hot
```

### Hot Restart
```bash
# Terminal mein 'R' (capital) press karo
# Ya
flutter run --hot-restart
```

### Logs Dekhne Ke Liye
```bash
# All Flutter logs
flutter logs

# Specific device
flutter logs -d <device_id>
```

---

## 📱 Device Commands

### List Connected Devices
```bash
flutter devices
```

### Android Emulator Start
```bash
# List available emulators
flutter emulators

# Launch specific emulator
flutter emulators --launch <emulator_id>

# Create new emulator (Android Studio mein)
# Tools > Device Manager > Create Device
```

---

## 🎯 Build Variants

### APK Types
```bash
# Debug APK
flutter build apk --debug

# Release APK
flutter build apk --release

# Split APK by ABI
flutter build apk --release --split-per-abi
```

### App Bundle
```bash
# Release AAB (Play Store ke liye)
flutter build appbundle --release

# With verbose output
flutter build appbundle --verbose
```

---

## 🚀 Performance Commands

### Performance Profiling
```bash
# Profile mode run
flutter run --profile

# Performance overlay enable
flutter run --trace-skia
```

### Size Analysis
```bash
# APK size analyze
flutter build apk --analyze-size

# AAB size analyze
flutter build appbundle --analyze-size
```

---

## 📝 Code Quality

### Format Code
```bash
# Auto format all files
flutter format .

# Check format only
flutter format --dry-run .
```

### Analyze
```bash
# Static analysis
flutter analyze

# Fatal warnings treat as errors
flutter analyze --fatal-warnings
```

---

## 🔐 Security Commands

### Check Keystore
```bash
cd android

# Keystore content list
keytool -list -keystore spend-money.keystore

# Detailed info
keytool -list -v -keystore spend-money.keystore -alias spendmoney
```

### APK Sign Check
```bash
# APK signing check
cd android
apksigner verify -v ../build/app/outputs/flutter-apk/app-release.apk
```

---

## 🆘 Troubleshooting Commands

### Common Issues
```bash
# Cache clear
flutter pub cache clean

# Repair pub cache
flutter pub cache repair

# Delete build folders manually
rm -rf build/
rm -rf android/.gradle/
rm -rf android/app/build/

# Full clean (Android)
cd android
./gradlew clean
rm -rf build/
```

### Dependency Issues
```bash
# Outdated packages check
flutter pub outdated

# Upgrade specific package
flutter pub upgrade <package_name>

# Dependencies graph
flutter pub deps
```

---

## 📋 One-Line Build Script

Play Store ke liye complete build:
```bash
flutter clean && flutter pub get && flutter build appbundle && echo "✅ Build Complete!" && ls -lh build/app/outputs/bundle/release/
```

Output:
```
build/app/outputs/bundle/release/app-release.aab (20-30MB typically)
```

---

## 🎓 Pro Tips

1. **Auto-save**: Android Studio mein `Settings > Appearance & Behavior > System Settings > Auto-save` enable karo

2. **Hot Reload**: Code save karte hi automatic reload - `Settings > Languages & Frameworks > Flutter > Perform hot reload on save`

3. **Device Preview**: Multiple screen sizes test karne ke liye:
   ```bash
   flutter run -d chrome --web-port=8080
   ```

4. **Release Testing**: Pehle release APK device pe test karo:
   ```bash
   flutter build apk --release && flutter install
   ```

5. **Build Number Auto-increment**: `pubspec.yaml` mein version update mat bhoolna:
   ```yaml
   version: 1.0.1+2  # versionName + versionCode
   ```

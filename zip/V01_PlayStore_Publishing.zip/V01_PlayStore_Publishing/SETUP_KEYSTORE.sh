#!/bin/bash
# Play Store Keystore Setup Script for Spend The Money
# Run this in android/ folder

echo "🔐 Spend The Money - Keystore Setup"
echo "===================================="
echo ""

# Check if already exists
if [ -f "spend-money.keystore" ]; then
    echo "⚠️  Keystore already exists! Overwrite? (y/n)"
    read -r response
    if [ "$response" != "y" ]; then
        echo "❌ Setup cancelled."
        exit 1
    fi
fi

# Generate keystore
echo "📝 Generating keystore..."
echo "When prompted, enter these details:"
echo "  Password: SpendMoney2024! (or your own)"
echo "  Name: Your Name"
echo "  Organization: AVSVishalMedia"
echo "  City: Your City"
echo "  State: Your State"
echo "  Country: IN"
echo ""

keytool -genkey -v -keystore spend-money.keystore -alias spendmoney -keyalg RSA -keysize 2048 -validity 10000

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Keystore created successfully!"
    echo ""
    
    # Create key.properties
    echo "📝 Creating key.properties file..."
    
    echo "storePassword=SpendMoney2024!" > key.properties
    echo "keyPassword=SpendMoney2024!" >> key.properties
    echo "keyAlias=spendmoney" >> key.properties
    echo "storeFile=spend-money.keystore" >> key.properties
    
    echo ""
    echo "✅ key.properties created!"
    echo ""
    echo "🔒 IMPORTANT SECURITY NOTES:"
    echo "1. Keep spend-money.keystore SAFE - you'll need it for all updates"
    echo "2. Add key.properties to .gitignore"
    echo "3. Backup keystore file in secure location"
    echo ""
    echo "📋 Next Steps:"
    echo "1. Update key.properties with your actual password"
    echo "2. Copy build.gradle.kts template from publishing folder"
    echo "3. Run: flutter build appbundle"
    
else
    echo ""
    echo "❌ Keystore generation failed!"
    exit 1
fi

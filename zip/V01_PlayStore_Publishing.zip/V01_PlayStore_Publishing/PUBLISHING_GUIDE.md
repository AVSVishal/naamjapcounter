# 🚀 Play Store Publishing Guide - Spend The Money

## Step 1: App Bundle (AAB) Generate Karne Ke Liye

### 1.1 Terminal Open Karo (Android Studio Ya VS Code)

Project root folder mein jao:
```bash
cd V06
```

### 1.2 Keystore Generate Karo (Sirf Ek Baar)

Ye command terminal mein run karo:

```bash
cd android

keytool -genkey -v -keystore spend-money.keystore -alias spendmoney -keyalg RSA -keysize 2048 -validity 10000
```

**Details Enter Karo:**
- Enter keystore password: `SpendMoney2024!` (ya apna password)
- Re-enter password: same password
- What is your first and last name? `Your Name`
- What is the name of your organizational unit? `AVSVishalMedia`
- What is the name of your organization? `AVSVishalMedia`
- What is the name of your City or Locality? `Your City`
- What is the name of your State or Province? `Your State`
- What is the two-letter country code for this unit? `IN`
- Is CN=... correct? `yes`

Keystore file yahan banegi: `android/spend-money.keystore`

### 1.3 Key Properties File Create Karo

`android/key.properties` file create karo with this content:
```properties
storePassword=SpendMoney2024!
keyPassword=SpendMoney2024!
keyAlias=spendmoney
storeFile=spend-money.keystore
```

⚠️ **IMPORTANT:** Is file ko `.gitignore` mein add karo, kabhi push mat karo!

### 1.4 App Bundle Build Karo

```bash
cd android
./gradlew bundleRelease
```

**Ya Flutter se:**
```bash
flutter build appbundle
```

Output location:
```
build/app/outputs/bundle/release/app-release.aab
```

---

## Step 2: Google Play Console Setup

### 2.1 Developer Account
- [play.google.com/console](https://play.google.com/console) par jao
- $25 one-time fee pay karo
- Account verify karo

### 2.2 New App Create Karo
1. "Create app" click karo
2. App name: `Spend The Money`
3. Default language: `English (United States)`
4. App or Game: `Game`
5. Free or Paid: `Free`
6. Declarations check karo
7. "Create app" click karo

---

## Step 3: Store Listing Fill Karo

### 3.1 App Details
- **App name:** Spend The Money
- **Short description:** Can you spend billions? A fun shopping simulation game!
- **Full description:** (niche template hai)

### 3.2 Graphics Upload Karo
- **App icon:** (512 x 512 px) - `playstore_assets/app_icon.png`
- **Feature graphic:** (1024 x 500 px) - `playstore_assets/feature_graphic.png`
- **Phone screenshots:** (min 2, max 8) - `playstore_assets/screenshots/`
- **7-inch tablet:** Optional
- **10-inch tablet:** Optional

### 3.3 Categorization
- **Category:** Game > Simulation
- **Tags:** Shopping, Simulation, Casual, Money, Billionaire

---

## Step 4: Content Rating

1. Left menu se "Content rating" select karo
2. "Get started" click karo
3. Email address: apna email
4. Questionnaire fill karo:
   - Reference email: apna email
   - App mein violence? `No`
   - App mein fear? `No`
   - App mein sexual content? `No`
   - User generated content? `No`
5. "Save" then "Next"
6. "Submit" click karo

---

## Step 5: App Content

### 5.1 Privacy Policy
- Privacy policy URL: (niche template use karo hosting ke baad)
- Data safety section fill karo:
  - Data collected: `None` (ya analytics agar hai toh)
  - Data shared: `None`
  - Data encrypted: `Yes`
  - Users can delete data: `Yes`

### 5.2 Ads Declaration
- Contains ads? `No`

---

## Step 6: Pricing & Distribution

- Countries: `All countries`
- Contains ads: `No`
- Content guidelines: Accept karo
- US export laws: Accept karo

---

## Step 7: Release Karo

### 7.1 Production Track
1. Left menu: "Production"
2. "Create new release" click karo
3. App signing: Google-managed signing select karo
4. AAB file upload karo
5. Release notes add karo:
```
Initial release of Spend The Money!
- 26 unique items to purchase
- India & US currency support
- 3 game modes: Normal, Grid, Reel
- 6 budget levels from easy to billionaire
```
6. "Save" then "Next"
7. "Start rollout to Production"

---

## Quick Commands Summary

| Task | Command |
|------|---------|
| Debug run | `flutter run` |
| Release APK | `flutter build apk --release` |
| App Bundle | `flutter build appbundle` |
| Clean build | `flutter clean && flutter pub get` |
| Keystore check | `keytool -list -v -keystore spend-money.keystore -alias spendmoney` |

---

## Troubleshooting

### Error: "Keystore file not found"
Solution: `android/key.properties` mein correct path check karo

### Error: "Password verification failed"
Solution: key.properties mein correct password daalo

### Error: "Signing config not found"
Solution: `build.gradle.kts` mein signing config add karo (template provided)

---

## 🎯 Checklist Before Publishing

- [ ] Keystore generate ki
- [ ] key.properties create ki
- [ ] build.gradle.kts updated
- [ ] App bundle build hua
- [ ] Play Console account ready
- [ ] Screenshots uploaded
- [ ] Feature graphic uploaded
- [ ] Privacy policy ready
- [ ] Content rating done
- [ ] Store listing complete
- [ ] AAB uploaded to Play Console

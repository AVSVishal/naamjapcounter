# BizBill V28 - Indian Business Invoice App

## 100% FREE - No Paid Features, No Subscriptions

BizBill is a complete offline-first invoice management application designed specifically for Indian business owners. Built with Flutter, it works completely offline with local SQLite database storage.

## Features

### Core Features (All FREE)
- ✅ Create professional invoices with GST support
- ✅ Manage customers/clients with contact details
- ✅ Product & Service catalog with HSN codes
- ✅ PDF generation with professional templates
- ✅ WhatsApp sharing integration
- ✅ UPI payment request integration
- ✅ Payment tracking & partial payments
- ✅ Business reports & analytics
- ✅ Dashboard with revenue insights
- ✅ Multiple invoice status (Draft, Sent, Paid, Overdue)

### Indian Business Specific
- 🇮🇳 GST compliant with CGST/SGST calculations
- 🇮🇳 UPI payment integration (GPay, PhonePe, Paytm)
- 🇮🇳 HSN/SAC code support
- 🇮🇳 Indian Rupee (₹) formatting
- 🇮🇳 Hindi language support in UI

### Technical
- 📱 Offline-first - works without internet
- 🔒 Local SQLite database - your data stays on device
- 📄 PDF export with custom branding
- 🎨 Beautiful purple Material 3 UI
- 🌙 Light & Dark theme support

## Project Structure

```
lib/
├── main.dart                 # App entry point with go_router
├── database/
│   └── database_helper.dart  # SQLite models & CRUD operations
├── themes/
│   └── app_theme.dart        # Purple Material 3 theme
├── utils/
│   └── helpers.dart          # Formatting, GST calc, utilities
├── services/
│   └── pdf_generator.dart    # PDF generation service
└── screens/
    ├── splash_screen.dart       # Initial loading screen
    ├── dashboard_screen.dart    # Home with stats & invoices
    ├── create_invoice_screen.dart # Invoice creation wizard
    ├── customers_screen.dart    # Customer management
    ├── items_screen.dart        # Product/service catalog
    ├── business_setup_screen.dart # Company profile setup
    ├── invoice_preview_screen.dart # Invoice view + share
    └── reports_screen.dart      # Analytics & charts
```

## Database Schema

### Tables
- `business_profile` - Company details, logo, UPI ID
- `customers` - Client information with GST
- `catalog_items` - Products/services with HSN & GST rates
- `invoices` - Invoice headers with status
- `invoice_lines` - Line items with quantities & tax
- `payments` - Payment records with method

## Dependencies

```yaml
dependencies:
  flutter:
    sdk: flutter
  sqflite: ^2.3.2          # SQLite database
  path_provider: ^2.1.2    # File system access
  pdf: ^3.10.7             # PDF generation
  share_plus: ^7.2.2       # File sharing
  url_launcher: ^6.2.5     # UPI app launching
  image_picker: ^1.0.7     # Logo upload
  go_router: ^13.2.0       # Navigation
  flutter_animate: ^4.5.0  # Animations
  google_fonts: ^6.2.1     # Typography
  intl: ^0.19.0            # Date/number formatting
```

## Installation

1. Ensure Flutter SDK is installed (>=3.0.0)
2. Clone/unzip this project
3. Run `flutter pub get`
4. Run `flutter run`

## Building APK

```bash
flutter build apk --release
```

## Notes

- This is V28 - completely original implementation
- Based on invoice app concepts but with unique code structure
- All premium features from other apps are FREE here
- No server costs, no API keys needed
- Lifetime free for your customers

## Version

**V28** - Complete Flutter Invoice App for Indian Businesses

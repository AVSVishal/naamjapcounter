import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../themes/app_theme.dart';
import '../utils/helpers.dart';

class CreateInvoiceScreen extends StatefulWidget {
  const CreateInvoiceScreen({super.key});

  @override
  State<CreateInvoiceScreen> createState() => _CreateInvoiceScreenState();
}

class _CreateInvoiceScreenState extends State<CreateInvoiceScreen> {
  final _formKey = GlobalKey<FormState>();
  Customer? _selectedCustomer;
  List<Customer> _customers = [];
  List<CatalogItem> _catalogItems = [];
  List<InvoiceLineItem> _lineItems = [];
  
  DateTime _issueDate = DateTime.now();
  DateTime _dueDate = DateTime.now().add(const Duration(days: 30));
  
  final _notesController = TextEditingController();
  final _termsController = TextEditingController();
  final _discountController = TextEditingController();
  
  bool _isLoading = true;
  double _discountPercent = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _notesController.dispose();
    _termsController.dispose();
    _discountController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final customers = await DatabaseHelper().getAllCustomers();
    final items = await DatabaseHelper().getAllCatalogItems();
    
    setState(() {
      _customers = customers;
      _catalogItems = items;
      _isLoading = false;
    });
  }

  double get _subtotal => _lineItems.fold(0, (sum, item) => sum + item.amount);
  double get _totalDiscount => _subtotal * _discountPercent / 100;
  double get _taxAmount => _lineItems.fold(0, (sum, item) => sum + item.taxAmount);
  double get _total => _subtotal - _totalDiscount + _taxAmount;

  Future<void> _saveInvoice() async {
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a customer')),
      );
      return;
    }
    
    if (_lineItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add at least one item')),
      );
      return;
    }

    final invoiceNumber = await DatabaseHelper().getNextInvoiceNumber();
    final invoiceId = generateId();
    
    final invoice = Invoice(
      id: invoiceId,
      invoiceNumber: invoiceNumber,
      customerId: _selectedCustomer!.id,
      issueDate: _issueDate,
      dueDate: _dueDate,
      status: 'draft',
      discountPercent: _discountPercent > 0 ? _discountPercent : null,
      notes: _notesController.text.isNotEmpty ? _notesController.text : null,
      terms: _termsController.text.isNotEmpty ? _termsController.text : null,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await DatabaseHelper().insertInvoice(invoice);
    
    for (var lineItem in _lineItems) {
      final line = InvoiceLine(
        id: generateId(),
        invoiceId: invoiceId,
        catalogItemId: lineItem.catalogItem?.id,
        description: lineItem.description,
        quantity: lineItem.quantity,
        unitPrice: lineItem.unitPrice,
        gstRate: lineItem.gstRate,
        discount: lineItem.discountPercent,
      );
      await DatabaseHelper().insertInvoiceLine(line);
    }

    if (mounted) {
      context.push('/invoice-preview', extra: invoiceId);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Create Invoice'),
        actions: [
          TextButton.icon(
            onPressed: _saveInvoice,
            icon: const Icon(Icons.save_outlined),
            label: const Text('Save'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  _buildCustomerSection(),
                  const Gap(24),
                  _buildDatesSection(),
                  const Gap(24),
                  _buildItemsSection(),
                  const Gap(24),
                  _buildDiscountSection(),
                  const Gap(24),
                  _buildNotesSection(),
                  const Gap(24),
                  _buildTotalSection(),
                  const Gap(100),
                ],
              ),
            ),
    );
  }

  Widget _buildCustomerSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Bill To',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(12),
          if (_selectedCustomer == null)
            GestureDetector(
              onTap: _showCustomerPicker,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.purpleTint,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.primaryPurple.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.person_add_outlined, color: AppTheme.primaryPurple),
                    const Gap(12),
                    Text(
                      'Select Customer',
                      style: TextStyle(
                        color: AppTheme.primaryPurple,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    Icon(Icons.chevron_right, color: AppTheme.primaryPurple),
                  ],
                ),
              ),
            )
          else
            GestureDetector(
              onTap: _showCustomerPicker,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: getAvatarColor(_selectedCustomer!.name),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(
                          getInitials(_selectedCustomer!.name),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const Gap(12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _selectedCustomer!.name,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          if (_selectedCustomer!.phone != null)
                            Text(
                              _selectedCustomer!.phone!,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppTheme.textSecondary,
                                  ),
                            ),
                        ],
                      ),
                    ),
                    Icon(Icons.edit_outlined, color: AppTheme.textTertiary),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDatesSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Invoice Details',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(16),
          Row(
            children: [
              Expanded(
                child: _buildDateField(
                  label: 'Issue Date',
                  date: _issueDate,
                  onTap: () => _pickDate(true),
                ),
              ),
              const Gap(12),
              Expanded(
                child: _buildDateField(
                  label: 'Due Date',
                  date: _dueDate,
                  onTap: () => _pickDate(false),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDateField({
    required String label,
    required DateTime date,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.background,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
            ),
            const Gap(4),
            Text(
              DateFormat('dd MMM yyyy').format(date),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildItemsSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Items',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textSecondary,
                    ),
              ),
              TextButton.icon(
                onPressed: _showAddItemDialog,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add Item'),
              ),
            ],
          ),
          const Gap(12),
          if (_lineItems.isEmpty)
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: AppTheme.background,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.shopping_basket_outlined,
                      size: 48,
                      color: AppTheme.textTertiary,
                    ),
                    const Gap(12),
                    Text(
                      'No items added yet',
                      style: TextStyle(color: AppTheme.textTertiary),
                    ),
                  ],
                ),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _lineItems.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final item = _lineItems[index];
                return Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.description,
                            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          Text(
                            '${item.quantity} × ${formatCurrency(item.unitPrice, '₹')}',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: AppTheme.textSecondary,
                                ),
                          ),
                          if (item.gstRate > 0)
                            Text(
                              'GST ${item.gstRate}%',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppTheme.info,
                                  ),
                            ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        formatCurrency(item.total, '₹'),
                        textAlign: TextAlign.right,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () {
                        setState(() => _lineItems.removeAt(index));
                      },
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildDiscountSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Discount',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(12),
          TextFormField(
            controller: _discountController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              hintText: 'Enter discount percentage',
              suffixText: '%',
            ),
            onChanged: (value) {
              setState(() {
                _discountPercent = double.tryParse(value) ?? 0;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildNotesSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Notes & Terms',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(12),
          TextFormField(
            controller: _notesController,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Add notes (visible to customer)',
            ),
          ),
          const Gap(12),
          TextFormField(
            controller: _termsController,
            maxLines: 2,
            decoration: const InputDecoration(
              hintText: 'Terms & Conditions',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTotalSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.primaryPurple, AppTheme.secondaryPurple],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          _buildTotalRow('Subtotal', _subtotal, Colors.white70),
          if (_discountPercent > 0) ...[
            const Gap(8),
            _buildTotalRow('Discount ($_discountPercent%)', -_totalDiscount, Colors.green.shade300),
          ],
          if (_taxAmount > 0) ...[
            const Gap(8),
            _buildTotalRow('Tax', _taxAmount, Colors.white70),
          ],
          const Divider(color: Colors.white24),
          _buildTotalRow('Total', _total, Colors.white, isBold: true),
        ],
      ),
    );
  }

  Widget _buildTotalRow(String label, double amount, Color color, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: color,
            fontSize: isBold ? 18 : 14,
            fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
        Text(
          formatCurrency(amount, '₹'),
          style: TextStyle(
            color: Colors.white,
            fontSize: isBold ? 20 : 14,
            fontWeight: isBold ? FontWeight.w800 : FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Future<void> _pickDate(bool isIssueDate) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isIssueDate ? _issueDate : _dueDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() {
        if (isIssueDate) {
          _issueDate = picked;
        } else {
          _dueDate = picked;
        }
      });
    }
  }

  void _showCustomerPicker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        builder: (context, scrollController) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Select Customer',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    TextButton.icon(
                      onPressed: () => _showAddCustomerDialog(),
                      icon: const Icon(Icons.add),
                      label: const Text('New'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  itemCount: _customers.length,
                  itemBuilder: (context, index) {
                    final customer = _customers[index];
                    return ListTile(
                      leading: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: getAvatarColor(customer.name),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            getInitials(customer.name),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      title: Text(customer.name),
                      subtitle: customer.phone != null ? Text(customer.phone!) : null,
                      onTap: () {
                        setState(() => _selectedCustomer = customer);
                        Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddCustomerDialog() {
    // Navigate to customers screen for adding new customer
    Navigator.pop(context);
    context.push('/customers');
  }

  void _showAddItemDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        builder: (context, scrollController) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Select Item',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    TextButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        context.push('/items');
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('New'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _catalogItems.isEmpty
                    ? Center(
                        child: Text(
                          'No items in catalog',
                          style: TextStyle(color: AppTheme.textSecondary),
                        ),
                      )
                    : ListView.builder(
                        controller: scrollController,
                        itemCount: _catalogItems.length,
                        itemBuilder: (context, index) {
                          final item = _catalogItems[index];
                          return ListTile(
                            title: Text(item.name),
                            subtitle: Text(
                              formatCurrency(item.price, '₹') +
                                  (item.gstRate > 0 ? ' (GST ${item.gstRate}%)' : ''),
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.add_circle, color: AppTheme.success),
                              onPressed: () {
                                _addItemToInvoice(item);
                                Navigator.pop(context);
                              },
                            ),
                            onTap: () {
                              _addItemToInvoice(item);
                              Navigator.pop(context);
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _addItemToInvoice(CatalogItem item) {
    setState(() {
      _lineItems.add(InvoiceLineItem(
        catalogItem: item,
        description: item.name,
        quantity: 1,
        unitPrice: item.price,
        gstRate: item.gstRate,
        discountPercent: 0,
      ));
    });
  }
}

class InvoiceLineItem {
  final CatalogItem? catalogItem;
  String description;
  double quantity;
  double unitPrice;
  double gstRate;
  double discountPercent;

  InvoiceLineItem({
    this.catalogItem,
    required this.description,
    required this.quantity,
    required this.unitPrice,
    required this.gstRate,
    required this.discountPercent,
  });

  double get amount => quantity * unitPrice;
  double get discountAmount => amount * discountPercent / 100;
  double get taxableAmount => amount - discountAmount;
  double get taxAmount => taxableAmount * gstRate / 100;
  double get total => taxableAmount + taxAmount;
}

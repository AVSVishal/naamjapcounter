import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../database/database_helper.dart';
import '../themes/app_theme.dart';
import '../utils/helpers.dart';
import '../services/pdf_generator.dart';

class InvoicePreviewScreen extends StatefulWidget {
  final String invoiceId;

  const InvoicePreviewScreen({super.key, required this.invoiceId});

  @override
  State<InvoicePreviewScreen> createState() => _InvoicePreviewScreenState();
}

class _InvoicePreviewScreenState extends State<InvoicePreviewScreen> {
  Invoice? _invoice;
  Customer? _customer;
  BusinessProfile? _businessProfile;
  List<InvoiceLine> _lines = [];
  List<Payment> _payments = [];
  bool _isLoading = true;
  File? _pdfFile;

  @override
  void initState() {
    super.initState();
    _loadInvoiceData();
  }

  Future<void> _loadInvoiceData() async {
    setState(() => _isLoading = true);

    final details = await DatabaseHelper().getInvoiceWithDetails(widget.invoiceId);

    setState(() {
      _invoice = details['invoice'] as Invoice;
      _customer = details['customer'] as Customer?;
      _lines = details['lines'] as List<InvoiceLine>;
      _payments = details['payments'] as List<Payment>;
      _isLoading = false;
    });

    _businessProfile = await DatabaseHelper().getBusinessProfile();

    // Generate PDF
    await _generatePDF();
  }

  Future<void> _generatePDF() async {
    if (_invoice == null || _businessProfile == null) return;

    final pdfFile = await PDFGenerator.generateInvoicePDF(
      invoice: _invoice!,
      customer: _customer,
      business: _businessProfile!,
      lines: _lines,
      payments: _payments,
    );

    setState(() => _pdfFile = pdfFile);
  }

  double get _subtotal => _lines.fold(0, (sum, l) => sum + l.amount);
  double get _totalDiscount => _subtotal * (_invoice?.discountPercent ?? 0) / 100;
  double get _taxAmount => _lines.fold(0, (sum, l) => sum + l.gstAmount);
  double get _total => _subtotal - _totalDiscount + _taxAmount;
  double get _paidAmount => _payments.fold(0, (sum, p) => sum + p.amount);
  double get _balanceDue => _total - _paidAmount;

  Future<void> _shareInvoice() async {
    if (_pdfFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PDF not ready yet')),
      );
      return;
    }

    await Share.shareXFiles(
      [XFile(_pdfFile!.path)],
      subject: 'Invoice ${_invoice!.invoiceNumber} from ${_businessProfile?.name ?? 'Your Business'}',
      text: 'Please find attached your invoice.',
    );
  }

  Future<void> _shareViaWhatsApp() async {
    if (_customer?.phone == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Customer phone number not available')),
      );
      return;
    }

    final message =
        'Hello ${_customer!.name},\n\nYour invoice ${_invoice!.invoiceNumber} of ${formatCurrency(_total, '₹')} is ready.\n\nPlease check the attached PDF.';

    final url = Uri.parse(
        'https://wa.me/${_customer!.phone!.replaceAll(RegExp(r'[^0-9]'), '')}?text=${Uri.encodeComponent(message)}');

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      // Fallback to share
      await _shareInvoice();
    }
  }

  Future<void> _requestPaymentViaUPI() async {
    if (_businessProfile?.upiId == null || _businessProfile?.upiId!.isEmpty == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please set your UPI ID in Business Profile first'),
          action: SnackBarAction(label: 'Setup', onPressed: null),
        ),
      );
      return;
    }

    final upiLink = generateUPILink(
      upiId: _businessProfile!.upiId!,
      name: _businessProfile!.name,
      amount: _balanceDue > 0 ? _balanceDue : _total,
      transactionNote: 'Payment for Invoice ${_invoice!.invoiceNumber}',
    );

    final url = Uri.parse(upiLink);

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No UPI app found on this device')),
      );
    }
  }

  Future<void> _markAsPaid() async {
    final amountController = TextEditingController(text: _balanceDue.toStringAsFixed(2));
    String selectedMethod = 'cash';

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Record Payment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Amount',
                  prefixText: '₹ ',
                ),
              ),
              const Gap(16),
              DropdownButtonFormField<String>(
                value: selectedMethod,
                decoration: const InputDecoration(labelText: 'Payment Method'),
                items: ['cash', 'upi', 'card', 'bank', 'cheque'].map((method) {
                  return DropdownMenuItem(
                    value: method,
                    child: Text(method.toUpperCase()),
                  );
                }).toList(),
                onChanged: (value) => setDialogState(() => selectedMethod = value!),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Record Payment'),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      final amount = double.tryParse(amountController.text) ?? 0;
      if (amount > 0) {
        final payment = Payment(
          id: generateId(),
          invoiceId: widget.invoiceId,
          amount: amount,
          paymentDate: DateTime.now(),
          method: selectedMethod,
          reference: null,
        );

        await DatabaseHelper().insertPayment(payment);
        _loadInvoiceData();
      }
    }
  }

  Future<void> _updateStatus(String newStatus) async {
    await DatabaseHelper().updateInvoiceStatus(widget.invoiceId, newStatus);
    _loadInvoiceData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Invoice Preview'),
        actions: [
          PopupMenuButton<String>(
            onSelected: _updateStatus,
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'draft', child: Text('Mark as Draft')),
              const PopupMenuItem(value: 'sent', child: Text('Mark as Sent')),
              const PopupMenuItem(value: 'paid', child: Text('Mark as Paid')),
              const PopupMenuItem(value: 'overdue', child: Text('Mark as Overdue')),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _invoice == null
              ? const Center(child: Text('Invoice not found'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildInvoiceCard(),
                      const Gap(24),
                      _buildActionButtons(),
                      const Gap(40),
                    ],
                  ),
                ),
    );
  }

  Widget _buildInvoiceCard() {
    final statusColor = getStatusColor(_invoice!.status);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.primaryPurple, AppTheme.secondaryPurple],
              ),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'INVOICE',
                      style: Theme.of(context).textTheme.labelLarge?.copyWith(
                            color: Colors.white70,
                            letterSpacing: 2,
                          ),
                    ),
                    const Gap(4),
                    Text(
                      _invoice!.invoiceNumber,
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    _invoice!.status.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Business & Customer Info
          Padding(
            padding: const EdgeInsets.all(24),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'From',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Gap(8),
                      Text(
                        _businessProfile?.name ?? 'Your Business',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      if (_businessProfile?.gstNumber != null) ...[
                        const Gap(4),
                        Text(
                          'GST: ${_businessProfile!.gstNumber}',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Bill To',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Gap(8),
                      Text(
                        _customer?.name ?? 'Unknown Customer',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                        textAlign: TextAlign.right,
                      ),
                      if (_customer?.phone != null) ...[
                        const Gap(4),
                        Text(
                          _customer!.phone!,
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          const Divider(indent: 24, endIndent: 24),

          // Dates
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: Row(
              children: [
                Expanded(
                  child: _buildInfoColumn('Issue Date', formatDate(_invoice!.issueDate)),
                ),
                Expanded(
                  child: _buildInfoColumn('Due Date', formatDate(_invoice!.dueDate)),
                ),
              ],
            ),
          ),

          const Divider(indent: 24, endIndent: 24),

          // Line Items
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Text(
                        'Item',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        'Qty',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        'Amount',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
                const Gap(12),
                ..._lines.map((line) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  line.description,
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                                if (line.gstRate > 0)
                                  Text(
                                    'GST ${line.gstRate}%',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: AppTheme.textSecondary,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Text(
                              line.quantity.toStringAsFixed(0),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Text(
                              formatCurrency(line.total, '₹'),
                              textAlign: TextAlign.right,
                              style: const TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
            ),
          ),

          const Divider(indent: 24, endIndent: 24),

          // Totals
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                _buildTotalRow('Subtotal', _subtotal),
                if (_invoice!.discountPercent != null && _invoice!.discountPercent! > 0) ...[
                  const Gap(8),
                  _buildTotalRow('Discount (${_invoice!.discountPercent}%)', -_totalDiscount,
                      isDiscount: true),
                ],
                const Gap(8),
                _buildTotalRow('Tax', _taxAmount),
                const Divider(height: 24),
                _buildTotalRow('Total', _total, isBold: true),
                if (_paidAmount > 0) ...[
                  const Gap(8),
                  _buildTotalRow('Paid', _paidAmount, isPaid: true),
                  const Gap(8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _balanceDue <= 0
                          ? AppTheme.success.withOpacity(0.1)
                          : AppTheme.warning.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _balanceDue <= 0 ? 'Fully Paid' : 'Balance Due',
                          style: TextStyle(
                            color: _balanceDue <= 0 ? AppTheme.success : AppTheme.warning,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          formatCurrency(_balanceDue > 0 ? _balanceDue : 0, '₹'),
                          style: TextStyle(
                            color: _balanceDue <= 0 ? AppTheme.success : AppTheme.warning,
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),

          // Notes
          if (_invoice!.notes != null && _invoice!.notes!.isNotEmpty) ...[
            const Divider(indent: 24, endIndent: 24),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Notes',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                  const Gap(8),
                  Text(_invoice!.notes!),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoColumn(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 12,
          ),
        ),
        const Gap(4),
        Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  Widget _buildTotalRow(String label, double amount,
      {bool isBold = false, bool isDiscount = false, bool isPaid = false}) {
    Color color = AppTheme.textPrimary;
    if (isDiscount) color = Colors.green;
    if (isPaid) color = AppTheme.success;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
            color: color,
          ),
        ),
        Text(
          formatCurrency(amount, '₹'),
          style: TextStyle(
            fontWeight: isBold ? FontWeight.w800 : FontWeight.w600,
            fontSize: isBold ? 18 : 14,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _shareInvoice,
                icon: const Icon(Icons.share),
                label: const Text('Share PDF'),
              ),
            ),
          ],
        ),
        const Gap(12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _shareViaWhatsApp,
                icon: const Icon(Icons.whatshot),
                label: const Text('WhatsApp'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF25D366),
                  side: const BorderSide(color: Color(0xFF25D366)),
                ),
              ),
            ),
            const Gap(12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _requestPaymentViaUPI,
                icon: const Icon(Icons.payments),
                label: const Text('Request UPI'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.primaryPurple,
                ),
              ),
            ),
          ],
        ),
        if (_balanceDue > 0) ...[
          const Gap(12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _markAsPaid,
              icon: const Icon(Icons.check_circle),
              label: Text('Record Payment (${formatCurrency(_balanceDue, '₹')})'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.success,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

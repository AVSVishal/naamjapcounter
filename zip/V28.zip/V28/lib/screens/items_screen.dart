import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import '../database/database_helper.dart';
import '../themes/app_theme.dart';
import '../utils/helpers.dart';

class ItemsScreen extends StatefulWidget {
  const ItemsScreen({super.key});

  @override
  State<ItemsScreen> createState() => _ItemsScreenState();
}

class _ItemsScreenState extends State<ItemsScreen> {
  List<CatalogItem> _items = [];
  List<CatalogItem> _filteredItems = [];
  bool _isLoading = true;
  final _searchController = TextEditingController();

  final _nameController = TextEditingController();
  final _descController = TextEditingController();
  final _priceController = TextEditingController();
  final _hsnController = TextEditingController();
  final _gstController = TextEditingController();
  bool _isService = false;

  @override
  void initState() {
    super.initState();
    _loadItems();
    _searchController.addListener(_filterItems);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _nameController.dispose();
    _descController.dispose();
    _priceController.dispose();
    _hsnController.dispose();
    _gstController.dispose();
    super.dispose();
  }

  Future<void> _loadItems() async {
    setState(() => _isLoading = true);
    final items = await DatabaseHelper().getAllCatalogItems();
    setState(() {
      _items = items;
      _filteredItems = items;
      _isLoading = false;
    });
  }

  void _filterItems() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredItems = _items.where((i) {
        return i.name.toLowerCase().contains(query) ||
            (i.description?.toLowerCase().contains(query) ?? false) ||
            (i.hsnCode?.toLowerCase().contains(query) ?? false);
      }).toList();
    });
  }

  void _clearForm() {
    _nameController.clear();
    _descController.clear();
    _priceController.clear();
    _hsnController.clear();
    _gstController.clear();
    _isService = false;
  }

  Future<void> _saveItem({String? itemId}) async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter item name')),
      );
      return;
    }

    final price = double.tryParse(_priceController.text) ?? 0;
    if (price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid price')),
      );
      return;
    }

    final item = CatalogItem(
      id: itemId ?? generateId(),
      name: _nameController.text.trim(),
      description: _descController.text.isNotEmpty ? _descController.text.trim() : null,
      price: price,
      hsnCode: _hsnController.text.isNotEmpty ? _hsnController.text.trim() : null,
      gstRate: double.tryParse(_gstController.text) ?? 0,
      isService: _isService,
    );

    if (itemId != null) {
      await DatabaseHelper().updateCatalogItem(item);
    } else {
      await DatabaseHelper().insertCatalogItem(item);
    }

    _clearForm();
    Navigator.pop(context);
    _loadItems();
  }

  Future<void> _deleteItem(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Item?'),
        content: const Text('This item will be permanently removed from your catalog.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await DatabaseHelper().deleteCatalogItem(id);
      _loadItems();
    }
  }

  void _showAddEditItem({CatalogItem? item}) {
    if (item != null) {
      _nameController.text = item.name;
      _descController.text = item.description ?? '';
      _priceController.text = item.price.toString();
      _hsnController.text = item.hsnCode ?? '';
      _gstController.text = item.gstRate.toString();
      _isService = item.isService;
    } else {
      _clearForm();
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => DraggableScrollableSheet(
          initialChildSize: 0.8,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (context, scrollController) => Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: SingleChildScrollView(
                controller: scrollController,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: AppTheme.border,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      const Gap(24),
                      Text(
                        item != null ? 'Edit Item' : 'Add New Item',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      const Gap(24),
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Item Name *',
                          prefixIcon: Icon(Icons.inventory_2_outlined),
                        ),
                      ),
                      const Gap(16),
                      TextFormField(
                        controller: _descController,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'Description',
                          prefixIcon: Icon(Icons.description_outlined),
                          alignLabelWithHint: true,
                        ),
                      ),
                      const Gap(16),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _priceController,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'Price *',
                                prefixIcon: Icon(Icons.currency_rupee),
                              ),
                            ),
                          ),
                          const Gap(12),
                          Expanded(
                            child: TextFormField(
                              controller: _gstController,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'GST %',
                                prefixIcon: Icon(Icons.percent),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Gap(16),
                      TextFormField(
                        controller: _hsnController,
                        textCapitalization: TextCapitalization.characters,
                        decoration: const InputDecoration(
                          labelText: 'HSN/SAC Code',
                          prefixIcon: Icon(Icons.code_outlined),
                          hintText: 'For GST compliance',
                        ),
                      ),
                      const Gap(16),
                      SwitchListTile(
                        value: _isService,
                        onChanged: (value) => setModalState(() => _isService = value),
                        title: const Text('This is a Service'),
                        subtitle: const Text('Mark if not a physical product'),
                        activeColor: AppTheme.primaryPurple,
                      ),
                      const Gap(32),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () => _saveItem(itemId: item?.id),
                          child: Text(item != null ? 'Update Item' : 'Add Item'),
                        ),
                      ),
                      const Gap(16),
                      if (item != null)
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton(
                            onPressed: () {
                              Navigator.pop(context);
                              _deleteItem(item.id);
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                              side: const BorderSide(color: Colors.red),
                            ),
                            child: const Text('Delete Item'),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Items & Services'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search items...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => _searchController.clear(),
                      )
                    : null,
              ),
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredItems.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _filteredItems.length,
                        itemBuilder: (context, index) {
                          final item = _filteredItems[index];
                          return _buildItemCard(item).animate().fadeIn(
                            duration: 300.ms,
                            delay: (index * 50).ms,
                          );
                        },
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditItem(),
        icon: const Icon(Icons.add),
        label: const Text('Add Item'),
      ),
    );
  }

  Widget _buildItemCard(CatalogItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: item.isService ? AppTheme.info.withOpacity(0.1) : AppTheme.success.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Center(
            child: Icon(
              item.isService ? Icons.handyman_outlined : Icons.inventory_2_outlined,
              color: item.isService ? AppTheme.info : AppTheme.success,
            ),
          ),
        ),
        title: Text(
          item.name,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Gap(4),
            Text(
              formatCurrency(item.price, '₹') +
                  (item.gstRate > 0 ? ' + ${item.gstRate}% GST' : ''),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
            ),
            if (item.hsnCode != null) ...[
              const Gap(2),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.purpleTint,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'HSN: ${item.hsnCode}',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppTheme.primaryPurple,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.edit_outlined, color: AppTheme.primaryPurple),
          onPressed: () => _showAddEditItem(item: item),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: AppTheme.purpleTint,
              borderRadius: BorderRadius.circular(32),
            ),
            child: const Icon(
              Icons.inventory_2_outlined,
              size: 60,
              color: AppTheme.primaryPurple,
            ),
          ),
          const Gap(24),
          Text(
            'No Items Yet',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const Gap(8),
          Text(
            'Add products or services to your catalog',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(24),
          ElevatedButton.icon(
            onPressed: () => _showAddEditItem(),
            icon: const Icon(Icons.add),
            label: const Text('Add Item'),
          ),
        ],
      ),
    );
  }
}

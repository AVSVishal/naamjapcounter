import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import '../database/database_helper.dart';
import '../themes/app_theme.dart';
import '../utils/helpers.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  BusinessProfile? _businessProfile;
  List<InvoiceWithCustomer> _invoices = [];
  List<Customer> _customers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    final profile = await DatabaseHelper().getBusinessProfile();
    final invoices = await DatabaseHelper().getAllInvoicesWithCustomers();
    final customers = await DatabaseHelper().getAllCustomers();
    
    setState(() {
      _businessProfile = profile;
      _invoices = invoices;
      _customers = customers;
      _isLoading = false;
    });
  }

  double get _totalRevenue => _invoices
      .where((i) => i.status == 'paid')
      .fold(0, (sum, i) => sum + i.total);

  double get _outstandingAmount => _invoices
      .where((i) => i.status == 'sent' || i.status == 'overdue')
      .fold(0, (sum, i) => sum + i.total);

  int get _overdueCount => _invoices.where((i) => i.status == 'overdue').length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: IndexedStack(
                index: _selectedIndex,
                children: [
                  _buildHomeTab(),
                  _buildInvoicesTab(),
                  _buildMoreTab(),
                ],
              ),
            ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        backgroundColor: Colors.white,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_outlined),
            selectedIcon: Icon(Icons.receipt),
            label: 'Invoices',
          ),
          NavigationDestination(
            icon: Icon(Icons.more_horiz_outlined),
            selectedIcon: Icon(Icons.more_horiz),
            label: 'More',
          ),
        ],
      ),
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton.extended(
              onPressed: () => context.push('/create-invoice'),
              icon: const Icon(Icons.add),
              label: const Text('New Invoice'),
            )
          : null,
    );
  }

  Widget _buildHomeTab() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          getGreetingInHindi(),
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: AppTheme.textSecondary,
                              ),
                        ),
                        const Gap(4),
                        Text(
                          _businessProfile?.name ?? 'Your Business',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                      ],
                    ),
                    GestureDetector(
                      onTap: () => context.push('/business-setup'),
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [AppTheme.primaryPurple, AppTheme.secondaryPurple],
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Icon(
                          Icons.store_outlined,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const Gap(24),
                _buildStatsCards(),
                const Gap(24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Quick Actions',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ],
                ),
                const Gap(16),
                _buildQuickActions(),
                const Gap(24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Recent Invoices',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    TextButton(
                      onPressed: () => setState(() => _selectedIndex = 1),
                      child: const Text('View All'),
                    ),
                  ],
                ),
                const Gap(12),
              ],
            ),
          ),
        ),
        _invoices.isEmpty
            ? SliverToBoxAdapter(
                child: _buildEmptyState(),
              )
            : SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final invoice = _invoices[index];
                    return _buildInvoiceCard(invoice).animate().fadeIn(
                      duration: 400.ms,
                      delay: (index * 100).ms,
                    );
                  },
                  childCount: _invoices.take(5).length,
                ),
              ),
        const SliverToBoxAdapter(child: Gap(100)),
      ],
    );
  }

  Widget _buildStatsCards() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            'Total Revenue',
            formatCurrency(_totalRevenue, '₹'),
            Icons.trending_up,
            AppTheme.success,
          ),
        ),
        const Gap(12),
        Expanded(
          child: _buildStatCard(
            'Outstanding',
            formatCurrency(_outstandingAmount, '₹'),
            Icons.pending_outlined,
            _overdueCount > 0 ? AppTheme.warning : AppTheme.info,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const Gap(12),
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          const Gap(4),
          Text(
            title,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    final actions = [
      _QuickAction(
        icon: Icons.person_add_outlined,
        label: 'Add Customer',
        color: AppTheme.primaryPurple,
        onTap: () => _showAddCustomerBottomSheet(),
      ),
      _QuickAction(
        icon: Icons.inventory_2_outlined,
        label: 'Add Item',
        color: AppTheme.success,
        onTap: () => context.push('/items'),
      ),
      _QuickAction(
        icon: Icons.share_outlined,
        label: 'Share Report',
        color: AppTheme.info,
        onTap: () => context.push('/reports'),
      ),
    ];

    return Row(
      children: actions.map((action) => Expanded(
        child: GestureDetector(
          onTap: action.onTap,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
            decoration: BoxDecoration(
              color: action.color.withOpacity(0.08),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Icon(action.icon, color: action.color, size: 28),
                const Gap(8),
                Text(
                  action.label,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: action.color,
                        fontWeight: FontWeight.w600,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      )).toList(),
    );
  }

  Widget _buildInvoiceCard(Invoice invoice) {
    final statusColor = getStatusColor(invoice.status);
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: statusColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              getInitials(invoice.customerName ?? 'Unknown'),
              style: TextStyle(
                color: statusColor,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ),
        title: Text(
          invoice.customerName ?? 'Unknown Customer',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Gap(4),
            Text(
              '${invoice.invoiceNumber} • ${formatDate(invoice.issueDate)}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              formatCurrency(invoice.total, '₹'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const Gap(4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                invoice.status.toUpperCase(),
                style: TextStyle(
                  color: statusColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        onTap: () => context.push('/invoice-preview', extra: invoice.id),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      margin: const EdgeInsets.all(20),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppTheme.purpleTint,
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(
              Icons.receipt_long_outlined,
              size: 40,
              color: AppTheme.primaryPurple,
            ),
          ),
          const Gap(20),
          Text(
            'No Invoices Yet',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const Gap(8),
          Text(
            'Create your first invoice to get started',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textSecondary,
                ),
            textAlign: TextAlign.center,
          ),
          const Gap(20),
          ElevatedButton.icon(
            onPressed: () => context.push('/create-invoice'),
            icon: const Icon(Icons.add),
            label: const Text('Create Invoice'),
          ),
        ],
      ),
    );
  }

  Widget _buildInvoicesTab() {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          pinned: true,
          title: Text(
            'All Invoices',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.filter_list),
              onPressed: () {},
            ),
          ],
        ),
        _invoices.isEmpty
            ? SliverToBoxAdapter(child: _buildEmptyState())
            : SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => _buildInvoiceCard(_invoices[index]),
                  childCount: _invoices.length,
                ),
              ),
        const SliverToBoxAdapter(child: Gap(100)),
      ],
    );
  }

  Widget _buildMoreTab() {
    final menuItems = [
      _MenuItem(
        icon: Icons.people_outlined,
        title: 'Customers',
        subtitle: '${_customers.length} customers',
        onTap: () => context.push('/customers'),
      ),
      _MenuItem(
        icon: Icons.inventory_2_outlined,
        title: 'Items & Services',
        subtitle: 'Manage your catalog',
        onTap: () => context.push('/items'),
      ),
      _MenuItem(
        icon: Icons.insert_chart_outlined,
        title: 'Reports & Analytics',
        subtitle: 'View business insights',
        onTap: () => context.push('/reports'),
      ),
      _MenuItem(
        icon: Icons.store_outlined,
        title: 'Business Profile',
        subtitle: 'Edit company details',
        onTap: () => context.push('/business-setup'),
      ),
      _MenuItem(
        icon: Icons.settings_outlined,
        title: 'Settings',
        subtitle: 'App preferences',
        onTap: () {},
      ),
      _MenuItem(
        icon: Icons.help_outline,
        title: 'Help & Support',
        subtitle: 'FAQs and contact',
        onTap: () {},
      ),
    ];

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          pinned: true,
          title: Text(
            'More Options',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              final item = menuItems[index];
              return ListTile(
                leading: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppTheme.purpleTint,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(item.icon, color: AppTheme.primaryPurple),
                ),
                title: Text(
                  item.title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                subtitle: Text(
                  item.subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                ),
                trailing: const Icon(Icons.chevron_right, color: AppTheme.textTertiary),
                onTap: item.onTap,
              );
            },
            childCount: menuItems.length,
          ),
        ),
        const SliverToBoxAdapter(child: Gap(24)),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Divider(),
                const Gap(16),
                Text(
                  'BizBill v28',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.textTertiary,
                      ),
                ),
                const Gap(4),
                Text(
                  '100% Free • Made for India',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.textTertiary,
                      ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _showAddCustomerBottomSheet() {
    // Implementation for adding customer
    context.push('/customers');
  }
}

class _QuickAction {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  _QuickAction({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });
}

class _MenuItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  _MenuItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../database/database_helper.dart';
import '../themes/app_theme.dart';
import '../utils/helpers.dart';

class BusinessSetupScreen extends StatefulWidget {
  const BusinessSetupScreen({super.key});

  @override
  State<BusinessSetupScreen> createState() => _BusinessSetupScreenState();
}

class _BusinessSetupScreenState extends State<BusinessSetupScreen> {
  final _formKey = GlobalKey<FormState>();
  
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _gstController = TextEditingController();
  final _upiController = TextEditingController();
  final _websiteController = TextEditingController();
  
  File? _logoImage;
  bool _isLoading = false;
  bool _isEditMode = false;

  @override
  void initState() {
    super.initState();
    _loadExistingProfile();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _gstController.dispose();
    _upiController.dispose();
    _websiteController.dispose();
    super.dispose();
  }

  Future<void> _loadExistingProfile() async {
    final profile = await DatabaseHelper().getBusinessProfile();
    if (profile != null) {
      setState(() => _isEditMode = true);
      _nameController.text = profile.name;
      _phoneController.text = profile.phone ?? '';
      _emailController.text = profile.email ?? '';
      _addressController.text = profile.address ?? '';
      _gstController.text = profile.gstNumber ?? '';
      _upiController.text = profile.upiId ?? '';
      _websiteController.text = profile.website ?? '';
      if (profile.logoPath != null) {
        _logoImage = File(profile.logoPath!);
      }
    }
  }

  Future<void> _pickLogo() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _logoImage = File(picked.path));
    }
  }

  Future<void> _saveBusinessProfile() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter business name')),
      );
      return;
    }

    setState(() => _isLoading = true);

    final profile = BusinessProfile(
      id: _isEditMode ? (await DatabaseHelper().getBusinessProfile())!.id : generateId(),
      name: _nameController.text.trim(),
      phone: _phoneController.text.isNotEmpty ? _phoneController.text.trim() : null,
      email: _emailController.text.isNotEmpty ? _emailController.text.trim() : null,
      address: _addressController.text.isNotEmpty ? _addressController.text.trim() : null,
      gstNumber: _gstController.text.isNotEmpty ? _gstController.text.trim() : null,
      logoPath: _logoImage?.path,
      currency: '₹',
      website: _websiteController.text.isNotEmpty ? _websiteController.text.trim() : null,
      upiId: _upiController.text.isNotEmpty ? _upiController.text.trim() : null,
    );

    await DatabaseHelper().saveBusinessProfile(profile);

    setState(() => _isLoading = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Business profile saved successfully')),
      );
      if (!_isEditMode) {
        context.go('/dashboard');
      } else {
        context.pop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text(_isEditMode ? 'Edit Business Profile' : 'Setup Your Business'),
        leading: _isEditMode
            ? IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => context.pop(),
              )
            : null,
        automaticallyImplyLeading: _isEditMode,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (!_isEditMode) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.primaryPurple, AppTheme.secondaryPurple],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.storefront,
                      size: 48,
                      color: Colors.white.withOpacity(0.9),
                    ),
                    const Gap(12),
                    Text(
                      'Welcome to BizBill!',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const Gap(8),
                    Text(
                      'Set up your business details to start creating professional invoices for your Indian customers.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.white.withOpacity(0.9),
                          ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              const Gap(24),
            ],
            _buildLogoSection(),
            const Gap(24),
            _buildFormSection(),
            const Gap(32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _saveBusinessProfile,
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text(_isEditMode ? 'Save Changes' : 'Get Started'),
              ),
            ),
            if (_isEditMode) ...[
              const Gap(16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => context.pop(),
                  child: const Text('Cancel'),
                ),
              ),
            ],
            const Gap(40),
          ],
        ),
      ),
    );
  }

  Widget _buildLogoSection() {
    return Center(
      child: Column(
        children: [
          GestureDetector(
            onTap: _pickLogo,
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppTheme.border, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: _logoImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(22),
                      child: Image.file(
                        _logoImage!,
                        fit: BoxFit.cover,
                        width: 120,
                        height: 120,
                      ),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add_photo_alternate_outlined,
                          size: 40,
                          color: AppTheme.primaryPurple.withOpacity(0.5),
                        ),
                        const Gap(8),
                        Text(
                          'Add Logo',
                          style: TextStyle(
                            color: AppTheme.primaryPurple.withOpacity(0.7),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
          const Gap(8),
          TextButton.icon(
            onTap: _logoImage != null ? () => setState(() => _logoImage = null) : _pickLogo,
            icon: Icon(_logoImage != null ? Icons.delete_outline : Icons.camera_alt_outlined),
            label: Text(_logoImage != null ? 'Remove Logo' : 'Select from Gallery'),
          ),
        ],
      ),
    );
  }

  Widget _buildFormSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Business Information',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(20),
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Business Name *',
              prefixIcon: Icon(Icons.store_outlined),
            ),
          ),
          const Gap(16),
          TextFormField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Phone Number',
              prefixIcon: Icon(Icons.phone_outlined),
            ),
          ),
          const Gap(16),
          TextFormField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Email Address',
              prefixIcon: Icon(Icons.email_outlined),
            ),
          ),
          const Gap(16),
          TextFormField(
            controller: _gstController,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(
              labelText: 'GST Number',
              prefixIcon: Icon(Icons.receipt_outlined),
              hintText: '22AAAAA0000A1Z5',
            ),
          ),
          const Gap(24),
          const Divider(),
          const Gap(24),
          Text(
            'Payment Settings',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
          ),
          const Gap(20),
          TextFormField(
            controller: _upiController,
            decoration: const InputDecoration(
              labelText: 'UPI ID for Payments',
              prefixIcon: Icon(Icons.payments_outlined),
              hintText: 'yourname@upi',
              helperText: 'Customers can pay directly via UPI apps',
            ),
          ),
          const Gap(16),
          TextFormField(
            controller: _websiteController,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
              labelText: 'Website (Optional)',
              prefixIcon: Icon(Icons.language_outlined),
              hintText: 'www.yourbusiness.com',
            ),
          ),
          const Gap(16),
          TextFormField(
            controller: _addressController,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Business Address',
              prefixIcon: Icon(Icons.location_on_outlined),
              alignLabelWithHint: true,
            ),
          ),
        ],
      ),
    );
  }
}

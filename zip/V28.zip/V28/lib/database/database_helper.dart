import 'dart:async';
import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

/// Business Profile Model
class BusinessProfile {
  final String id;
  final String name;
  final String? phone;
  final String? email;
  final String? address;
  final String? gstNumber;
  final String? logoPath;
  final String currency;
  final String? website;
  final String? signaturePath;
  final String? upiId;

  BusinessProfile({
    required this.id,
    required this.name,
    this.phone,
    this.email,
    this.address,
    this.gstNumber,
    this.logoPath,
    this.currency = '₹',
    this.website,
    this.signaturePath,
    this.upiId,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'phone': phone,
    'email': email,
    'address': address,
    'gst_number': gstNumber,
    'logo_path': logoPath,
    'currency': currency,
    'website': website,
    'signature_path': signaturePath,
    'upi_id': upiId,
  };

  factory BusinessProfile.fromMap(Map<String, dynamic> map) => BusinessProfile(
    id: map['id'],
    name: map['name'],
    phone: map['phone'],
    email: map['email'],
    address: map['address'],
    gstNumber: map['gst_number'],
    logoPath: map['logo_path'],
    currency: map['currency'] ?? '₹',
    website: map['website'],
    signaturePath: map['signature_path'],
    upiId: map['upi_id'],
  );
}

/// Customer/Client Model
class Customer {
  final String id;
  final String name;
  final String? phone;
  final String? email;
  final String? address;
  final String? company;
  final String? gstNumber;
  final String? avatarPath;
  final DateTime createdAt;

  Customer({
    required this.id,
    required this.name,
    this.phone,
    this.email,
    this.address,
    this.company,
    this.gstNumber,
    this.avatarPath,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'phone': phone,
    'email': email,
    'address': address,
    'company': company,
    'gst_number': gstNumber,
    'avatar_path': avatarPath,
    'created_at': createdAt.toIso8601String(),
  };

  factory Customer.fromMap(Map<String, dynamic> map) => Customer(
    id: map['id'],
    name: map['name'],
    phone: map['phone'],
    email: map['email'],
    address: map['address'],
    company: map['company'],
    gstNumber: map['gst_number'],
    avatarPath: map['avatar_path'],
    createdAt: DateTime.parse(map['created_at']),
  );
}

/// Product/Service Catalog Item
class CatalogItem {
  final String id;
  final String name;
  final String? description;
  final double price;
  final String? hsnCode;
  final double gstRate;
  final bool isService;

  CatalogItem({
    required this.id,
    required this.name,
    this.description,
    required this.price,
    this.hsnCode,
    this.gstRate = 0,
    this.isService = false,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'description': description,
    'price': price,
    'hsn_code': hsnCode,
    'gst_rate': gstRate,
    'is_service': isService ? 1 : 0,
  };

  factory CatalogItem.fromMap(Map<String, dynamic> map) => CatalogItem(
    id: map['id'],
    name: map['name'],
    description: map['description'],
    price: map['price'],
    hsnCode: map['hsn_code'],
    gstRate: map['gst_rate'] ?? 0,
    isService: map['is_service'] == 1,
  );
}

/// Invoice Line Item
class InvoiceLine {
  final String id;
  final String invoiceId;
  final String? catalogItemId;
  final String description;
  final double quantity;
  final double unitPrice;
  final double gstRate;
  final double discount;

  InvoiceLine({
    required this.id,
    required this.invoiceId,
    this.catalogItemId,
    required this.description,
    required this.quantity,
    required this.unitPrice,
    this.gstRate = 0,
    this.discount = 0,
  });

  double get amount => quantity * unitPrice * (1 - discount / 100);
  double get gstAmount => amount * gstRate / 100;
  double get total => amount + gstAmount;

  Map<String, dynamic> toMap() => {
    'id': id,
    'invoice_id': invoiceId,
    'catalog_item_id': catalogItemId,
    'description': description,
    'quantity': quantity,
    'unit_price': unitPrice,
    'gst_rate': gstRate,
    'discount': discount,
  };

  factory InvoiceLine.fromMap(Map<String, dynamic> map) => InvoiceLine(
    id: map['id'],
    invoiceId: map['invoice_id'],
    catalogItemId: map['catalog_item_id'],
    description: map['description'],
    quantity: map['quantity'],
    unitPrice: map['unit_price'],
    gstRate: map['gst_rate'] ?? 0,
    discount: map['discount'] ?? 0,
  );
}

/// Invoice Model
class Invoice {
  final String id;
  final String invoiceNumber;
  final String customerId;
  final DateTime issueDate;
  final DateTime dueDate;
  final String status; // draft, sent, paid, overdue, cancelled
  final double? discountPercent;
  final String? notes;
  final String? terms;
  final String? poNumber;
  final String? signaturePath;
  final DateTime createdAt;
  final DateTime updatedAt;

  Invoice({
    required this.id,
    required this.invoiceNumber,
    required this.customerId,
    required this.issueDate,
    required this.dueDate,
    this.status = 'draft',
    this.discountPercent,
    this.notes,
    this.terms,
    this.poNumber,
    this.signaturePath,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'invoice_number': invoiceNumber,
    'customer_id': customerId,
    'issue_date': issueDate.toIso8601String(),
    'due_date': dueDate.toIso8601String(),
    'status': status,
    'discount_percent': discountPercent,
    'notes': notes,
    'terms': terms,
    'po_number': poNumber,
    'signature_path': signaturePath,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  factory Invoice.fromMap(Map<String, dynamic> map) => Invoice(
    id: map['id'],
    invoiceNumber: map['invoice_number'],
    customerId: map['customer_id'],
    issueDate: DateTime.parse(map['issue_date']),
    dueDate: DateTime.parse(map['due_date']),
    status: map['status'],
    discountPercent: map['discount_percent'],
    notes: map['notes'],
    terms: map['terms'],
    poNumber: map['po_number'],
    signaturePath: map['signature_path'],
    createdAt: DateTime.parse(map['created_at']),
    updatedAt: DateTime.parse(map['updated_at']),
  );

  // Calculated total (to be populated with lines)
  double get total => 0; // Will be calculated from invoice lines
}

/// Payment Record
class Payment {
  final String id;
  final String invoiceId;
  final double amount;
  final DateTime paymentDate;
  final String method; // cash, upi, card, bank, cheque
  final String? reference;
  final String? notes;

  Payment({
    required this.id,
    required this.invoiceId,
    required this.amount,
    required this.paymentDate,
    required this.method,
    this.reference,
    this.notes,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'invoice_id': invoiceId,
    'amount': amount,
    'payment_date': paymentDate.toIso8601String(),
    'method': method,
    'reference': reference,
    'notes': notes,
  };

  factory Payment.fromMap(Map<String, dynamic> map) => Payment(
    id: map['id'],
    invoiceId: map['invoice_id'],
    amount: map['amount'],
    paymentDate: DateTime.parse(map['payment_date']),
    method: map['method'],
    reference: map['reference'],
    notes: map['notes'],
  );
}

/// Main Database Helper
class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  Database? _database;

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final Directory documentsDirectory = await getApplicationDocumentsDirectory();
    final String path = join(documentsDirectory.path, 'bizbill.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Business Profile Table
    await db.execute('''
      CREATE TABLE business_profile (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        gst_number TEXT,
        logo_path TEXT,
        currency TEXT DEFAULT '₹',
        website TEXT,
        signature_path TEXT,
        upi_id TEXT
      )
    ''');

    // Customers Table
    await db.execute('''
      CREATE TABLE customers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        company TEXT,
        gst_number TEXT,
        avatar_path TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    // Catalog Items Table
    await db.execute('''
      CREATE TABLE catalog_items (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        hsn_code TEXT,
        gst_rate REAL DEFAULT 0,
        is_service INTEGER DEFAULT 0
      )
    ''');

    // Invoices Table
    await db.execute('''
      CREATE TABLE invoices (
        id TEXT PRIMARY KEY,
        invoice_number TEXT UNIQUE NOT NULL,
        customer_id TEXT NOT NULL,
        issue_date TEXT NOT NULL,
        due_date TEXT NOT NULL,
        status TEXT DEFAULT 'draft',
        discount_percent REAL,
        notes TEXT,
        terms TEXT,
        po_number TEXT,
        signature_path TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
      )
    ''');

    // Invoice Lines Table
    await db.execute('''
      CREATE TABLE invoice_lines (
        id TEXT PRIMARY KEY,
        invoice_id TEXT NOT NULL,
        catalog_item_id TEXT,
        description TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit_price REAL NOT NULL,
        gst_rate REAL DEFAULT 0,
        discount REAL DEFAULT 0,
        FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
        FOREIGN KEY (catalog_item_id) REFERENCES catalog_items(id)
      )
    ''');

    // Payments Table
    await db.execute('''
      CREATE TABLE payments (
        id TEXT PRIMARY KEY,
        invoice_id TEXT NOT NULL,
        amount REAL NOT NULL,
        payment_date TEXT NOT NULL,
        method TEXT NOT NULL,
        reference TEXT,
        notes TEXT,
        FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
      )
    ''');

    // Create indexes for faster queries
    await db.execute('CREATE INDEX idx_invoices_customer ON invoices(customer_id)');
    await db.execute('CREATE INDEX idx_invoices_status ON invoices(status)');
    await db.execute('CREATE INDEX idx_invoice_lines_invoice ON invoice_lines(invoice_id)');
    await db.execute('CREATE INDEX idx_payments_invoice ON payments(invoice_id)');
  }

  // ==================== BUSINESS PROFILE CRUD ====================

  Future<void> saveBusinessProfile(BusinessProfile profile) async {
    final db = await database;
    await db.insert(
      'business_profile',
      profile.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<BusinessProfile?> getBusinessProfile() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('business_profile', limit: 1);
    if (maps.isNotEmpty) {
      return BusinessProfile.fromMap(maps.first);
    }
    return null;
  }

  Future<bool> hasBusinessProfile() async {
    final db = await database;
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM business_profile'));
    return count != null && count > 0;
  }

  // ==================== CUSTOMER CRUD ====================

  Future<String> insertCustomer(Customer customer) async {
    final db = await database;
    await db.insert('customers', customer.toMap());
    return customer.id;
  }

  Future<void> updateCustomer(Customer customer) async {
    final db = await database;
    await db.update(
      'customers',
      customer.toMap(),
      where: 'id = ?',
      whereArgs: [customer.id],
    );
  }

  Future<void> deleteCustomer(String id) async {
    final db = await database;
    await db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Customer>> getAllCustomers() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'customers',
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => Customer.fromMap(maps[i]));
  }

  Future<Customer?> getCustomerById(String id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'customers',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) return Customer.fromMap(maps.first);
    return null;
  }

  Future<List<Customer>> searchCustomers(String query) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'customers',
      where: 'name LIKE ? OR phone LIKE ? OR email LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => Customer.fromMap(maps[i]));
  }

  // ==================== CATALOG ITEM CRUD ====================

  Future<String> insertCatalogItem(CatalogItem item) async {
    final db = await database;
    await db.insert('catalog_items', item.toMap());
    return item.id;
  }

  Future<void> updateCatalogItem(CatalogItem item) async {
    final db = await database;
    await db.update(
      'catalog_items',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<void> deleteCatalogItem(String id) async {
    final db = await database;
    await db.delete('catalog_items', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<CatalogItem>> getAllCatalogItems() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'catalog_items',
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => CatalogItem.fromMap(maps[i]));
  }

  Future<List<CatalogItem>> searchCatalogItems(String query) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'catalog_items',
      where: 'name LIKE ?',
      whereArgs: ['%$query%'],
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => CatalogItem.fromMap(maps[i]));
  }

  // ==================== INVOICE CRUD ====================

  Future<String> insertInvoice(Invoice invoice) async {
    final db = await database;
    await db.insert('invoices', invoice.toMap());
    return invoice.id;
  }

  Future<String> insertInvoiceLine(InvoiceLine line) async {
    final db = await database;
    await db.insert('invoice_lines', line.toMap());
    return line.id;
  }

  Future<void> updateInvoice(Invoice invoice, List<InvoiceLine> lines) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update(
        'invoices',
        invoice.toMap(),
        where: 'id = ?',
        whereArgs: [invoice.id],
      );
      // Delete old lines and insert new ones
      await txn.delete('invoice_lines', where: 'invoice_id = ?', whereArgs: [invoice.id]);
      for (final line in lines) {
        await txn.insert('invoice_lines', line.toMap());
      }
    });
  }

  Future<void> deleteInvoice(String id) async {
    final db = await database;
    await db.delete('invoices', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> updateInvoiceStatus(String id, String status) async {
    final db = await database;
    await db.update(
      'invoices',
      {'status': status, 'updated_at': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<Invoice>> getAllInvoices({String? status}) async {
    final db = await database;
    String whereClause = '';
    List<dynamic>? whereArgs;
    if (status != null) {
      whereClause = 'WHERE status = ?';
      whereArgs = [status];
    }
    final List<Map<String, dynamic>> maps = await db.rawQuery(
      'SELECT * FROM invoices $whereClause ORDER BY created_at DESC',
      whereArgs,
    );
    return List.generate(maps.length, (i) => Invoice.fromMap(maps[i]));
  }

  Future<List<InvoiceWithCustomer>> getAllInvoicesWithCustomers() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT i.*, c.name as customer_name
      FROM invoices i
      LEFT JOIN customers c ON i.customer_id = c.id
      ORDER BY i.created_at DESC
    ''');
    return List.generate(maps.length, (i) => InvoiceWithCustomer.fromMap(maps[i]));
  }

  Future<Invoice?> getInvoiceById(String id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'invoices',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) return Invoice.fromMap(maps.first);
    return null;
  }

  Future<List<InvoiceLine>> getInvoiceLines(String invoiceId) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'invoice_lines',
      where: 'invoice_id = ?',
      whereArgs: [invoiceId],
    );
    return List.generate(maps.length, (i) => InvoiceLine.fromMap(maps[i]));
  }

  Future<Map<String, dynamic>> getInvoiceWithDetails(String invoiceId) async {
    final db = await database;
    final invoice = await getInvoiceById(invoiceId);
    final lines = await getInvoiceLines(invoiceId);
    final customer = await getCustomerById(invoice!.customerId);
    final payments = await getPaymentsForInvoice(invoiceId);
    
    return {
      'invoice': invoice,
      'lines': lines,
      'customer': customer,
      'payments': payments,
    };
  }

  Future<String> getNextInvoiceNumber() async {
    final db = await database;
    final result = await db.rawQuery(
      "SELECT invoice_number FROM invoices WHERE invoice_number LIKE 'INV-%' ORDER BY created_at DESC LIMIT 1"
    );
    
    int nextNumber = 1;
    if (result.isNotEmpty) {
      final lastNumber = result.first['invoice_number'] as String;
      final match = RegExp(r'INV-(\d+)').firstMatch(lastNumber);
      if (match != null) {
        nextNumber = int.parse(match.group(1)!) + 1;
      }
    }
    
    return 'INV-${nextNumber.toString().padLeft(4, '0')}';
  }

  // ==================== PAYMENT CRUD ====================

  Future<String> insertPayment(Payment payment) async {
    final db = await database;
    await db.insert('payments', payment.toMap());
    
    // Update invoice status if fully paid
    final payments = await getPaymentsForInvoice(payment.invoiceId);
    final totalPaid = payments.fold<double>(0, (sum, p) => sum + p.amount);
    
    final invoiceData = await getInvoiceWithDetails(payment.invoiceId);
    final lines = invoiceData['lines'] as List<InvoiceLine>;
    final total = lines.fold<double>(0, (sum, l) => sum + l.total);
    
    if (totalPaid >= total) {
      await updateInvoiceStatus(payment.invoiceId, 'paid');
    }
    
    return payment.id;
  }

  Future<List<Payment>> getPaymentsForInvoice(String invoiceId) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'payments',
      where: 'invoice_id = ?',
      whereArgs: [invoiceId],
      orderBy: 'payment_date DESC',
    );
    return List.generate(maps.length, (i) => Payment.fromMap(maps[i]));
  }

  Future<void> deletePayment(String id) async {
    final db = await database;
    await db.delete('payments', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== DASHBOARD STATS ====================

  Future<Map<String, dynamic>> getDashboardStats() async {
    final db = await database;
    
    // Total invoices count
    final totalInvoices = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM invoices')
    ) ?? 0;
    
    // Pending (not paid) count
    final pendingInvoices = Sqflite.firstIntValue(
      await db.rawQuery("SELECT COUNT(*) FROM invoices WHERE status != 'paid'")
    ) ?? 0;
    
    // Paid count
    final paidInvoices = Sqflite.firstIntValue(
      await db.rawQuery("SELECT COUNT(*) FROM invoices WHERE status = 'paid'")
    ) ?? 0;
    
    // Total customers
    final totalCustomers = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM customers')
    ) ?? 0;
    
    // Total revenue (from paid invoices)
    final revenueResult = await db.rawQuery('''
      SELECT SUM(p.amount) as total FROM payments p
      JOIN invoices i ON p.invoice_id = i.id
    ''');
    final totalRevenue = (revenueResult.first['total'] as num?)?.toDouble() ?? 0.0;
    
    // Outstanding amount
    final outstandingResult = await db.rawQuery('''
      SELECT 
        (SELECT SUM(il.quantity * il.unit_price * (1 + il.gst_rate/100) * (1 - il.discount/100)) 
         FROM invoice_lines il 
         JOIN invoices i ON il.invoice_id = i.id 
         WHERE i.status != 'paid') -
        (SELECT SUM(amount) FROM payments) as outstanding
    ''');
    final outstanding = (outstandingResult.first['outstanding'] as num?)?.toDouble() ?? 0.0;
    
    return {
      'totalInvoices': totalInvoices,
      'pendingInvoices': pendingInvoices,
      'paidInvoices': paidInvoices,
      'totalCustomers': totalCustomers,
      'totalRevenue': totalRevenue,
      'outstanding': outstanding,
    };
  }

  // ==================== UTILITY ====================

  Future<void> close() async {
    final db = await database;
    await db.close();
    _database = null;
  }

  Future<void> deleteDatabase() async {
    final Directory documentsDirectory = await getApplicationDocumentsDirectory();
    final String path = join(documentsDirectory.path, 'bizbill.db');
    await databaseFactory.deleteDatabase(path);
    _database = null;
  }
}

/// Extended Invoice with Customer Name
class InvoiceWithCustomer extends Invoice {
  final String? customerName;
  final double _total;

  InvoiceWithCustomer({
    required super.id,
    required super.invoiceNumber,
    required super.customerId,
    required super.issueDate,
    required super.dueDate,
    super.status,
    super.discountPercent,
    super.notes,
    super.terms,
    super.poNumber,
    super.signaturePath,
    required super.createdAt,
    required super.updatedAt,
    this.customerName,
    double total = 0,
  }) : _total = total;

  @override
  double get total => _total;

  factory InvoiceWithCustomer.fromMap(Map<String, dynamic> map) {
    return InvoiceWithCustomer(
      id: map['id'],
      invoiceNumber: map['invoice_number'],
      customerId: map['customer_id'],
      issueDate: DateTime.parse(map['issue_date']),
      dueDate: DateTime.parse(map['due_date']),
      status: map['status'],
      discountPercent: map['discount_percent'],
      notes: map['notes'],
      terms: map['terms'],
      poNumber: map['po_number'],
      signaturePath: map['signature_path'],
      createdAt: DateTime.parse(map['created_at']),
      updatedAt: DateTime.parse(map['updated_at']),
      customerName: map['customer_name'],
      total: (map['total_amount'] as num?)?.toDouble() ?? 0,
    );
  }
}

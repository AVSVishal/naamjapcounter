import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:intl/intl.dart';
import '../database/database_helper.dart';

class PDFGenerator {
  static Future<File> generateInvoicePDF({
    required Invoice invoice,
    required BusinessProfile business,
    Customer? customer,
    required List<InvoiceLine> lines,
    required List<Payment> payments,
  }) async {
    final pdf = pw.Document();

    final font = await rootBundle.load('assets/fonts/NotoSans-Regular.ttf');
    final fontBold = await rootBundle.load('assets/fonts/NotoSans-Bold.ttf');
    final ttf = pw.Font.ttf(font);
    final ttfBold = pw.Font.ttf(fontBold);

    final subtotal = lines.fold<double>(0, (sum, l) => sum + l.amount);
    final totalDiscount = subtotal * (invoice.discountPercent ?? 0) / 100;
    final taxAmount = lines.fold<double>(0, (sum, l) => sum + l.gstAmount);
    final total = subtotal - totalDiscount + taxAmount;
    final paidAmount = payments.fold<double>(0, (sum, p) => sum + p.amount);
    final balanceDue = total - paidAmount;

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // Header
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        'INVOICE',
                        style: pw.TextStyle(
                          font: ttfBold,
                          fontSize: 24,
                          color: const PdfColor.fromHex('6E33B1'),
                        ),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Text(
                        invoice.invoiceNumber,
                        style: pw.TextStyle(
                          font: ttfBold,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                  pw.Container(
                    padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: pw.BoxDecoration(
                      color: const PdfColor.fromHex('F3F0FA'),
                      borderRadius: pw.BorderRadius.circular(20),
                    ),
                    child: pw.Text(
                      invoice.status.toUpperCase(),
                      style: pw.TextStyle(
                        font: ttfBold,
                        color: const PdfColor.fromHex('6E33B1'),
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),

              pw.SizedBox(height: 30),

              // Business & Customer Info
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'From:',
                          style: pw.TextStyle(
                            font: ttfBold,
                            fontSize: 10,
                            color: const PdfColor.fromHex('6B7280'),
                          ),
                        ),
                        pw.SizedBox(height: 4),
                        pw.Text(
                          business.name,
                          style: pw.TextStyle(
                            font: ttfBold,
                            fontSize: 14,
                          ),
                        ),
                        if (business.phone != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text(business.phone!, style: pw.TextStyle(font: ttf, fontSize: 10)),
                        ],
                        if (business.email != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text(business.email!, style: pw.TextStyle(font: ttf, fontSize: 10)),
                        ],
                        if (business.gstNumber != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text('GST: ${business.gstNumber}', style: pw.TextStyle(font: ttf, fontSize: 10)),
                        ],
                        if (business.address != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text(business.address!, style: pw.TextStyle(font: ttf, fontSize: 10)),
                        ],
                      ],
                    ),
                  ),
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        pw.Text(
                          'Bill To:',
                          style: pw.TextStyle(
                            font: ttfBold,
                            fontSize: 10,
                            color: const PdfColor.fromHex('6B7280'),
                          ),
                        ),
                        pw.SizedBox(height: 4),
                        pw.Text(
                          customer?.name ?? 'Unknown Customer',
                          style: pw.TextStyle(
                            font: ttfBold,
                            fontSize: 14,
                          ),
                          textAlign: pw.TextAlign.right,
                        ),
                        if (customer?.phone != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text(customer!.phone!, 
                            style: pw.TextStyle(font: ttf, fontSize: 10),
                            textAlign: pw.TextAlign.right),
                        ],
                        if (customer?.email != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text(customer!.email!, 
                            style: pw.TextStyle(font: ttf, fontSize: 10),
                            textAlign: pw.TextAlign.right),
                        ],
                        if (customer?.address != null) ...[
                          pw.SizedBox(height: 2),
                          pw.Text(customer!.address!, 
                            style: pw.TextStyle(font: ttf, fontSize: 10),
                            textAlign: pw.TextAlign.right),
                        ],
                      ],
                    ),
                  ),
                ],
              ),

              pw.SizedBox(height: 20),

              // Dates
              pw.Container(
                padding: const pw.EdgeInsets.all(12),
                decoration: pw.BoxDecoration(
                  color: const PdfColor.fromHex('F8F9FB'),
                  borderRadius: pw.BorderRadius.circular(8),
                ),
                child: pw.Row(
                  children: [
                    pw.Expanded(
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text(
                            'Issue Date',
                            style: pw.TextStyle(
                              font: ttf,
                              fontSize: 9,
                              color: const PdfColor.fromHex('6B7280'),
                            ),
                          ),
                          pw.Text(
                            DateFormat('dd MMM yyyy').format(invoice.issueDate),
                            style: pw.TextStyle(font: ttfBold, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    pw.Expanded(
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text(
                            'Due Date',
                            style: pw.TextStyle(
                              font: ttf,
                              fontSize: 9,
                              color: const PdfColor.fromHex('6B7280'),
                            ),
                          ),
                          pw.Text(
                            DateFormat('dd MMM yyyy').format(invoice.dueDate),
                            style: pw.TextStyle(font: ttfBold, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              pw.SizedBox(height: 20),

              // Line Items Table
              pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(4),
                  1: const pw.FlexColumnWidth(2),
                  2: const pw.FlexColumnWidth(2),
                  3: const pw.FlexColumnWidth(2),
                },
                children: [
                  // Header
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(
                      color: PdfColor.fromHex('6E33B1'),
                    ),
                    children: [
                      _buildTableHeader('Item Description', ttfBold),
                      _buildTableHeader('Qty', ttfBold, align: pw.TextAlign.center),
                      _buildTableHeader('Rate', ttfBold, align: pw.TextAlign.right),
                      _buildTableHeader('Amount', ttfBold, align: pw.TextAlign.right),
                    ],
                  ),
                  // Items
                  ...lines.map((line) => pw.TableRow(
                    children: [
                      pw.Padding(
                        padding: const pw.EdgeInsets.all(8),
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Text(
                              line.description,
                              style: pw.TextStyle(font: ttf, fontSize: 10),
                            ),
                            if (line.gstRate > 0)
                              pw.Text(
                                'GST ${line.gstRate.toStringAsFixed(0)}%',
                                style: pw.TextStyle(
                                  font: ttf,
                                  fontSize: 8,
                                  color: const PdfColor.fromHex('6B7280'),
                                ),
                              ),
                          ],
                        ),
                      ),
                      pw.Padding(
                        padding: const pw.EdgeInsets.all(8),
                        child: pw.Text(
                          line.quantity.toStringAsFixed(0),
                          style: pw.TextStyle(font: ttf, fontSize: 10),
                          textAlign: pw.TextAlign.center,
                        ),
                      ),
                      pw.Padding(
                        padding: const pw.EdgeInsets.all(8),
                        child: pw.Text(
                          '₹${line.unitPrice.toStringAsFixed(2)}',
                          style: pw.TextStyle(font: ttf, fontSize: 10),
                          textAlign: pw.TextAlign.right,
                        ),
                      ),
                      pw.Padding(
                        padding: const pw.EdgeInsets.all(8),
                        child: pw.Text(
                          '₹${line.total.toStringAsFixed(2)}',
                          style: pw.TextStyle(font: ttfBold, fontSize: 10),
                          textAlign: pw.TextAlign.right,
                        ),
                      ),
                    ],
                  )),
                ],
              ),

              pw.SizedBox(height: 20),

              // Totals
              pw.Row(
                children: [
                  pw.Spacer(),
                  pw.Container(
                    width: 250,
                    child: pw.Column(
                      children: [
                        _buildTotalRow('Subtotal', subtotal, ttf, ttfBold),
                        if (invoice.discountPercent != null && invoice.discountPercent! > 0) ...[
                          pw.SizedBox(height: 4),
                          _buildTotalRow(
                            'Discount (${invoice.discountPercent}%)', 
                            -totalDiscount, 
                            ttf, 
                            ttfBold,
                            isDiscount: true,
                          ),
                        ],
                        pw.SizedBox(height: 4),
                        _buildTotalRow('Tax', taxAmount, ttf, ttfBold),
                        pw.Divider(),
                        _buildTotalRow('Total', total, ttf, ttfBold, isBold: true),
                        if (paidAmount > 0) ...[
                          pw.SizedBox(height: 4),
                          _buildTotalRow('Paid', paidAmount, ttf, ttfBold, isPaid: true),
                          pw.SizedBox(height: 8),
                          pw.Container(
                            padding: const pw.EdgeInsets.all(8),
                            decoration: pw.BoxDecoration(
                              color: balanceDue <= 0 
                                  ? const PdfColor.fromHex('D1FAE5')
                                  : const PdfColor.fromHex('FEF3C7'),
                              borderRadius: pw.BorderRadius.circular(4),
                            ),
                            child: pw.Row(
                              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                              children: [
                                pw.Text(
                                  balanceDue <= 0 ? 'PAID IN FULL' : 'BALANCE DUE',
                                  style: pw.TextStyle(
                                    font: ttfBold,
                                    fontSize: 10,
                                    color: balanceDue <= 0 
                                        ? const PdfColor.fromHex('10B981')
                                        : const PdfColor.fromHex('F59E0B'),
                                  ),
                                ),
                                pw.Text(
                                  '₹${balanceDue > 0 ? balanceDue.toStringAsFixed(2) : '0.00'}',
                                  style: pw.TextStyle(
                                    font: ttfBold,
                                    fontSize: 14,
                                    color: balanceDue <= 0 
                                        ? const PdfColor.fromHex('10B981')
                                        : const PdfColor.fromHex('F59E0B'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),

              pw.Spacer(),

              // Footer
              pw.Divider(),
              pw.SizedBox(height: 8),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Text(
                    'Thank you for your business!',
                    style: pw.TextStyle(
                      font: ttf,
                      fontSize: 10,
                      color: const PdfColor.fromHex('6B7280'),
                    ),
                  ),
                ],
              ),
              if (business.upiId != null) ...[
                pw.SizedBox(height: 4),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  children: [
                    pw.Text(
                      'Pay via UPI: ${business.upiId}',
                      style: pw.TextStyle(
                        font: ttfBold,
                        fontSize: 10,
                        color: const PdfColor.fromHex('6E33B1'),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          );
        },
      ),
    );

    // Save PDF
    final output = await getTemporaryDirectory();
    final file = File('${output.path}/Invoice_${invoice.invoiceNumber}.pdf');
    await file.writeAsBytes(await pdf.save());

    return file;
  }

  static pw.Widget _buildTableHeader(String text, pw.Font font, {pw.TextAlign? align}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          font: font,
          color: PdfColors.white,
          fontSize: 10,
        ),
        textAlign: align ?? pw.TextAlign.left,
      ),
    );
  }

  static pw.Widget _buildTotalRow(
    String label,
    double amount,
    pw.Font regularFont,
    pw.Font boldFont, {
    bool isBold = false,
    bool isDiscount = false,
    bool isPaid = false,
  }) {
    PdfColor color = const PdfColor.fromHex('09030E');
    if (isDiscount) color = const PdfColor.fromHex('10B981');
    if (isPaid) color = const PdfColor.fromHex('10B981');

    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text(
          label,
          style: pw.TextStyle(
            font: isBold ? boldFont : regularFont,
            fontSize: isBold ? 12 : 10,
          ),
        ),
        pw.Text(
          '₹${amount.toStringAsFixed(2)}',
          style: pw.TextStyle(
            font: isBold ? boldFont : regularFont,
            fontSize: isBold ? 14 : 10,
            color: color,
          ),
        ),
      ],
    );
  }
}

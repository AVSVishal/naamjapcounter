import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:convert';

// Date Formatting
String formatDate(DateTime date) {
  return DateFormat('dd MMM yyyy').format(date);
}

String formatDateTime(DateTime date) {
  return DateFormat('dd MMM yyyy, hh:mm a').format(date);
}

String formatCurrency(double amount, String currency) {
  final formatter = NumberFormat.currency(symbol: currency, decimalDigits: 2);
  return formatter.format(amount);
}

String formatCompactCurrency(double amount, String currency) {
  final formatter = NumberFormat.compactCurrency(symbol: currency, decimalDigits: 1);
  return formatter.format(amount);
}

// String Utilities
String getInitials(String name) {
  final parts = name.trim().split(' ');
  if (parts.length == 1) {
    return parts[0].substring(0, min(2, parts[0].length)).toUpperCase();
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

String truncate(String text, int maxLength) {
  if (text.length <= maxLength) return text;
  return '${text.substring(0, maxLength)}...';
}

String toTitleCase(String text) {
  if (text.isEmpty) return text;
  return text.split(' ').map((word) {
    if (word.isEmpty) return word;
    return word[0].toUpperCase() + word.substring(1).toLowerCase();
  }).join(' ');
}

// ID Generation
String generateId() {
  return '${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(9999)}';
}

// Color Utilities
Color getAvatarColor(String name) {
  final colors = [
    const Color(0xFF6E33B1),
    const Color(0xFF7B52D9),
    const Color(0xFF10B981),
    const Color(0xFF3B82F6),
    const Color(0xFFF59E0B),
    const Color(0xFFEF4444),
    const Color(0xFF8B5CF6),
    const Color(0xFFEC4899),
  ];
  int hash = 0;
  for (int i = 0; i < name.length; i++) {
    hash = name.codeUnitAt(i) + ((hash << 5) - hash);
  }
  return colors[hash.abs() % colors.length];
}

Color getStatusColor(String status) {
  switch (status.toLowerCase()) {
    case 'paid':
      return const Color(0xFF10B981);
    case 'sent':
      return const Color(0xFF3B82F6);
    case 'overdue':
      return const Color(0xFFEF4444);
    case 'draft':
      return const Color(0xFF9CA3AF);
    default:
      return const Color(0xFF6B7280);
  }
}

// GST Calculations
double calculateGST(double amount, double rate) {
  return amount * rate / 100;
}

double calculateCGST(double amount, double rate) {
  return calculateGST(amount, rate) / 2;
}

double calculateSGST(double amount, double rate) {
  return calculateGST(amount, rate) / 2;
}

double calculateDiscount(double amount, double percentage) {
  return amount * percentage / 100;
}

// Validation
bool isValidEmail(String email) {
  return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email);
}

bool isValidPhone(String phone) {
  return RegExp(r'^[0-9]{10}$').hasMatch(phone);
}

// UPI Link Generation
String generateUPILink({
  required String upiId,
  required String name,
  required double amount,
  required String transactionNote,
}) {
  return 'upi://pay?pa=${Uri.encodeComponent(upiId)}&pn=${Uri.encodeComponent(name)}&am=${amount.toStringAsFixed(2)}&tn=${Uri.encodeComponent(transactionNote)}&cu=INR';
}

// Payment Method
String getPaymentMethodIcon(String method) {
  switch (method.toLowerCase()) {
    case 'cash':
      return '💵';
    case 'upi':
    case 'phonepe':
    case 'gpay':
    case 'paytm':
      return '📱';
    case 'card':
      return '💳';
    case 'bank':
      return '🏦';
    case 'cheque':
      return '📋';
    default:
      return '💰';
  }
}

String getStatusLabel(String status) {
  switch (status.toLowerCase()) {
    case 'paid':
      return 'Paid';
    case 'sent':
      return 'Sent';
    case 'overdue':
      return 'Overdue';
    case 'draft':
      return 'Draft';
    default:
      return status;
  }
}

// Date Utilities
bool isOverdue(DateTime dueDate) {
  return DateTime.now().isAfter(dueDate);
}

int daysBetween(DateTime from, DateTime to) {
  return to.difference(from).inDays;
}

String getGreeting() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  return 'Good Evening';
}

String getGreetingInHindi() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'शुभ प्रभात';
  if (hour < 17) return 'नमस्कार';
  return 'शुभ संध्या';
}

// JSON Utilities
String toJSON(Map<String, dynamic> map) {
  return jsonEncode(map);
}

Map<String, dynamic> fromJSON(String json) {
  return jsonDecode(json) as Map<String, dynamic>;
}

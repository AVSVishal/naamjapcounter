#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# 🔐 Spend The Money - Keystore Generator Script
# ═══════════════════════════════════════════════════════════════════
# Is script ko terminal mein run karo, details enter karo,
# aur automatically keystore ban jaayega!
# ═══════════════════════════════════════════════════════════════════

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║          🔐 SPEND THE MONEY - KEYSTORE GENERATOR                 ║"
echo "║              Google Play Store Publishing Setup                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Check if running in android folder
if [[ ! -f "../pubspec.yaml" && ! -f "pubspec.yaml" ]]; then
    echo "⚠️  Warning: Make sure you are in the android/ folder of your Flutter project!"
    echo "   Example: cd V06/android"
    echo ""
fi

# Keystore filename
KEYSTORE_FILE="spend-money.keystore"
ALIAS_NAME="spendmoney"

# Check if keystore already exists
if [ -f "$KEYSTORE_FILE" ]; then
    echo "⚠️  Keystore already exists: $KEYSTORE_FILE"
    echo ""
    read -p "Overwrite existing keystore? (y/N): " overwrite
    if [[ ! $overwrite =~ ^[Yy]$ ]]; then
        echo "❌ Cancelled. Existing keystore preserved."
        exit 0
    fi
    echo ""
fi

echo "📋 Please enter the following details:"
echo "═══════════════════════════════════════"
echo ""

# Get password
read -s -p "🔑 Enter keystore password (min 6 chars): " PASSWORD
echo ""
read -s -p "🔑 Re-enter password: " PASSWORD_CONFIRM
echo ""

if [ "$PASSWORD" != "$PASSWORD_CONFIRM" ]; then
    echo ""
    echo "❌ ERROR: Passwords do not match!"
    exit 1
fi

if [ ${#PASSWORD} -lt 6 ]; then
    echo ""
    echo "❌ ERROR: Password must be at least 6 characters!"
    exit 1
fi

# Get user details
echo ""
read -p "👤 Your First and Last Name: " NAME
echo ""
read -p "🏢 Organizational Unit (e.g., AVSVishalMedia): " ORG_UNIT
echo ""
read -p "🏛️  Organization Name (e.g., AVSVishalMedia): " ORG
echo ""
read -p "🌆 City or Locality: " CITY
echo ""
read -p "🗺️  State or Province: " STATE
echo ""
read -p "🇮🇳 Country Code (2 letters, e.g., IN): " COUNTRY
echo ""

echo "═══════════════════════════════════════"
echo "🔨 Generating keystore..."
echo "═══════════════════════════════════════"
echo ""

# Generate keystore with keytool
keytool -genkey -v \
    -keystore "$KEYSTORE_FILE" \
    -alias "$ALIAS_NAME" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass "$PASSWORD" \
    -keypass "$PASSWORD" \
    -dname "CN=$NAME, OU=$ORG_UNIT, O=$ORG, L=$CITY, ST=$STATE, C=$COUNTRY" \
    2>&1

# Check if generation was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                    ✅ SUCCESS! KEYSTORE CREATED                  ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo ""
    echo "📁 File created: $KEYSTORE_FILE"
    echo "🔤 Alias: $ALIAS_NAME"
    echo "📍 Location: $(pwd)/$KEYSTORE_FILE"
    echo ""
    
    # Create key.properties file
    echo "📝 Creating key.properties file..."
    cat > key.properties << EOF
storePassword=$PASSWORD
keyPassword=$PASSWORD
keyAlias=$ALIAS_NAME
storeFile=$KEYSTORE_FILE
EOF
    echo "✅ key.properties created!"
    echo ""
    
    # Show keystore info
    echo "📊 Keystore Info:"
    echo "══════════════════"
    keytool -list -v -keystore "$KEYSTORE_FILE" -alias "$ALIAS_NAME" -storepass "$PASSWORD" 2>&1 | grep -E "(Alias|Creation|Owner|Issuer|Valid)"
    echo ""
    
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                     ⚠️  IMPORTANT - READ THIS                   ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo ""
    echo "🔐 BACKUP YOUR KEYSTORE FILE!"
    echo "   • File: $KEYSTORE_FILE"
    echo "   • Location: $(pwd)/"
    echo ""
    echo "📋 Save these details safely:"
    echo "   Password: $PASSWORD"
    echo "   Alias: $ALIAS_NAME"
    echo ""
    echo "☠️  WARNING: If you lose this keystore, you CANNOT update your app!"
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
    echo "📱 NEXT STEPS:"
    echo "═══════════════════════════════════════════════════════════════════"
    echo ""
    echo "1️⃣  Copy build.gradle.kts from V02_Keystore_Setup folder"
    echo "    to: android/app/build.gradle.kts"
    echo ""
    echo "2️⃣  Build App Bundle with this command:"
    echo "    flutter build appbundle"
    echo ""
    echo "3️⃣  Upload to Play Store:"
    echo "    build/app/outputs/bundle/release/app-release.aab"
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
    echo ""
    
else
    echo ""
    echo "❌ FAILED: Keystore generation failed!"
    echo "   Please check if Java/keytool is installed."
    exit 1
fi

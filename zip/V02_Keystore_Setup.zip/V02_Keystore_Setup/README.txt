╔══════════════════════════════════════════════════════════════════╗
║           🔐 V02 - KEYSTORE SETUP PACKAGE                        ║
║     Spend The Money - Play Store Publishing                      ║
╚══════════════════════════════════════════════════════════════════╝

YE PACKAGE KYA HAI?
═══════════════════
Is package mein sirf wo files hain jo aapko Play Store ke liye 
keystore generate karne aur AAB file build karne ke liye chahiye.

FILES INCLUDED:
═══════════════

1. 🔐 generate_keystore.sh
   • Shell script jo keystore automatically generate karta hai
   • Terminal mein bas "bash generate_keystore.sh" run karo
   • Details enter karo, baaki sab automatic!

2. 🔧 build.gradle.kts
   • Signing configuration wala gradle file
   • Isko android/app/build.gradle.kts mein copy karo

3. 📱 ANDROID_STUDIO_COMMANDS.txt
   • All commands jo aapko chahiye Android Studio mein
   • Step-by-step guide with exact commands

4. ℹ️ README.txt
   • Ye file - instructions

═══════════════════════════════════════════════════════════════════

HOW TO USE:
═══════════

STEP 1: Script ko android folder mein copy karo:
   FROM: V02_Keystore_Setup/generate_keystore.sh
   TO:   V06/android/generate_keystore.sh

STEP 2: Terminal open karo Android Studio mein:
   View → Tool Windows → Terminal
   Ya Alt + F12

STEP 3: Commands run karo:
   cd android
   bash generate_keystore.sh

STEP 4: Details enter karo:
   • Password (min 6 chars)
   • Your Name
   • Organization
   • City, State
   • Country code (IN)

STEP 5: Gradle file update karo:
   build.gradle.kts copy karo to android/app/

STEP 6: App Bundle build karo:
   flutter build appbundle

STEP 7: Upload to Play Store!

═══════════════════════════════════════════════════════════════════

⚠️ IMPORTANT WARNINGS:
═════════════════════

• spend-money.keystore file HAMESHA backup rakho!
• key.properties file ko kabhi GitHub pe mat daalo
• Agar keystore kho gaya toh app update nahi kar paoge
• Password yaad rakho ya secure jagah save karo

═══════════════════════════════════════════════════════════════════

NEXT VERSION ZIP KE LIYE:
════════════════════════
Jab bhi naya version banao:
1. pubspec.yaml mein version badlo (1.0.1+2, etc)
2. flutter build appbundle
3. Naya AAB file milega

═══════════════════════════════════════════════════════════════════

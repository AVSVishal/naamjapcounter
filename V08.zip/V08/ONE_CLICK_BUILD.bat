@echo off
chcp 65001 >nul
title 🎮 SPEND THE MONEY - Play Store Build Setup
color 0B

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║     🎮 SPEND THE MONEY - PLAY STORE BUILD SETUP 🎮        ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

:: Check if running in project root
if not exist "pubspec.yaml" (
    color 0C
    echo ❌ Error: Please run this script from the project root folder
    echo    (Where pubspec.yaml is located)
    pause
    exit /b 1
)

set "PROJECT_ROOT=%CD%"
set "KEYSTORE_PATH=%PROJECT_ROOT%\android\app\keystore.jks"
set "KEY_PROPS_PATH=%PROJECT_ROOT%\android\key.properties"

echo ╔════════════════════════════════════════════════════════════╗
echo ║              🔐 Enter Your Keystore Details               ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

set /p "FULL_NAME=📛 Enter your FULL NAME: "
set /p "ORGANIZATION=🏢 Enter your ORGANIZATION: "
if "%ORGANIZATION%"=="" set ORGANIZATION=Unknown
set /p "COUNTRY_CODE=🌍 Enter your COUNTRY CODE (2 letters, e.g., IN, US): "
if "%COUNTRY_CODE%"=="" set COUNTRY_CODE=IN
set /p "KEYSTORE_PASSWORD=🔑 Enter KEYSTORE PASSWORD (min 6 chars): "
echo.
set /p "KEYSTORE_PASSWORD_CONFIRM=🔑 Confirm KEYSTORE PASSWORD: "
echo.

if not "%KEYSTORE_PASSWORD%"=="%KEYSTORE_PASSWORD_CONFIRM%" (
    color 0C
    echo ❌ Passwords do not match!
    pause
    exit /b 1
)

set /p "KEY_ALIAS=🔑 Enter KEY ALIAS (or press Enter for 'upload'): "
if "%KEY_ALIAS%"=="" set KEY_ALIAS=upload

set /p "KEY_PASSWORD=🔑 Enter KEY PASSWORD (or press Enter to use keystore password): "
echo.
if "%KEY_PASSWORD%"=="" set KEY_PASSWORD=%KEYSTORE_PASSWORD%

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                   📋 Confirm Details                       ║
echo ╚════════════════════════════════════════════════════════════╝
echo    Name:        %FULL_NAME%
echo    Org:         %ORGANIZATION%
echo    Country:     %COUNTRY_CODE%
echo    Key Alias:   %KEY_ALIAS%
echo    Keystore:    %KEYSTORE_PATH%
echo.
pause

:: Generate keystore
echo.
echo 🔐 Generating Keystore...

if exist "%KEYSTORE_PATH%" (
    echo ⚠️  Keystore already exists. Overwrite? (Y/N)
    set /p OVERWRITE=
    if /I not "%OVERWRITE%"=="Y" goto :skip_keystore
)

:: Find keytool
for /f "delims=" %%i in ('where keytool 2^>nul') do set "KEYTOOL=%%i"
if "%KEYTOOL%"=="" (
    :: Try common Java locations
    if exist "%JAVA_HOME%\bin\keytool.exe" set "KEYTOOL=%JAVA_HOME%\bin\keytool.exe"
    if exist "C:\Program Files\Java\jdk*\bin\keytool.exe" (
        for /d %%D in ("C:\Program Files\Java\jdk*") do set "KEYTOOL=%%D\bin\keytool.exe"
    )
)

if "%KEYTOOL%"=="" (
    color 0C
    echo ❌ keytool not found! Make sure Java JDK is installed.
    pause
    exit /b 1
)

echo Found keytool at: %KEYTOOL%

"%KEYTOOL%" -genkey -v -keystore "%KEYSTORE_PATH%" -alias "%KEY_ALIAS%" -keyalg RSA -keysize 2048 -validity 10000 -storepass "%KEYSTORE_PASSWORD%" -keypass "%KEY_PASSWORD%" -dname "CN=%FULL_NAME%, O=%ORGANIZATION%, C=%COUNTRY_CODE%"

if errorlevel 1 (
    color 0C
    echo ❌ Keystore generation failed!
    pause
    exit /b 1
)

echo ✅ Keystore created!

:skip_keystore

:: Create key.properties
echo.
echo 📝 Creating key.properties...
(
echo storePassword=%KEYSTORE_PASSWORD%
echo keyPassword=%KEY_PASSWORD%
echo keyAlias=%KEY_ALIAS%
echo storeFile=keystore.jks
) > "%KEY_PROPS_PATH%"

echo ✅ key.properties created!

:: Show summary
echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                ✅ SETUP COMPLETE!                          ║
echo ╚════════════════════════════════════════════════════════════╝
echo.
echo 📁 Files Created:
echo    • %KEYSTORE_PATH%
echo    • %KEY_PROPS_PATH%
echo.
echo 🔒 IMPORTANT - Save these details safely:
echo    Keystore Path:  %KEYSTORE_PATH%
echo    Keystore Pass:  %KEYSTORE_PASSWORD%
echo    Key Alias:      %KEY_ALIAS%
echo    Key Password:   %KEY_PASSWORD%
echo.
echo ⚠️  WARNING: Never share or lose your keystore!
echo     You cannot update your app without the same keystore!
echo.

:: Build AAB
echo 🚀 Ready to build Play Store AAB?
set /p BUILD_AAB=Build AAB now? (Y/n): 

if /I "%BUILD_AAB%"=="N" goto :skip_build

echo.
echo 🏗️  Cleaning and building AAB...
flutter clean
flutter pub get
flutter build appbundle --release

set "AAB_PATH=%PROJECT_ROOT%\build\app\outputs\bundle\release\app-release.aab"

if exist "%AAB_PATH%" (
    echo.
    echo ╔════════════════════════════════════════════════════════════╗
    echo ║            🎉 AAB BUILT SUCCESSFULLY! 🎉                  ║
    echo ╚════════════════════════════════════════════════════════════╝
    echo.
    echo 📦 AAB Location:
    echo    %AAB_PATH%
    echo.
    echo 📤 Next Steps:
    echo    1. Go to: https://play.google.com/console
    echo    2. Create new app and upload this AAB file
    echo    3. Fill in store listing details
    echo    4. Submit for review!
) else (
    color 0C
    echo ❌ AAB build failed. Check errors above.
)

goto :done

:skip_build
echo.
echo 📋 To build AAB later, run:
echo    flutter build appbundle --release

:done
echo.
echo ✨ Done!
pause

#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# 🚀 SPEND THE MONEY - ONE CLICK PLAY STORE BUILD SCRIPT
# ═══════════════════════════════════════════════════════════════════════════

set -e

YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RED='\033[1;31m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║     🎮 SPEND THE MONEY - PLAY STORE BUILD SETUP 🎮        ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running in project root
if [ ! -f "pubspec.yaml" ]; then
    echo -e "${RED}❌ Error: Please run this script from the project root folder${NC}"
    echo -e "${YELLOW}   (Where pubspec.yaml is located)${NC}"
    exit 1
fi

PROJECT_ROOT=$(pwd)
KEYSTORE_PATH="$PROJECT_ROOT/android/app/keystore.jks"
KEYSTORE_DIR="$PROJECT_ROOT/android/app"
KEY_PROPS_PATH="$PROJECT_ROOT/android/key.properties"

# Get user details
echo -e "${YELLOW}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${YELLOW}║              🔐 Enter Your Keystore Details                 ║${NC}"
echo -e "${YELLOW}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

read -p "📛 Enter your FULL NAME: " FULL_NAME
read -p "🏢 Enter your ORGANIZATION (or press Enter for blank): " ORGANIZATION
if [ -z "$ORGANIZATION" ]; then
    ORGANIZATION="Unknown"
fi
read -p "🌍 Enter your COUNTRY CODE (2 letters, e.g., IN, US, UK): " COUNTRY_CODE
if [ -z "$COUNTRY_CODE" ]; then
    COUNTRY_CODE="IN"
fi
read -p "🔑 Enter KEYSTORE PASSWORD (min 6 chars): " -s KEYSTORE_PASSWORD
echo ""
read -p "🔑 Confirm KEYSTORE PASSWORD: " -s KEYSTORE_PASSWORD_CONFIRM
echo ""

if [ "$KEYSTORE_PASSWORD" != "$KEYSTORE_PASSWORD_CONFIRM" ]; then
    echo -e "${RED}❌ Passwords do not match!${NC}"
    exit 1
fi

if [ ${#KEYSTORE_PASSWORD} -lt 6 ]; then
    echo -e "${RED}❌ Password must be at least 6 characters!${NC}"
    exit 1
fi

read -p "🔑 Enter KEY ALIAS (or press Enter for 'upload'): " KEY_ALIAS
if [ -z "$KEY_ALIAS" ]; then
    KEY_ALIAS="upload"
fi

read -p "🔑 Enter KEY PASSWORD (or press Enter to use keystore password): " -s KEY_PASSWORD
echo ""
if [ -z "$KEY_PASSWORD" ]; then
    KEY_PASSWORD="$KEYSTORE_PASSWORD"
fi

# Confirm details
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                   📋 Confirm Details                       ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo -e "   Name:        ${GREEN}$FULL_NAME${NC}"
echo -e "   Org:         ${GREEN}$ORGANIZATION${NC}"
echo -e "   Country:     ${GREEN}$COUNTRY_CODE${NC}"
echo -e "   Key Alias:   ${GREEN}$KEY_ALIAS${NC}"
echo -e "   Keystore:    ${GREEN}$KEYSTORE_PATH${NC}"
echo ""
read -p "✅ Press ENTER to continue or Ctrl+C to cancel..."

# Create keystore directory if needed
mkdir -p "$KEYSTORE_DIR"

# Check if keytool is available
if ! command -v keytool &> /dev/null; then
    echo -e "${RED}❌ keytool not found!${NC}"
    echo -e "${YELLOW}   Make sure Java JDK is installed and in your PATH${NC}"
    exit 1
fi

# Generate keystore
echo ""
echo -e "${YELLOW}🔐 Generating Keystore...${NC}"

# Check if keystore already exists
if [ -f "$KEYSTORE_PATH" ]; then
    echo -e "${YELLOW}⚠️  Keystore already exists at:$NC $KEYSTORE_PATH"
    read -p "Do you want to overwrite it? (y/N): " OVERWRITE
    if [[ ! $OVERWRITE =~ ^[Yy]$ ]]; then
        echo -e "${GREEN}✅ Using existing keystore${NC}"
    else
        rm -f "$KEYSTORE_PATH"
        generate_keystore=1
    fi
else
    generate_keystore=1
fi

if [ "$generate_keystore" = "1" ]; then
    keytool -genkey -v \
        -keystore "$KEYSTORE_PATH" \
        -alias "$KEY_ALIAS" \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass "$KEYSTORE_PASSWORD" \
        -keypass "$KEY_PASSWORD" \
        -dname "CN=$FULL_NAME, O=$ORGANIZATION, C=$COUNTRY_CODE"

    echo -e "${GREEN}✅ Keystore created successfully!${NC}"
fi

# Create key.properties
echo ""
echo -e "${YELLOW}📝 Creating key.properties...${NC}"

cat > "$KEY_PROPS_PATH" << EOF
storePassword=$KEYSTORE_PASSWORD
keyPassword=$KEY_PASSWORD
keyAlias=$KEY_ALIAS
storeFile=keystore.jks
EOF

echo -e "${GREEN}✅ key.properties created!${NC}"

# Display summary
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                ✅ SETUP COMPLETE!                          ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}📁 Files Created:${NC}"
echo -e "   • ${YELLOW}$KEYSTORE_PATH${NC}"
echo -e "   • ${YELLOW}$KEY_PROPS_PATH${NC}"
echo ""
echo -e "${CYAN}🔒 IMPORTANT - Save these details safely:${NC}"
echo -e "   Keystore Path:  ${YELLOW}$KEYSTORE_PATH${NC}"
echo -e "   Keystore Pass:  ${YELLOW}$KEYSTORE_PASSWORD${NC}"
echo -e "   Key Alias:      ${YELLOW}$KEY_ALIAS${NC}"
echo -e "   Key Password:   ${YELLOW}$KEY_PASSWORD${NC}"
echo ""
echo -e "${RED}⚠️  WARNING: Never share or lose your keystore!${NC}"
echo -e "${RED}    You cannot update your app without the same keystore!${NC}"
echo ""

# Ask to build AAB
echo -e "${YELLOW}🚀 Ready to build Play Store AAB?${NC}"
read -p "Build AAB now? (Y/n): " BUILD_AAB

if [[ ! $BUILD_AAB =~ ^[Nn]$ ]]; then
    echo ""
    echo -e "${YELLOW}🏗️  Cleaning and building AAB...${NC}"
    flutter clean
    flutter pub get
    flutter build appbundle --release

    AAB_PATH="$PROJECT_ROOT/build/app/outputs/bundle/release/app-release.aab"

    if [ -f "$AAB_PATH" ]; then
        echo ""
        echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${GREEN}║            🎉 AAB BUILT SUCCESSFULLY! 🎉                  ║${NC}"
        echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
        echo ""
        echo -e "${CYAN}📦 AAB Location:${NC}"
        echo -e "   ${YELLOW}$AAB_PATH${NC}"
        echo ""
        echo -e "${CYAN}📤 Next Steps:${NC}"
        echo -e "   1. Go to: ${YELLOW}https://play.google.com/console${NC}"
        echo -e "   2. Create new app and upload this AAB file"
        echo -e "   3. Fill in store listing details"
        echo -e "   4. Submit for review!"
    else
        echo -e "${RED}❌ AAB build failed. Check errors above.${NC}"
        exit 1
    fi
else
    echo ""
    echo -e "${CYAN}📋 To build AAB later, run:${NC}"
    echo -e "   ${YELLOW}flutter build appbundle --release${NC}"
fi

echo ""
echo -e "${GREEN}✨ Done!${NC}"

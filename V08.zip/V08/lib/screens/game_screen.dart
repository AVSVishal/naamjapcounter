import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:gap/gap.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../models/shop_item.dart';
import '../providers/game_provider.dart';
import '../theme/app_theme.dart';
import '../utils/currency_formatter.dart';
import '../services/ad_service.dart';
import '../services/analytics_service.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  final _qtyController = TextEditingController(text: '1');
  final _qtyFocus = FocusNode();
  GameMode _mode = GameMode.normal;

  late AnimationController _balanceAnimController;
  int _displayedBalance = 0;
  int _previousBalance = 0;

  final Map<int, int> _gridQty = {};

  BannerAd? _bannerAd;
  bool _isBannerLoaded = false;

  // Session tracking
  DateTime? _sessionStartTime;

  @override
  void initState() {
    super.initState();
    _balanceAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    final provider = context.read<GameProvider>();
    _displayedBalance = provider.balance;
    _previousBalance = provider.balance;
    _loadBannerAd();
    // Track game screen view
    AnalyticsService().logScreenView(screenName: 'game');
    // Track session start time
    _sessionStartTime = DateTime.now();
  }

  void _loadBannerAd() {
    if (_mode == GameMode.reel) return;
    _bannerAd?.dispose();
    _bannerAd = AdService().createBannerAd();
    if (_bannerAd != null) {
      _bannerAd!.load().then((_) {
        if (mounted) {
          setState(() => _isBannerLoaded = true);
        }
      });
    }
  }

  @override
  void dispose() {
    _qtyController.dispose();
    _qtyFocus.dispose();
    _balanceAnimController.dispose();
    _bannerAd?.dispose();
    super.dispose();
  }

  void _animateBalance(int from, int to) {
    _previousBalance = from;
    _balanceAnimController.reset();
    _balanceAnimController.addListener(_balanceListener);
    _balanceAnimController.forward().then((_) {
      _balanceAnimController.removeListener(_balanceListener);
      if (mounted) setState(() => _displayedBalance = to);
    });
  }

  void _balanceListener() {
    final provider = context.read<GameProvider>();
    if (mounted) {
      setState(() {
        _displayedBalance = (_previousBalance +
                (_balanceAnimController.value * (provider.balance - _previousBalance)))
            .round();
      });
    }
  }

  void _onBuy() async {
    final provider = context.read<GameProvider>();
    final qty = int.tryParse(_qtyController.text) ?? 0;
    final oldBal = provider.balance;
    final item = provider.currentItem;
    if (provider.buyItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      FocusScope.of(context).unfocus();
      // Track item purchase
      await AnalyticsService().logItemPurchase(
        itemName: item.name,
        quantity: qty,
        price: item.price(provider.isIndia).toDouble(),
        totalSpent: provider.totalSpent.toDouble(),
        remaining: provider.balance.toDouble(),
      );
      // Show interstitial ad after purchase (tracked in AdService)
      await AdService().onPurchase();
    } else {
      _showSnack(provider.lastMessage);
    }
  }

  void _onSell() async {
    final provider = context.read<GameProvider>();
    final qty = int.tryParse(_qtyController.text) ?? 0;
    final oldBal = provider.balance;
    final item = provider.currentItem;
    if (provider.sellItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      FocusScope.of(context).unfocus();
      // Track item sale
      await AnalyticsService().logItemSale(
        itemName: item.name,
        quantity: qty,
        price: item.price(provider.isIndia).toDouble(),
        totalSpent: provider.totalSpent.toDouble(),
        remaining: provider.balance.toDouble(),
      );
    } else {
      _showSnack(provider.lastMessage);
    }
  }

  void _onGridBuy(int itemIndex, int qty) async {
    final provider = context.read<GameProvider>();
    final oldIdx = provider.currentIndex;
    provider.goToItem(itemIndex);
    final oldBal = provider.balance;
    final item = provider.currentItem;
    if (provider.buyItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      setState(() => _gridQty[itemIndex] = 1);
      // Track grid item purchase
      await AnalyticsService().logItemPurchase(
        itemName: item.name,
        quantity: qty,
        price: item.price(provider.isIndia).toDouble(),
        totalSpent: provider.totalSpent.toDouble(),
        remaining: provider.balance.toDouble(),
      );
      // Show interstitial ad after purchase (tracked in AdService)
      await AdService().onPurchase();
    } else {
      _showSnack(provider.lastMessage);
    }
    provider.goToItem(oldIdx);
  }

  void _onGridSell(int itemIndex, int qty) async {
    final provider = context.read<GameProvider>();
    final oldIdx = provider.currentIndex;
    provider.goToItem(itemIndex);
    final oldBal = provider.balance;
    final item = provider.currentItem;
    if (provider.sellItem(qty)) {
      _animateBalance(oldBal, provider.balance);
      setState(() => _gridQty[itemIndex] = 1);
      // Track grid item sale
      await AnalyticsService().logItemSale(
        itemName: item.name,
        quantity: qty,
        price: item.price(provider.isIndia).toDouble(),
        totalSpent: provider.totalSpent.toDouble(),
        remaining: provider.balance.toDouble(),
      );
    } else {
      _showSnack(provider.lastMessage);
    }
    provider.goToItem(oldIdx);
  }

  void _showSnack(String msg) {
    if (msg.isEmpty) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(msg),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 80),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  void _navigateItem(int dir) {
    final provider = context.read<GameProvider>();
    final oldItem = provider.currentItem;
    _qtyController.text = '1';
    FocusScope.of(context).unfocus();
    if (dir > 0) provider.nextItem();
    if (dir < 0) provider.prevItem();
    // Track item navigation
    AnalyticsService().logItemNavigation(
      dir > 0 ? 'next' : 'prev',
      oldItem.name,
    );
  }

  void _incrementQty() {
    final current = int.tryParse(_qtyController.text) ?? 0;
    _qtyController.text = '${current + 1}';
  }

  void _decrementQty() {
    final current = int.tryParse(_qtyController.text) ?? 0;
    if (current > 1) _qtyController.text = '${current - 1}';
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<GameProvider>();

    if (_displayedBalance != provider.balance && !_balanceAnimController.isAnimating) {
      _displayedBalance = provider.balance;
    }

    final balanceText = CurrencyFormatter.format(
      _displayedBalance,
      indian: provider.isIndia,
      symbol: provider.country.currencySymbol,
    );

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _showExitDialog();
      },
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          backgroundColor: Colors.white,
          resizeToAvoidBottomInset: true,
          body: SafeArea(
            bottom: false,
            child: Column(
              children: [
                _buildTopBar(provider),
                Expanded(
                  child: switch (_mode) {
                    GameMode.normal => _buildNormalMode(provider),
                    GameMode.grid => _buildGridMode(provider),
                    GameMode.reel => _buildReelMode(provider),
                  },
                ),
                // Banner Ad (hidden in reel mode)
                if (_isBannerLoaded && _bannerAd != null && _mode != GameMode.reel)
                  Container(
                    height: 60,
                    margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: AdWidget(ad: _bannerAd!),
                  ),
                _buildBalanceBar(balanceText),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(GameProvider provider) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Row(
        children: [
          IconButton(
            onPressed: _showExitDialog,
            icon: const Icon(Icons.close_rounded, color: Color(0xFF666666)),
          ),
          const Spacer(),
          _buildModeChip(GameMode.normal, Icons.view_agenda_outlined, 'Normal'),
          const Gap(4),
          _buildModeChip(GameMode.grid, Icons.grid_view_outlined, 'Grid'),
          const Gap(4),
          _buildModeChip(GameMode.reel, Icons.videocam_outlined, 'Reel'),
          const Spacer(),
          IconButton(
            onPressed: () => _showReceiptSheet(provider),
            icon: const Icon(Icons.receipt_long_outlined, color: Color(0xFF666666)),
          ),
        ],
      ),
    );
  }

  Widget _buildModeChip(GameMode mode, IconData icon, String label) {
    final isActive = _mode == mode;
    return GestureDetector(
      onTap: () {
        setState(() {
          _mode = mode;
          // Track game mode change
          AnalyticsService().logGameModeChange(mode.toString().split('.').last);
          // Update AdService reel mode status
          AdService().setReelMode(mode == GameMode.reel);
          // Reload banner ad based on mode
          if (mode == GameMode.reel) {
            _bannerAd?.dispose();
            _bannerAd = null;
            _isBannerLoaded = false;
          } else {
            _loadBannerAd();
          }
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFF111827) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: isActive ? null : Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: isActive ? Colors.white : const Color(0xFF9CA3AF)),
            const Gap(4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: isActive ? Colors.white : const Color(0xFF9CA3AF),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── NORMAL MODE ──────────────────────────────────────
  Widget _buildNormalMode(GameProvider provider) {
    final item = provider.currentItem;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Column(
                children: [
                  // Spent Indicator
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppTheme.spentIndicatorBg,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.trending_down, size: 14, color: Colors.white),
                        const Gap(4),
                        Text('${provider.spentPercentage.toStringAsFixed(1)}% spent',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white)),
                      ],
                    ),
                  ),
                  const Gap(12),
                  // Item Image
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      _buildItemImage(item, size: 220),
                      // Nav arrows on sides
                      Positioned(
                        left: 0,
                        child: IconButton(
                          onPressed: () => _navigateItem(-1),
                          icon: const Icon(Icons.chevron_left, color: Color(0xFF9CA3AF), size: 32),
                          splashRadius: 24,
                        ),
                      ),
                      Positioned(
                        right: 0,
                        child: IconButton(
                          onPressed: () => _navigateItem(1),
                          icon: const Icon(Icons.chevron_right, color: Color(0xFF9CA3AF), size: 32),
                          splashRadius: 24,
                        ),
                      ),
                    ],
                  ),
                  const Gap(12),
                  // Item Name
                  Text(item.name,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
                  const Gap(8),
                  // Price & Owned
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppTheme.priceColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          provider.formatPrice(item.price(provider.isIndia)),
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.priceColor),
                        ),
                      ),
                      const Gap(12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppTheme.ownedBg,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text('Owned: ${item.owned}',
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.ownedText)),
                      ),
                    ],
                  ),
                  const Gap(20),
                  // Quantity Controls
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF9FAFB),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildQtyButton(Icons.remove, _decrementQty),
                        const Gap(12),
                        Container(
                          width: 100,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFE5E7EB)),
                          ),
                          child: TextField(
                            controller: _qtyController,
                            focusNode: _qtyFocus,
                            textAlign: TextAlign.center,
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Color(0xFF111827)),
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.zero,
                              hintText: '1',
                              hintStyle: TextStyle(color: Color(0xFF9CA3AF)),
                            ),
                          ),
                        ),
                        const Gap(12),
                        _buildQtyButton(Icons.add, _incrementQty),
                      ],
                    ),
                  ),
                  const Gap(16),
                  // Total Cost Preview
                  ValueListenableBuilder<TextEditingValue>(
                    valueListenable: _qtyController,
                    builder: (context, value, _) {
                      final qty = int.tryParse(value.text) ?? 0;
                      final total = qty * item.price(provider.isIndia);
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF3F4F6),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'Total: ${provider.formatPrice(total)}',
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF6B7280)),
                        ),
                      );
                    },
                  ),
                  const Gap(20),
                  // Buy / Sell Buttons
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 54,
                          child: OutlinedButton(
                            onPressed: _onSell,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppTheme.sellColor,
                              side: BorderSide(color: AppTheme.sellColor.withValues(alpha: 0.5), width: 2),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            child: const Text('Sell', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      ),
                      const Gap(12),
                      Expanded(
                        child: SizedBox(
                          height: 54,
                          child: ElevatedButton(
                            onPressed: _onBuy,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.buyColor,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              elevation: 0,
                            ),
                            child: const Text('Buy', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const Gap(16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQtyButton(IconData icon, VoidCallback onPressed) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFE5E7EB)),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 4)],
        ),
        child: Icon(icon, color: const Color(0xFF6B7280)),
      ),
    );
  }

  // ─── GRID MODE ──────────────────────────────────────────
  Widget _buildGridMode(GameProvider provider) {
    final items = provider.items;
    final crossAxisCount = MediaQuery.of(context).size.width > 600 ? 3 : 2;

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.68,
      ),
      itemCount: items.length,
      itemBuilder: (ctx, idx) {
        final item = items[idx];
        final owned = item.owned;
        final gridQtyVal = _gridQty[idx] ?? 1;

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE5E7EB)),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                  child: _buildNetworkImage(item, double.infinity),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
                child: Text(
                  item.name,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF111827)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  provider.formatPrice(item.price(provider.isIndia)),
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.priceColor),
                ),
              ),
              if (owned > 0)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                  child: Text(
                    'Owned: $owned',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: AppTheme.ownedText),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
                child: Row(
                  children: [
                    // Qty control
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: TextField(
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.number,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        onChanged: (v) => setState(() => _gridQty[idx] = int.tryParse(v) ?? 1),
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.zero,
                          hintText: '1',
                          hintStyle: TextStyle(fontSize: 12),
                        ),
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                      ),
                    ),
                    const Gap(6),
                    // Buy button
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _onGridBuy(idx, gridQtyVal),
                        child: Container(
                          height: 28,
                          decoration: BoxDecoration(
                            color: AppTheme.buyColor,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Icon(Icons.add, color: Colors.white, size: 18),
                        ),
                      ),
                    ),
                    const Gap(4),
                    // Sell button (only if owned)
                    if (owned > 0)
                      Expanded(
                        child: GestureDetector(
                          onTap: () => _onGridSell(idx, gridQtyVal),
                          child: Container(
                            height: 28,
                            decoration: BoxDecoration(
                              color: AppTheme.sellColor,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Icon(Icons.remove, color: Colors.white, size: 18),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── REEL MODE ─────────────────────────────────────────
  Widget _buildReelMode(GameProvider provider) {
    final items = provider.items;

    return PageView.builder(
      scrollDirection: Axis.vertical,
      itemCount: items.length,
      onPageChanged: (idx) {
        provider.goToItem(idx);
        setState(() => _gridQty[provider.currentIndex] = 1);
      },
      itemBuilder: (ctx, idx) {
        final item = items[idx];
        return Stack(
          fit: StackFit.expand,
          children: [
            // Full-screen background image
            _buildNetworkImage(item, MediaQuery.of(context).size.width),
            // Gradient overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.3),
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.7),
                  ],
                ),
              ),
            ),
            // UI Overlay
            SafeArea(
              child: Column(
                children: [
                  // Top bar with close button
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: _showExitDialog,
                          icon: const Icon(Icons.close_rounded, color: Colors.white, size: 28),
                        ),
                        const Spacer(),
                        IconButton(
                          onPressed: () => _showReceiptSheet(provider),
                          icon: const Icon(Icons.receipt_long_outlined, color: Colors.white, size: 28),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  // Bottom info panel
                  Container(
                    margin: const EdgeInsets.all(16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.6),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.name,
                                    style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                  ),
                                  Text(
                                    provider.formatPrice(item.price(provider.isIndia)),
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700,
                                      color: AppTheme.priceColor,
                                    ),
                                  ),
                                  if (item.owned > 0)
                                    Text(
                                      'Owned: ${item.owned}',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white.withValues(alpha: 0.8),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            // Buy/Sell actions on right side
                            Column(
                              children: [
                                GestureDetector(
                                  onTap: () => _onGridBuy(idx, 1),
                                  child: Container(
                                    width: 50,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      color: AppTheme.buyColor,
                                      borderRadius: BorderRadius.circular(14),
                                      boxShadow: [BoxShadow(color: AppTheme.buyColor.withValues(alpha: 0.4), blurRadius: 12)],
                                    ),
                                    child: const Icon(Icons.add_shopping_cart, color: Colors.white, size: 24),
                                  ),
                                ),
                                const Gap(12),
                                if (item.owned > 0)
                                  GestureDetector(
                                    onTap: () => _onGridSell(idx, 1),
                                    child: Container(
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: AppTheme.sellColor,
                                        borderRadius: BorderRadius.circular(14),
                                        boxShadow: [BoxShadow(color: AppTheme.sellColor.withValues(alpha: 0.4), blurRadius: 12)],
                                      ),
                                      child: const Icon(Icons.remove_shopping_cart, color: Colors.white, size: 24),
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                        const Gap(10),
                        Row(
                          children: [
                            Expanded(
                              child: SizedBox(
                                height: 50,
                                child: OutlinedButton(
                                  onPressed: () => _onGridSell(idx, _gridQty[idx] ?? 1),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.white,
                                    side: const BorderSide(color: Colors.white, width: 1.5),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                  ),
                                  child: const Text('Sell', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                                ),
                              ),
                            ),
                            const Gap(10),
                            Expanded(
                              child: SizedBox(
                                height: 50,
                                child: ElevatedButton(
                                  onPressed: _onBuy,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: AppTheme.buyColor,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: const Text('Buy',
                                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  // ─── SHARED WIDGETS ────────────────────────────────────
  Widget _buildItemImage(ShopItem item, {double size = 220}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Image.asset(
        item.imageUrl,
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (ctx, err, stack) {
          return Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: item.iconColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(item.icon, size: size * 0.45, color: item.iconColor),
          );
        },
      ),
    );
  }

  Widget _buildNetworkImage(ShopItem item, double width) {
    return Image.asset(
      item.imageUrl,
      width: width,
      fit: BoxFit.cover,
      errorBuilder: (ctx, err, stack) {
        return Container(
          color: item.iconColor.withValues(alpha: 0.08),
          child: Icon(item.icon, size: 48, color: item.iconColor),
        );
      },
    );
  }

  Widget _buildBalanceBar(String balanceText) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: 16,
        bottom: MediaQuery.of(context).padding.bottom + 16,
        left: 16,
        right: 16,
      ),
      decoration: BoxDecoration(
        color: AppTheme.balanceBarColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.balanceBarColor.withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Text(
        balanceText,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w800,
          color: Colors.white,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  void _showExitDialog() {
    final provider = context.read<GameProvider>();
    final spent = provider.totalSpent.toDouble();
    final budget = provider.budget.toDouble();

    // Track session duration
    if (_sessionStartTime != null) {
      final duration = DateTime.now().difference(_sessionStartTime!).inSeconds;
      AnalyticsService().logSessionDuration(duration);
      AnalyticsService().logQuitGame(spent, budget);
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Quit Game?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
        content: const Text('Your progress will be lost.', style: TextStyle(color: Color(0xFF6B7280))),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(ctx).pop();
              // Show interstitial before returning home
              await AdService().showInterstitialAd();
              if (context.mounted) {
                context.read<GameProvider>().resetGame();
                context.go('/home');
              }
            },
            child: const Text('Quit', style: TextStyle(color: AppTheme.sellColor)),
          ),
        ],
      ),
    );
  }

  void _showReceiptSheet(GameProvider provider) {
    final purchased = provider.items.where((i) => i.owned > 0).toList();

    // Track receipt viewed
    AnalyticsService().logReceiptViewed(
      provider.totalSpent.toDouble(),
      provider.budget.toDouble(),
      purchased.length,
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.3,
        maxChildSize: 0.9,
        builder: (ctx, scroll) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              const Gap(8),
              Container(
                width: 40, height: 4,
                decoration: BoxDecoration(color: const Color(0xFFD1D5DB), borderRadius: BorderRadius.circular(2)),
              ),
              const Gap(12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(flex: 3),
                  const Text('Your Purchases',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF111827))),
                  const Spacer(flex: 2),
                  IconButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    icon: const Icon(Icons.close_rounded, color: Color(0xFF6B7280)),
                  ),
                ],
              ),
              const Gap(4),
              Text('Spent: ${provider.formattedSpent}',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.sellColor)),
              const Gap(16),
              Expanded(
                child: purchased.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.shopping_cart_outlined, size: 48, color: Color(0xFFD1D5DB)),
                            Gap(12),
                            Text('No purchases yet', style: TextStyle(fontSize: 16, color: Color(0xFF9CA3AF))),
                          ],
                        ),
                      )
                    : ListView.separated(
                        controller: scroll,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: purchased.length,
                        separatorBuilder: (_, __) => const Divider(color: Color(0xFFF3F4F6)),
                        itemBuilder: (ctx, i) {
                          final p = purchased[i];
                          final total = p.owned * p.price(provider.isIndia);
                          return ListTile(
                            leading: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.asset(p.imageUrl, width: 44, height: 44, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  width: 44, height: 44,
                                  decoration: BoxDecoration(
                                    color: p.iconColor.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(p.icon, color: p.iconColor, size: 24),
                                ),
                              ),
                            ),
                            title: Text(p.name,
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF111827))),
                            subtitle: Text('x${p.owned}', style: const TextStyle(fontSize: 12, color: Color(0xFF9CA3AF))),
                            trailing: Text(provider.formatPrice(total),
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppTheme.priceColor)),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

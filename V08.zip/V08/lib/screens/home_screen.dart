import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../models/shop_item.dart';
import '../data/items_data.dart';
import '../providers/game_provider.dart';
import '../theme/app_theme.dart';
import '../services/ad_service.dart';
import '../services/analytics_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int? _selectedBudgetIndex;
  BannerAd? _bannerAd;
  bool _isBannerLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
    // Track home screen view
    AnalyticsService().logScreenView(screenName: 'home');
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  void _loadBannerAd() {
    _bannerAd = AdService().createBannerAd();
    if (_bannerAd != null) {
      _bannerAd!.load().then((_) {
        if (mounted) {
          setState(() => _isBannerLoaded = true);
        }
      });
    }
  }

  void _showSettingsMenu() {
    // Track settings opened
    AnalyticsService().logSettingsOpened();

    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final adService = AdService();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return Container(
            decoration: BoxDecoration(
              color: cs.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            ),
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle bar
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: cs.outline.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const Gap(16),
                // Title
                Row(
                  children: [
                    Icon(Icons.settings_outlined, color: cs.primary),
                    const Gap(12),
                    Text(
                      'Settings',
                      style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
                const Gap(24),
                // Ads Toggle
                Container(
                  decoration: BoxDecoration(
                    color: cs.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: cs.outlineVariant.withValues(alpha: 0.3),
                    ),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: adService.adsEnabled
                              ? AppTheme.buyColor.withValues(alpha: 0.1)
                              : Colors.grey.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          adService.adsEnabled
                              ? Icons.play_circle_outlined
                              : Icons.block_outlined,
                          color: adService.adsEnabled ? AppTheme.buyColor : Colors.grey,
                          size: 28,
                        ),
                      ),
                      const Gap(16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Show Ads',
                              style: tt.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const Gap(2),
                            Text(
                              adService.adsEnabled
                                  ? 'Ads are currently enabled'
                                  : 'Ads are currently disabled',
                              style: tt.bodySmall?.copyWith(
                                color: cs.onSurface.withValues(alpha: 0.6),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: adService.adsEnabled,
                        onChanged: (value) async {
                          await adService.setAdsEnabled(value);
                          // Track ads toggle
                          await AnalyticsService().logAdsToggle(value);
                          setModalState(() {});
                          setState(() {
                            // Reload banner ad based on new setting
                            if (value) {
                              _loadBannerAd();
                            } else {
                              _bannerAd?.dispose();
                              _bannerAd = null;
                              _isBannerLoaded = false;
                            }
                          });
                        },
                        activeColor: AppTheme.buyColor,
                      ),
                    ],
                  ),
                ),
                const Gap(8),
                // Help text
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    'Turning off ads will disable all advertisements in the app. This setting is saved for future sessions.',
                    style: tt.bodySmall?.copyWith(
                      color: cs.onSurface.withValues(alpha: 0.5),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                const Gap(24),
                // Close button
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: cs.primary,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      'Done',
                      style: tt.titleSmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const Gap(8),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<GameProvider>();
    final budgets = provider.country == Country.india ? indiaBudgets : usBudgets;
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          // Settings button (three dots)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: IconButton(
              onPressed: _showSettingsMenu,
              icon: Icon(
                Icons.more_vert_rounded,
                color: cs.onSurface,
              ),
              tooltip: 'Settings',
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF059669), Color(0xFF22C55E)],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.buyColor.withValues(alpha: 0.3),
                        blurRadius: 16,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.account_balance_wallet_rounded,
                    size: 36,
                    color: Colors.white,
                  ),
                ),
              ).animate().scale(
                    begin: const Offset(0.8, 0.8),
                    end: const Offset(1, 1),
                    duration: 500.ms,
                    curve: Curves.easeOut,
                  ),
              const Gap(16),
              Center(
                child: Text(
                  'Spend The Money',
                  style: tt.headlineMedium?.copyWith(fontWeight: FontWeight.w800),
                ),
              ).animate(delay: 100.ms).fadeIn(duration: 400.ms),
              Center(
                child: Text(
                  'How fast can you spend it all?',
                  style: tt.bodyMedium?.copyWith(color: cs.onSurface.withValues(alpha: 0.6)),
                ),
              ).animate(delay: 200.ms).fadeIn(duration: 400.ms),
              const Gap(32),
              Text(
                'SELECT COUNTRY',
                style: tt.labelMedium?.copyWith(
                  color: cs.onSurface.withValues(alpha: 0.5),
                  letterSpacing: 1.2,
                ),
              ).animate(delay: 300.ms).fadeIn(duration: 300.ms),
              const Gap(12),
              Row(
                children: [
                  Expanded(
                    child: _CountryCard(
                      flag: Country.india.flag,
                      name: Country.india.label,
                      currency: Country.india.currencySymbol,
                      isSelected: provider.country == Country.india,
                      onTap: () {
                        provider.setCountry(Country.india);
                        setState(() => _selectedBudgetIndex = null);
                        // Track country selection
                        AnalyticsService().logCountrySelection(
                          Country.india.label,
                          Country.india.currencySymbol,
                        );
                      },
                    ),
                  ),
                  const Gap(12),
                  Expanded(
                    child: _CountryCard(
                      flag: Country.us.flag,
                      name: Country.us.label,
                      currency: Country.us.currencySymbol,
                      isSelected: provider.country == Country.us,
                      onTap: () {
                        provider.setCountry(Country.us);
                        setState(() => _selectedBudgetIndex = null);
                        // Track country selection
                        AnalyticsService().logCountrySelection(
                          Country.us.label,
                          Country.us.currencySymbol,
                        );
                      },
                    ),
                  ),
                ],
              ).animate(delay: 400.ms).fadeIn(duration: 400.ms).slideY(begin: 0.1, end: 0),
              const Gap(32),
              Text(
                'CHOOSE YOUR BUDGET',
                style: tt.labelMedium?.copyWith(
                  color: cs.onSurface.withValues(alpha: 0.5),
                  letterSpacing: 1.2,
                ),
              ).animate(delay: 500.ms).fadeIn(duration: 300.ms),
              const Gap(12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.8,
                ),
                itemCount: budgets.length,
                itemBuilder: (context, index) {
                  final budget = budgets[index];
                  final isSelected = _selectedBudgetIndex == index;
                  return _BudgetCard(
                    label: budget.label,
                    subtitle: budget.subtitle,
                    isSelected: isSelected,
                    onTap: () {
                      setState(() => _selectedBudgetIndex = index);
                      // Track budget selection
                      AnalyticsService().logBudgetSelection(
                        budget.amount,
                        budget.label,
                      );
                    },
                  ).animate(delay: Duration(milliseconds: 550 + index * 80)).fadeIn(duration: 300.ms).slideY(begin: 0.1, end: 0);
                },
              ),
              const Gap(32),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _selectedBudgetIndex != null
                      ? () async {
                          final budget = budgets[_selectedBudgetIndex!];
                          provider.startGame(budget.amount);
                          // Track game start
                          await AnalyticsService().logGameStart(
                            budget.amount,
                            provider.country == Country.india ? 'India' : 'USA',
                          );
                          await AnalyticsService().setUserProperties(
                            adsEnabled: AdService().adsEnabled,
                            country: provider.country == Country.india ? 'India' : 'USA',
                          );
                          // Show interstitial before starting game
                          await AdService().showInterstitialAd();
                          if (context.mounted) context.go('/game');
                        }
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.buyColor,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: cs.onSurface.withValues(alpha: 0.12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'START SPENDING',
                        style: tt.titleMedium?.copyWith(
                          color: _selectedBudgetIndex != null
                              ? Colors.white
                              : cs.onSurface.withValues(alpha: 0.38),
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                      const Gap(8),
                      Icon(
                        Icons.arrow_forward_rounded,
                        color: _selectedBudgetIndex != null
                            ? Colors.white
                            : cs.onSurface.withValues(alpha: 0.38),
                      ),
                    ],
                  ),
                ),
              ).animate(delay: 900.ms).fadeIn(duration: 400.ms).slideY(begin: 0.1, end: 0),
              const Gap(16),
              // Banner Ad
              if (_isBannerLoaded && _bannerAd != null)
                Container(
                  height: 60,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  child: AdWidget(
                    ad: _bannerAd!,
                  ),
                ),
              const Gap(8),
            ],
          ),
        ),
      ),
    );
  }
}

class _CountryCard extends StatelessWidget {
  final String flag;
  final String name;
  final String currency;
  final bool isSelected;
  final VoidCallback onTap;

  const _CountryCard({
    required this.flag,
    required this.name,
    required this.currency,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.buyColor.withValues(alpha: 0.08) : cs.surfaceContainerLow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppTheme.buyColor : cs.outlineVariant.withValues(alpha: 0.3),
            width: isSelected ? 2.5 : 1,
          ),
        ),
        child: Column(
          children: [
            Text(flag, style: const TextStyle(fontSize: 32)),
            const Gap(8),
            Text(
              name,
              style: tt.titleSmall?.copyWith(
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected ? AppTheme.buyColor : cs.onSurface,
              ),
            ),
            Text(
              currency,
              style: tt.bodySmall?.copyWith(
                color: isSelected ? AppTheme.buyColor : cs.onSurface.withValues(alpha: 0.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BudgetCard extends StatelessWidget {
  final String label;
  final String subtitle;
  final bool isSelected;
  final VoidCallback onTap;

  const _BudgetCard({
    required this.label,
    required this.subtitle,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.buyColor.withValues(alpha: 0.08) : cs.surfaceContainerLow,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? AppTheme.buyColor : cs.outlineVariant.withValues(alpha: 0.3),
            width: isSelected ? 2.5 : 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              style: tt.titleSmall?.copyWith(
                fontWeight: FontWeight.w700,
                color: isSelected ? AppTheme.buyColor : cs.onSurface,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const Gap(4),
            Text(
              subtitle,
              style: tt.bodySmall?.copyWith(
                color: isSelected ? AppTheme.buyColor.withValues(alpha: 0.7) : cs.onSurface.withValues(alpha: 0.45),
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

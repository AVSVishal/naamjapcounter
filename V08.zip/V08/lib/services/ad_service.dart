import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdService {
  static final AdService _instance = AdService._internal();
  factory AdService() => _instance;
  AdService._internal();

  // Ad Unit IDs
  static const String _appOpenAdUnitId = 'ca-app-pub-7484296346485733/3911725468';
  static const String _interstitialAdUnitId = 'ca-app-pub-7484296346485733/3337010391';
  static const String _bannerAdUnitId = 'ca-app-pub-7484296346485733/1640785345';

  // Test Ad Unit IDs (for development)
  static const String _testAppOpenAdUnitId = 'ca-app-pub-3940256099942544/9257395921';
  static const String _testInterstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712';
  static const String _testBannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111';

  // Shared Preferences key
  static const String _adsEnabledKey = 'ads_enabled';

  // State
  AppOpenAd? _appOpenAd;
  InterstitialAd? _interstitialAd;
  bool _isInterstitialLoading = false;
  int _purchaseCount = 0;
  DateTime? _lastInterstitialTime;
  SharedPreferences? _prefs;

  // Configuration
  static const int _interstitialAfterPurchases = 5;
  static const Duration _minInterstitialInterval = Duration(minutes: 2);
  static const bool _useTestAds = false; // Set to false for production

  String get appOpenAdUnitId => _useTestAds ? _testAppOpenAdUnitId : _appOpenAdUnitId;
  String get interstitialAdUnitId => _useTestAds ? _testInterstitialAdUnitId : _interstitialAdUnitId;
  String get bannerAdUnitId => _useTestAds ? _testBannerAdUnitId : _bannerAdUnitId;

  bool get isInReelMode => _inReelMode;
  bool _inReelMode = false;

  // Ads enabled state - defaults to true (ads ON by default)
  bool _adsEnabled = true;
  bool get adsEnabled => _adsEnabled;

  void setReelMode(bool value) {
    _inReelMode = value;
  }

  // Load ads enabled state from SharedPreferences
  Future<void> _loadAdsEnabledState() async {
    _prefs ??= await SharedPreferences.getInstance();
    // Default is true (ads enabled), only disabled if explicitly set to false
    _adsEnabled = _prefs!.getBool(_adsEnabledKey) ?? true;
    if (kDebugMode) {
      print('AdService: Ads enabled state loaded: $_adsEnabled');
    }
  }

  // Toggle ads on/off and save to SharedPreferences
  Future<void> setAdsEnabled(bool enabled) async {
    _prefs ??= await SharedPreferences.getInstance();
    _adsEnabled = enabled;
    await _prefs!.setBool(_adsEnabledKey, enabled);
    if (kDebugMode) {
      print('AdService: Ads ${enabled ? 'enabled' : 'disabled'}');
    }
  }

  Future<void> initialize() async {
    if (kDebugMode) {
      print('AdService: Initializing...');
    }

    // Load ads enabled state first
    await _loadAdsEnabledState();

    await MobileAds.instance.initialize();

    // Only preload ads if ads are enabled
    if (_adsEnabled) {
      _loadAppOpenAd();
      _loadInterstitialAd();
    }

    if (kDebugMode) {
      print('AdService: Initialized successfully (ads enabled: $_adsEnabled)');
    }
  }

  // ==================== APP OPEN AD ====================
  void _loadAppOpenAd() {
    if (!_adsEnabled) return;

    AppOpenAd.load(
      adUnitId: appOpenAdUnitId,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          _appOpenAd = ad;
          if (kDebugMode) {
            print('AdService: App Open Ad loaded');
          }
        },
        onAdFailedToLoad: (error) {
          if (kDebugMode) {
            print('AdService: App Open Ad failed to load: ${error.message}');
          }
          _appOpenAd = null;
        },
      ),
    );
  }

  Future<void> showAppOpenAd() async {
    if (!_adsEnabled) {
      if (kDebugMode) {
        print('AdService: Skipping App Open Ad - ads disabled');
      }
      return;
    }

    if (_appOpenAd == null) {
      if (kDebugMode) {
        print('AdService: App Open Ad not ready, loading...');
      }
      _loadAppOpenAd();
      return;
    }

    _appOpenAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _appOpenAd = null;
        _loadAppOpenAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _appOpenAd = null;
        _loadAppOpenAd();
      },
    );

    await _appOpenAd!.show();
  }

  // ==================== INTERSTITIAL AD ====================
  void _loadInterstitialAd() {
    if (!_adsEnabled) return;
    if (_isInterstitialLoading) return;

    _isInterstitialLoading = true;

    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialLoading = false;
          if (kDebugMode) {
            print('AdService: Interstitial Ad loaded');
          }
        },
        onAdFailedToLoad: (error) {
          _interstitialAd = null;
          _isInterstitialLoading = false;
          if (kDebugMode) {
            print('AdService: Interstitial Ad failed to load: ${error.message}');
          }
        },
      ),
    );
  }

  Future<bool> showInterstitialAd({bool force = false}) async {
    // Never show ads if disabled
    if (!_adsEnabled) {
      if (kDebugMode) {
        print('AdService: Skipping interstitial - ads disabled');
      }
      return false;
    }

    // Never show ads in reel mode
    if (_inReelMode) {
      if (kDebugMode) {
        print('AdService: Skipping interstitial - in reel mode');
      }
      return false;
    }

    // Check if enough time has passed since last interstitial
    if (!force && _lastInterstitialTime != null) {
      final timeSinceLast = DateTime.now().difference(_lastInterstitialTime!);
      if (timeSinceLast < _minInterstitialInterval) {
        if (kDebugMode) {
          print('AdService: Skipping interstitial - too soon (${timeSinceLast.inSeconds}s)');
        }
        return false;
      }
    }

    if (_interstitialAd == null) {
      if (kDebugMode) {
        print('AdService: Interstitial not ready');
      }
      _loadInterstitialAd();
      return false;
    }

    final completer = Completer<bool>();

    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _lastInterstitialTime = DateTime.now();
        _loadInterstitialAd();
        completer.complete(true);
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitialAd();
        completer.complete(false);
      },
      onAdShowedFullScreenContent: (ad) {
        if (kDebugMode) {
          print('AdService: Interstitial shown');
        }
      },
    );

    await _interstitialAd!.show();
    return completer.future;
  }

  // Called when user makes a purchase
  Future<bool> onPurchase() async {
    if (!_adsEnabled) return false;

    _purchaseCount++;

    if (kDebugMode) {
      print('AdService: Purchase count: $_purchaseCount');
    }

    if (_purchaseCount >= _interstitialAfterPurchases) {
      _purchaseCount = 0;
      return await showInterstitialAd();
    }

    return false;
  }

  // Called when user starts a new game
  Future<bool> onNewGame() async {
    if (!_adsEnabled) return false;

    _purchaseCount = 0;
    return await showInterstitialAd(force: false);
  }

  // Called when returning to home
  Future<bool> onReturnToHome() async {
    if (!_adsEnabled) return false;

    return await showInterstitialAd();
  }

  // ==================== BANNER AD ====================
  BannerAd? createBannerAd() {
    // Don't create banner if ads disabled
    if (!_adsEnabled) return null;

    // Don't create banner in reel mode
    if (_inReelMode) {
      return null;
    }

    return BannerAd(
      adUnitId: bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (kDebugMode) {
            print('AdService: Banner Ad loaded');
          }
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          if (kDebugMode) {
            print('AdService: Banner Ad failed to load: ${error.message}');
          }
        },
      ),
    );
  }

  void dispose() {
    _appOpenAd?.dispose();
    _interstitialAd?.dispose();
    _appOpenAd = null;
    _interstitialAd = null;
  }
}
